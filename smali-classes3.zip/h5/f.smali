.class public interface abstract Lh5/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onFailure(Lh5/e;Ljava/io/IOException;)V
.end method

.method public abstract onResponse(Lh5/e;Lh5/B;)V
.end method
