.class public interface abstract Lh5/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh5/b$a;
    }
.end annotation


# static fields
.field public static final a:Lh5/b$a;

.field public static final b:Lh5/b;

.field public static final c:Lh5/b;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    sget-object v0, Lh5/b$a;->a:Lh5/b$a;

    .line 2
    .line 3
    sput-object v0, Lh5/b;->a:Lh5/b$a;

    .line 4
    .line 5
    new-instance v0, Lh5/b$a$a;

    .line 6
    .line 7
    invoke-direct {v0}, Lh5/b$a$a;-><init>()V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lh5/b;->b:Lh5/b;

    .line 11
    .line 12
    new-instance v0, Lj5/a;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v1, v2, v1}, Lj5/a;-><init>(Lh5/q;ILkotlin/jvm/internal/j;)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lh5/b;->c:Lh5/b;

    .line 20
    .line 21
    return-void
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
.end method


# virtual methods
.method public abstract a(Lh5/D;Lh5/B;)Lh5/z;
.end method
