.class public interface abstract Lh5/v;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh5/v$a;
    }
.end annotation


# virtual methods
.method public abstract intercept(Lh5/v$a;)Lh5/B;
.end method
