.class public interface abstract Lh5/v$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lh5/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lh5/z;)Lh5/B;
.end method

.method public abstract c()Lh5/z;
.end method

.method public abstract call()Lh5/e;
.end method
