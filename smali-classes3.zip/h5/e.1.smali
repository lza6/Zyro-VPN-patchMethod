.class public interface abstract Lh5/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh5/e$a;
    }
.end annotation


# virtual methods
.method public abstract c()Lh5/z;
.end method

.method public abstract cancel()V
.end method

.method public abstract execute()Lh5/B;
.end method

.method public abstract isCanceled()Z
.end method

.method public abstract n(Lh5/f;)V
.end method
