.class public final Lh5/c$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lh5/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh5/c$c$a;
    }
.end annotation


# static fields
.field public static final k:Lh5/c$c$a;

.field public static final l:Ljava/lang/String;

.field public static final m:Ljava/lang/String;


# instance fields
.field public final a:Lh5/u;

.field public final b:Lh5/t;

.field public final c:Ljava/lang/String;

.field public final d:Lh5/y;

.field public final e:I

.field public final f:Ljava/lang/String;

.field public final g:Lh5/t;

.field public final h:Lh5/s;

.field public final i:J

.field public final j:J


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lh5/c$c$a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lh5/c$c$a;-><init>(Lkotlin/jvm/internal/j;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lh5/c$c;->k:Lh5/c$c$a;

    .line 8
    .line 9
    sget-object v0, Lr5/j;->a:Lr5/j$a;

    .line 10
    .line 11
    invoke-virtual {v0}, Lr5/j$a;->g()Lr5/j;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v1}, Lr5/j;->g()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const-string v2, "-Sent-Millis"

    .line 20
    .line 21
    invoke-static {v1, v2}, Lkotlin/jvm/internal/s;->n(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    sput-object v1, Lh5/c$c;->l:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v0}, Lr5/j$a;->g()Lr5/j;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Lr5/j;->g()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const-string v1, "-Received-Millis"

    .line 36
    .line 37
    invoke-static {v0, v1}, Lkotlin/jvm/internal/s;->n(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, Lh5/c$c;->m:Ljava/lang/String;

    .line 42
    .line 43
    return-void
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
.end method

.method public constructor <init>(Lh5/B;)V
    .registers 4

    const-string v0, "response"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    invoke-virtual {p1}, Lh5/B;->V0()Lh5/z;

    move-result-object v0

    invoke-virtual {v0}, Lh5/z;->l()Lh5/u;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->a:Lh5/u;

    .line 45
    sget-object v0, Lh5/c;->g:Lh5/c$b;

    invoke-virtual {v0, p1}, Lh5/c$b;->f(Lh5/B;)Lh5/t;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->b:Lh5/t;

    .line 46
    invoke-virtual {p1}, Lh5/B;->V0()Lh5/z;

    move-result-object v0

    invoke-virtual {v0}, Lh5/z;->h()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->c:Ljava/lang/String;

    .line 47
    invoke-virtual {p1}, Lh5/B;->T0()Lh5/y;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->d:Lh5/y;

    .line 48
    invoke-virtual {p1}, Lh5/B;->r()I

    move-result v0

    iput v0, p0, Lh5/c$c;->e:I

    .line 49
    invoke-virtual {p1}, Lh5/B;->J0()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->f:Ljava/lang/String;

    .line 50
    invoke-virtual {p1}, Lh5/B;->m0()Lh5/t;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->g:Lh5/t;

    .line 51
    invoke-virtual {p1}, Lh5/B;->U()Lh5/s;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 52
    invoke-virtual {p1}, Lh5/B;->W0()J

    move-result-wide v0

    iput-wide v0, p0, Lh5/c$c;->i:J

    .line 53
    invoke-virtual {p1}, Lh5/B;->U0()J

    move-result-wide v0

    iput-wide v0, p0, Lh5/c$c;->j:J

    return-void
.end method

.method public constructor <init>(Lv5/C;)V
    .registers 10

    const-string v0, "rawSource"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    :try_start_8
    invoke-static {p1}, Lv5/q;->d(Lv5/C;)Lv5/g;

    move-result-object v0

    .line 3
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v1

    .line 4
    sget-object v2, Lh5/u;->k:Lh5/u$b;

    invoke-virtual {v2, v1}, Lh5/u$b;->f(Ljava/lang/String;)Lh5/u;

    move-result-object v2

    if-eqz v2, :cond_ff

    iput-object v2, p0, Lh5/c$c;->a:Lh5/u;

    .line 5
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lh5/c$c;->c:Ljava/lang/String;

    .line 6
    new-instance v1, Lh5/t$a;

    invoke-direct {v1}, Lh5/t$a;-><init>()V

    .line 7
    sget-object v2, Lh5/c;->g:Lh5/c$b;

    invoke-virtual {v2, v0}, Lh5/c$b;->c(Lv5/g;)I

    move-result v2

    const/4 v3, 0x0

    move v4, v3

    :goto_2d
    if-ge v4, v2, :cond_3c

    add-int/lit8 v4, v4, 0x1

    .line 8
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lh5/t$a;->b(Ljava/lang/String;)Lh5/t$a;

    goto :goto_2d

    :catchall_39
    move-exception v0

    goto/16 :goto_117

    .line 9
    :cond_3c
    invoke-virtual {v1}, Lh5/t$a;->d()Lh5/t;

    move-result-object v1

    iput-object v1, p0, Lh5/c$c;->b:Lh5/t;

    .line 10
    sget-object v1, Ln5/k;->d:Ln5/k$a;

    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ln5/k$a;->a(Ljava/lang/String;)Ln5/k;

    move-result-object v1

    .line 11
    iget-object v2, v1, Ln5/k;->a:Lh5/y;

    iput-object v2, p0, Lh5/c$c;->d:Lh5/y;

    .line 12
    iget v2, v1, Ln5/k;->b:I

    iput v2, p0, Lh5/c$c;->e:I

    .line 13
    iget-object v1, v1, Ln5/k;->c:Ljava/lang/String;

    iput-object v1, p0, Lh5/c$c;->f:Ljava/lang/String;

    .line 14
    new-instance v1, Lh5/t$a;

    invoke-direct {v1}, Lh5/t$a;-><init>()V

    .line 15
    sget-object v2, Lh5/c;->g:Lh5/c$b;

    invoke-virtual {v2, v0}, Lh5/c$b;->c(Lv5/g;)I

    move-result v2

    :goto_63
    if-ge v3, v2, :cond_6f

    add-int/lit8 v3, v3, 0x1

    .line 16
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lh5/t$a;->b(Ljava/lang/String;)Lh5/t$a;

    goto :goto_63

    .line 17
    :cond_6f
    sget-object v2, Lh5/c$c;->l:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lh5/t$a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 18
    sget-object v4, Lh5/c$c;->m:Ljava/lang/String;

    invoke-virtual {v1, v4}, Lh5/t$a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 19
    invoke-virtual {v1, v2}, Lh5/t$a;->g(Ljava/lang/String;)Lh5/t$a;

    .line 20
    invoke-virtual {v1, v4}, Lh5/t$a;->g(Ljava/lang/String;)Lh5/t$a;

    const-wide/16 v6, 0x0

    if-nez v3, :cond_87

    move-wide v2, v6

    goto :goto_8b

    .line 21
    :cond_87
    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    :goto_8b
    iput-wide v2, p0, Lh5/c$c;->i:J

    if-nez v5, :cond_90

    goto :goto_94

    .line 22
    :cond_90
    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    :goto_94
    iput-wide v6, p0, Lh5/c$c;->j:J

    .line 23
    invoke-virtual {v1}, Lh5/t$a;->d()Lh5/t;

    move-result-object v1

    iput-object v1, p0, Lh5/c$c;->g:Lh5/t;

    .line 24
    invoke-virtual {p0}, Lh5/c$c;->a()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_f7

    .line 25
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v1

    .line 26
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-gtz v3, :cond_db

    .line 27
    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v1

    .line 28
    sget-object v3, Lh5/i;->b:Lh5/i$b;

    invoke-virtual {v3, v1}, Lh5/i$b;->b(Ljava/lang/String;)Lh5/i;

    move-result-object v1

    .line 29
    invoke-virtual {p0, v0}, Lh5/c$c;->c(Lv5/g;)Ljava/util/List;

    move-result-object v3

    .line 30
    invoke-virtual {p0, v0}, Lh5/c$c;->c(Lv5/g;)Ljava/util/List;

    move-result-object v4

    .line 31
    invoke-interface {v0}, Lv5/g;->L()Z

    move-result v5

    if-nez v5, :cond_d0

    .line 32
    sget-object v5, Lh5/E;->b:Lh5/E$a;

    invoke-interface {v0}, Lv5/g;->H0()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lh5/E$a;->a(Ljava/lang/String;)Lh5/E;

    move-result-object v0

    goto :goto_d2

    .line 33
    :cond_d0
    sget-object v0, Lh5/E;->g:Lh5/E;

    .line 34
    :goto_d2
    sget-object v5, Lh5/s;->e:Lh5/s$a;

    invoke-virtual {v5, v0, v1, v3, v4}, Lh5/s$a;->a(Lh5/E;Lh5/i;Ljava/util/List;Ljava/util/List;)Lh5/s;

    move-result-object v0

    iput-object v0, p0, Lh5/c$c;->h:Lh5/s;

    goto :goto_f9

    .line 35
    :cond_db
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "expected \"\" but was \""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x22

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 36
    :cond_f7
    iput-object v2, p0, Lh5/c$c;->h:Lh5/s;

    .line 37
    :goto_f9
    sget-object v0, Lp4/E;->a:Lp4/E;
    :try_end_fb
    .catchall {:try_start_8 .. :try_end_fb} :catchall_39

    .line 38
    invoke-static {p1, v2}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    .line 39
    :cond_ff
    :try_start_ff
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Cache corruption for "

    invoke-static {v2, v1}, Lkotlin/jvm/internal/s;->n(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 40
    sget-object v1, Lr5/j;->a:Lr5/j$a;

    invoke-virtual {v1}, Lr5/j$a;->g()Lr5/j;

    move-result-object v1

    const-string v2, "cache corruption"

    const/4 v3, 0x5

    invoke-virtual {v1, v2, v3, v0}, Lr5/j;->k(Ljava/lang/String;ILjava/lang/Throwable;)V

    .line 41
    throw v0
    :try_end_117
    .catchall {:try_start_ff .. :try_end_117} :catchall_39

    .line 42
    :goto_117
    :try_start_117
    throw v0
    :try_end_118
    .catchall {:try_start_117 .. :try_end_118} :catchall_118

    :catchall_118
    move-exception v1

    invoke-static {p1, v0}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1
.end method


# virtual methods
.method public final a()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lh5/c$c;->a:Lh5/u;

    .line 2
    .line 3
    invoke-virtual {v0}, Lh5/u;->q()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "https"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/s;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    return v0
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
.end method

.method public final b(Lh5/z;Lh5/B;)Z
    .registers 5

    .line 1
    const-string v0, "request"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "response"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lh5/c$c;->a:Lh5/u;

    .line 12
    .line 13
    invoke-virtual {p1}, Lh5/z;->l()Lh5/u;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {v0, v1}, Lkotlin/jvm/internal/s;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_2e

    .line 22
    .line 23
    iget-object v0, p0, Lh5/c$c;->c:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {p1}, Lh5/z;->h()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-static {v0, v1}, Lkotlin/jvm/internal/s;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2e

    .line 34
    .line 35
    sget-object v0, Lh5/c;->g:Lh5/c$b;

    .line 36
    .line 37
    iget-object v1, p0, Lh5/c$c;->b:Lh5/t;

    .line 38
    .line 39
    invoke-virtual {v0, p2, v1, p1}, Lh5/c$b;->g(Lh5/B;Lh5/t;Lh5/z;)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    if-eqz p1, :cond_2e

    .line 44
    .line 45
    const/4 p1, 0x1

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    const/4 p1, 0x0

    .line 48
    :goto_2f
    return p1
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public final c(Lv5/g;)Ljava/util/List;
    .registers 9

    .line 1
    sget-object v0, Lh5/c;->g:Lh5/c$b;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lh5/c$b;->c(Lv5/g;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, -0x1

    .line 8
    if-ne v0, v1, :cond_e

    .line 9
    .line 10
    invoke-static {}, Lq4/o;->h()Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :cond_e
    :try_start_e
    const-string v1, "X.509"

    .line 16
    .line 17
    invoke-static {v1}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    new-instance v2, Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 24
    .line 25
    .line 26
    const/4 v3, 0x0

    .line 27
    :goto_1a
    if-ge v3, v0, :cond_41

    .line 28
    .line 29
    add-int/lit8 v3, v3, 0x1

    .line 30
    .line 31
    invoke-interface {p1}, Lv5/g;->H0()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    new-instance v5, Lv5/e;

    .line 36
    .line 37
    invoke-direct {v5}, Lv5/e;-><init>()V

    .line 38
    .line 39
    .line 40
    sget-object v6, Lv5/h;->d:Lv5/h$a;

    .line 41
    .line 42
    invoke-virtual {v6, v4}, Lv5/h$a;->a(Ljava/lang/String;)Lv5/h;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    invoke-static {v4}, Lkotlin/jvm/internal/s;->c(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v5, v4}, Lv5/e;->y1(Lv5/h;)Lv5/e;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v5}, Lv5/e;->t1()Ljava/io/InputStream;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    invoke-virtual {v1, v4}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_3e
    .catch Ljava/security/cert/CertificateException; {:try_start_e .. :try_end_3e} :catch_3f

    .line 61
    .line 62
    .line 63
    goto :goto_1a

    .line 64
    :catch_3f
    move-exception p1

    .line 65
    goto :goto_42

    .line 66
    :cond_41
    return-object v2

    .line 67
    :goto_42
    new-instance v0, Ljava/io/IOException;

    .line 68
    .line 69
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    throw v0
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
.end method

.method public final d(Lk5/d$d;)Lh5/B;
    .registers 7

    .line 1
    const-string v0, "snapshot"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lh5/c$c;->g:Lh5/t;

    .line 7
    .line 8
    const-string v1, "Content-Type"

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Lh5/t;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v1, p0, Lh5/c$c;->g:Lh5/t;

    .line 15
    .line 16
    const-string v2, "Content-Length"

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Lh5/t;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    new-instance v2, Lh5/z$a;

    .line 23
    .line 24
    invoke-direct {v2}, Lh5/z$a;-><init>()V

    .line 25
    .line 26
    .line 27
    iget-object v3, p0, Lh5/c$c;->a:Lh5/u;

    .line 28
    .line 29
    invoke-virtual {v2, v3}, Lh5/z$a;->o(Lh5/u;)Lh5/z$a;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    iget-object v3, p0, Lh5/c$c;->c:Ljava/lang/String;

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    invoke-virtual {v2, v3, v4}, Lh5/z$a;->h(Ljava/lang/String;Lh5/A;)Lh5/z$a;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    iget-object v3, p0, Lh5/c$c;->b:Lh5/t;

    .line 41
    .line 42
    invoke-virtual {v2, v3}, Lh5/z$a;->g(Lh5/t;)Lh5/z$a;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v2}, Lh5/z$a;->b()Lh5/z;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    new-instance v3, Lh5/B$a;

    .line 51
    .line 52
    invoke-direct {v3}, Lh5/B$a;-><init>()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v3, v2}, Lh5/B$a;->s(Lh5/z;)Lh5/B$a;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    iget-object v3, p0, Lh5/c$c;->d:Lh5/y;

    .line 60
    .line 61
    invoke-virtual {v2, v3}, Lh5/B$a;->q(Lh5/y;)Lh5/B$a;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    iget v3, p0, Lh5/c$c;->e:I

    .line 66
    .line 67
    invoke-virtual {v2, v3}, Lh5/B$a;->g(I)Lh5/B$a;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    iget-object v3, p0, Lh5/c$c;->f:Ljava/lang/String;

    .line 72
    .line 73
    invoke-virtual {v2, v3}, Lh5/B$a;->n(Ljava/lang/String;)Lh5/B$a;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    iget-object v3, p0, Lh5/c$c;->g:Lh5/t;

    .line 78
    .line 79
    invoke-virtual {v2, v3}, Lh5/B$a;->l(Lh5/t;)Lh5/B$a;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    new-instance v3, Lh5/c$a;

    .line 84
    .line 85
    invoke-direct {v3, p1, v0, v1}, Lh5/c$a;-><init>(Lk5/d$d;Ljava/lang/String;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2, v3}, Lh5/B$a;->b(Lh5/C;)Lh5/B$a;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    iget-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 93
    .line 94
    invoke-virtual {p1, v0}, Lh5/B$a;->j(Lh5/s;)Lh5/B$a;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    iget-wide v0, p0, Lh5/c$c;->i:J

    .line 99
    .line 100
    invoke-virtual {p1, v0, v1}, Lh5/B$a;->t(J)Lh5/B$a;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    iget-wide v0, p0, Lh5/c$c;->j:J

    .line 105
    .line 106
    invoke-virtual {p1, v0, v1}, Lh5/B$a;->r(J)Lh5/B$a;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    invoke-virtual {p1}, Lh5/B$a;->c()Lh5/B;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    return-object p1
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
.end method

.method public final e(Lv5/f;Ljava/util/List;)V
    .registers 11

    .line 1
    :try_start_0
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    int-to-long v0, v0

    .line 6
    invoke-interface {p1, v0, v1}, Lv5/f;->p1(J)Lv5/f;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/16 v1, 0xa

    .line 11
    .line 12
    invoke-interface {v0, v1}, Lv5/f;->M(I)Lv5/f;

    .line 13
    .line 14
    .line 15
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    :goto_12
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_3f

    .line 24
    .line 25
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/security/cert/Certificate;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/security/cert/Certificate;->getEncoded()[B

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    sget-object v2, Lv5/h;->d:Lv5/h$a;

    .line 36
    .line 37
    const-string v0, "bytes"

    .line 38
    .line 39
    invoke-static {v3, v0}, Lkotlin/jvm/internal/s;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const/4 v6, 0x3

    .line 43
    const/4 v7, 0x0

    .line 44
    const/4 v4, 0x0

    .line 45
    const/4 v5, 0x0

    .line 46
    invoke-static/range {v2 .. v7}, Lv5/h$a;->g(Lv5/h$a;[BIIILjava/lang/Object;)Lv5/h;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Lv5/h;->a()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-interface {p1, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-interface {v0, v1}, Lv5/f;->M(I)Lv5/f;
    :try_end_3c
    .catch Ljava/security/cert/CertificateEncodingException; {:try_start_0 .. :try_end_3c} :catch_3d

    .line 59
    .line 60
    .line 61
    goto :goto_12

    .line 62
    :catch_3d
    move-exception p1

    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    return-void

    .line 65
    :goto_40
    new-instance p2, Ljava/io/IOException;

    .line 66
    .line 67
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    throw p2
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public final f(Lk5/d$b;)V
    .registers 9

    .line 1
    const-string v0, "editor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-virtual {p1, v0}, Lk5/d$b;->f(I)Lv5/A;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-static {p1}, Lv5/q;->c(Lv5/A;)Lv5/f;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    :try_start_e
    iget-object v1, p0, Lh5/c$c;->a:Lh5/u;

    .line 16
    .line 17
    invoke-virtual {v1}, Lh5/u;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-interface {p1, v1}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/16 v2, 0xa

    .line 26
    .line 27
    invoke-interface {v1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lh5/c$c;->c:Ljava/lang/String;

    .line 31
    .line 32
    invoke-interface {p1, v1}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 37
    .line 38
    .line 39
    iget-object v1, p0, Lh5/c$c;->b:Lh5/t;

    .line 40
    .line 41
    invoke-virtual {v1}, Lh5/t;->size()I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    int-to-long v3, v1

    .line 46
    invoke-interface {p1, v3, v4}, Lv5/f;->p1(J)Lv5/f;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-interface {v1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 51
    .line 52
    .line 53
    iget-object v1, p0, Lh5/c$c;->b:Lh5/t;

    .line 54
    .line 55
    invoke-virtual {v1}, Lh5/t;->size()I

    .line 56
    .line 57
    .line 58
    move-result v1
    :try_end_3a
    .catchall {:try_start_e .. :try_end_3a} :catchall_5e

    .line 59
    move v3, v0

    .line 60
    :goto_3b
    const-string v4, ": "

    .line 61
    .line 62
    if-ge v3, v1, :cond_61

    .line 63
    .line 64
    add-int/lit8 v5, v3, 0x1

    .line 65
    .line 66
    :try_start_41
    iget-object v6, p0, Lh5/c$c;->b:Lh5/t;

    .line 67
    .line 68
    invoke-virtual {v6, v3}, Lh5/t;->c(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    invoke-interface {p1, v6}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    invoke-interface {v6, v4}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    iget-object v6, p0, Lh5/c$c;->b:Lh5/t;

    .line 81
    .line 82
    invoke-virtual {v6, v3}, Lh5/t;->f(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    invoke-interface {v4, v3}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    invoke-interface {v3, v2}, Lv5/f;->M(I)Lv5/f;

    .line 91
    .line 92
    .line 93
    move v3, v5

    .line 94
    goto :goto_3b

    .line 95
    :catchall_5e
    move-exception v0

    .line 96
    goto/16 :goto_11b

    .line 97
    .line 98
    :cond_61
    new-instance v1, Ln5/k;

    .line 99
    .line 100
    iget-object v3, p0, Lh5/c$c;->d:Lh5/y;

    .line 101
    .line 102
    iget v5, p0, Lh5/c$c;->e:I

    .line 103
    .line 104
    iget-object v6, p0, Lh5/c$c;->f:Ljava/lang/String;

    .line 105
    .line 106
    invoke-direct {v1, v3, v5, v6}, Ln5/k;-><init>(Lh5/y;ILjava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v1}, Ln5/k;->toString()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-interface {p1, v1}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-interface {v1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 118
    .line 119
    .line 120
    iget-object v1, p0, Lh5/c$c;->g:Lh5/t;

    .line 121
    .line 122
    invoke-virtual {v1}, Lh5/t;->size()I

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    add-int/lit8 v1, v1, 0x2

    .line 127
    .line 128
    int-to-long v5, v1

    .line 129
    invoke-interface {p1, v5, v6}, Lv5/f;->p1(J)Lv5/f;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    invoke-interface {v1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 134
    .line 135
    .line 136
    iget-object v1, p0, Lh5/c$c;->g:Lh5/t;

    .line 137
    .line 138
    invoke-virtual {v1}, Lh5/t;->size()I

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    :goto_8d
    if-ge v0, v1, :cond_ae

    .line 143
    .line 144
    add-int/lit8 v3, v0, 0x1

    .line 145
    .line 146
    iget-object v5, p0, Lh5/c$c;->g:Lh5/t;

    .line 147
    .line 148
    invoke-virtual {v5, v0}, Lh5/t;->c(I)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    invoke-interface {p1, v5}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    invoke-interface {v5, v4}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 157
    .line 158
    .line 159
    move-result-object v5

    .line 160
    iget-object v6, p0, Lh5/c$c;->g:Lh5/t;

    .line 161
    .line 162
    invoke-virtual {v6, v0}, Lh5/t;->f(I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-interface {v5, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-interface {v0, v2}, Lv5/f;->M(I)Lv5/f;

    .line 171
    .line 172
    .line 173
    move v0, v3

    .line 174
    goto :goto_8d

    .line 175
    :cond_ae
    sget-object v0, Lh5/c$c;->l:Ljava/lang/String;

    .line 176
    .line 177
    invoke-interface {p1, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    invoke-interface {v0, v4}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    iget-wide v5, p0, Lh5/c$c;->i:J

    .line 186
    .line 187
    invoke-interface {v0, v5, v6}, Lv5/f;->p1(J)Lv5/f;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-interface {v0, v2}, Lv5/f;->M(I)Lv5/f;

    .line 192
    .line 193
    .line 194
    sget-object v0, Lh5/c$c;->m:Ljava/lang/String;

    .line 195
    .line 196
    invoke-interface {p1, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    invoke-interface {v0, v4}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    iget-wide v3, p0, Lh5/c$c;->j:J

    .line 205
    .line 206
    invoke-interface {v0, v3, v4}, Lv5/f;->p1(J)Lv5/f;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-interface {v0, v2}, Lv5/f;->M(I)Lv5/f;

    .line 211
    .line 212
    .line 213
    invoke-virtual {p0}, Lh5/c$c;->a()Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    if-eqz v0, :cond_114

    .line 218
    .line 219
    invoke-interface {p1, v2}, Lv5/f;->M(I)Lv5/f;

    .line 220
    .line 221
    .line 222
    iget-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 223
    .line 224
    invoke-static {v0}, Lkotlin/jvm/internal/s;->c(Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v0}, Lh5/s;->a()Lh5/i;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    invoke-virtual {v0}, Lh5/i;->c()Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    invoke-interface {p1, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    invoke-interface {v0, v2}, Lv5/f;->M(I)Lv5/f;

    .line 240
    .line 241
    .line 242
    iget-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 243
    .line 244
    invoke-virtual {v0}, Lh5/s;->d()Ljava/util/List;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    invoke-virtual {p0, p1, v0}, Lh5/c$c;->e(Lv5/f;Ljava/util/List;)V

    .line 249
    .line 250
    .line 251
    iget-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 252
    .line 253
    invoke-virtual {v0}, Lh5/s;->c()Ljava/util/List;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    invoke-virtual {p0, p1, v0}, Lh5/c$c;->e(Lv5/f;Ljava/util/List;)V

    .line 258
    .line 259
    .line 260
    iget-object v0, p0, Lh5/c$c;->h:Lh5/s;

    .line 261
    .line 262
    invoke-virtual {v0}, Lh5/s;->e()Lh5/E;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    invoke-virtual {v0}, Lh5/E;->b()Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    invoke-interface {p1, v0}, Lv5/f;->n0(Ljava/lang/String;)Lv5/f;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    invoke-interface {v0, v2}, Lv5/f;->M(I)Lv5/f;

    .line 275
    .line 276
    .line 277
    :cond_114
    sget-object v0, Lp4/E;->a:Lp4/E;
    :try_end_116
    .catchall {:try_start_41 .. :try_end_116} :catchall_5e

    .line 278
    .line 279
    const/4 v0, 0x0

    .line 280
    invoke-static {p1, v0}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 281
    .line 282
    .line 283
    return-void

    .line 284
    :goto_11b
    :try_start_11b
    throw v0
    :try_end_11c
    .catchall {:try_start_11b .. :try_end_11c} :catchall_11c

    .line 285
    :catchall_11c
    move-exception v1

    .line 286
    invoke-static {p1, v0}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 287
    .line 288
    .line 289
    throw v1
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
.end method
