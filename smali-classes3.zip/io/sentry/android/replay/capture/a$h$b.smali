.class public final Lio/sentry/android/replay/capture/a$h$b;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/sentry/android/replay/capture/a$h;->setValue(Ljava/lang/Object;LI4/i;Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Lio/sentry/android/replay/capture/a;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Lio/sentry/android/replay/capture/a;)V
    .registers 5

    iput-object p1, p0, Lio/sentry/android/replay/capture/a$h$b;->d:Ljava/lang/String;

    iput-object p2, p0, Lio/sentry/android/replay/capture/a$h$b;->e:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/replay/capture/a$h$b;->f:Ljava/lang/Object;

    iput-object p4, p0, Lio/sentry/android/replay/capture/a$h$b;->g:Lio/sentry/android/replay/capture/a;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lio/sentry/android/replay/capture/a$h$b;->invoke()V

    sget-object v0, Lp4/E;->a:Lp4/E;

    return-object v0
.end method

.method public final invoke()V
    .registers 4

    .line 2
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$h$b;->e:Ljava/lang/Object;

    iget-object v1, p0, Lio/sentry/android/replay/capture/a$h$b;->f:Ljava/lang/Object;

    check-cast v1, Ljava/util/Date;

    check-cast v0, Ljava/util/Date;

    .line 3
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$h$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v0

    if-eqz v0, :cond_1d

    if-nez v1, :cond_14

    const/4 v1, 0x0

    goto :goto_18

    :cond_14
    invoke-static {v1}, Lio/sentry/j;->g(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    :goto_18
    const-string v2, "segment.timestamp"

    invoke-virtual {v0, v2, v1}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1d
    return-void
.end method
