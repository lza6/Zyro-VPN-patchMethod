.class public final Lio/sentry/android/replay/capture/a$f$b;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/sentry/android/replay/capture/a$f;->setValue(Ljava/lang/Object;LI4/i;Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Lio/sentry/android/replay/capture/a;

.field public final synthetic h:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Lio/sentry/android/replay/capture/a;Ljava/lang/String;)V
    .registers 6

    iput-object p1, p0, Lio/sentry/android/replay/capture/a$f$b;->d:Ljava/lang/String;

    iput-object p2, p0, Lio/sentry/android/replay/capture/a$f$b;->e:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/replay/capture/a$f$b;->f:Ljava/lang/Object;

    iput-object p4, p0, Lio/sentry/android/replay/capture/a$f$b;->g:Lio/sentry/android/replay/capture/a;

    iput-object p5, p0, Lio/sentry/android/replay/capture/a$f$b;->h:Ljava/lang/String;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lio/sentry/android/replay/capture/a$f$b;->invoke()V

    sget-object v0, Lp4/E;->a:Lp4/E;

    return-object v0
.end method

.method public final invoke()V
    .registers 4

    .line 2
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$f$b;->f:Ljava/lang/Object;

    .line 3
    iget-object v1, p0, Lio/sentry/android/replay/capture/a$f$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v1}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v1

    if-eqz v1, :cond_13

    iget-object v2, p0, Lio/sentry/android/replay/capture/a$f$b;->h:Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    :cond_13
    return-void
.end method
