.class public final Lio/sentry/android/replay/capture/a$d$b;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/sentry/android/replay/capture/a$d;->setValue(Ljava/lang/Object;LI4/i;Ljava/lang/Object;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Lio/sentry/android/replay/capture/a;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Lio/sentry/android/replay/capture/a;)V
    .registers 5

    iput-object p1, p0, Lio/sentry/android/replay/capture/a$d$b;->d:Ljava/lang/String;

    iput-object p2, p0, Lio/sentry/android/replay/capture/a$d$b;->e:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/replay/capture/a$d$b;->f:Ljava/lang/Object;

    iput-object p4, p0, Lio/sentry/android/replay/capture/a$d$b;->g:Lio/sentry/android/replay/capture/a;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lio/sentry/android/replay/capture/a$d$b;->invoke()V

    sget-object v0, Lp4/E;->a:Lp4/E;

    return-object v0
.end method

.method public final invoke()V
    .registers 5

    .line 2
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$d$b;->e:Ljava/lang/Object;

    iget-object v1, p0, Lio/sentry/android/replay/capture/a$d$b;->f:Ljava/lang/Object;

    check-cast v1, Lio/sentry/android/replay/u;

    check-cast v0, Lio/sentry/android/replay/u;

    if-nez v1, :cond_b

    goto :goto_5f

    .line 3
    :cond_b
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$d$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v0

    if-eqz v0, :cond_20

    invoke-virtual {v1}, Lio/sentry/android/replay/u;->c()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "config.height"

    invoke-virtual {v0, v3, v2}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    :cond_20
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$d$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v0

    if-eqz v0, :cond_35

    invoke-virtual {v1}, Lio/sentry/android/replay/u;->d()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "config.width"

    invoke-virtual {v0, v3, v2}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    :cond_35
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$d$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v0

    if-eqz v0, :cond_4a

    invoke-virtual {v1}, Lio/sentry/android/replay/u;->b()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "config.frame-rate"

    invoke-virtual {v0, v3, v2}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    :cond_4a
    iget-object v0, p0, Lio/sentry/android/replay/capture/a$d$b;->g:Lio/sentry/android/replay/capture/a;

    invoke-virtual {v0}, Lio/sentry/android/replay/capture/a;->p()Lio/sentry/android/replay/h;

    move-result-object v0

    if-eqz v0, :cond_5f

    invoke-virtual {v1}, Lio/sentry/android/replay/u;->a()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "config.bit-rate"

    invoke-virtual {v0, v2, v1}, Lio/sentry/android/replay/h;->J0(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5f
    :goto_5f
    return-void
.end method
