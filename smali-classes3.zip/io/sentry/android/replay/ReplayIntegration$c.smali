.class public final Lio/sentry/android/replay/ReplayIntegration$c;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/sentry/android/replay/ReplayIntegration;->l(Ljava/lang/Boolean;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Lio/sentry/android/replay/ReplayIntegration;


# direct methods
.method public constructor <init>(Lio/sentry/android/replay/ReplayIntegration;)V
    .registers 2

    iput-object p1, p0, Lio/sentry/android/replay/ReplayIntegration$c;->d:Lio/sentry/android/replay/ReplayIntegration;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Date;)V
    .registers 4

    .line 1
    const-string v0, "newTimestamp"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/replay/ReplayIntegration$c;->d:Lio/sentry/android/replay/ReplayIntegration;

    .line 7
    .line 8
    invoke-static {v0}, Lio/sentry/android/replay/ReplayIntegration;->m0(Lio/sentry/android/replay/ReplayIntegration;)Lio/sentry/android/replay/capture/h;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_e

    .line 13
    .line 14
    goto :goto_2c

    .line 15
    :cond_e
    iget-object v1, p0, Lio/sentry/android/replay/ReplayIntegration$c;->d:Lio/sentry/android/replay/ReplayIntegration;

    .line 16
    .line 17
    invoke-static {v1}, Lio/sentry/android/replay/ReplayIntegration;->m0(Lio/sentry/android/replay/ReplayIntegration;)Lio/sentry/android/replay/capture/h;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_1f

    .line 22
    .line 23
    invoke-interface {v1}, Lio/sentry/android/replay/capture/h;->k()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    const/4 v1, 0x0

    .line 33
    :goto_20
    invoke-static {v1}, Lkotlin/jvm/internal/s;->c(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    add-int/lit8 v1, v1, 0x1

    .line 41
    .line 42
    invoke-interface {v0, v1}, Lio/sentry/android/replay/capture/h;->i(I)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    iget-object v0, p0, Lio/sentry/android/replay/ReplayIntegration$c;->d:Lio/sentry/android/replay/ReplayIntegration;

    .line 46
    .line 47
    invoke-static {v0}, Lio/sentry/android/replay/ReplayIntegration;->m0(Lio/sentry/android/replay/ReplayIntegration;)Lio/sentry/android/replay/capture/h;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-nez v0, :cond_35

    .line 52
    .line 53
    goto :goto_38

    .line 54
    :cond_35
    invoke-interface {v0, p1}, Lio/sentry/android/replay/capture/h;->h(Ljava/util/Date;)V

    .line 55
    .line 56
    .line 57
    :goto_38
    return-void
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, Ljava/util/Date;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lio/sentry/android/replay/ReplayIntegration$c;->a(Ljava/util/Date;)V

    .line 4
    .line 5
    .line 6
    sget-object p1, Lp4/E;->a:Lp4/E;

    .line 7
    .line 8
    return-object p1
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
.end method
