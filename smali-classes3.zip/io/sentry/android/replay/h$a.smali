.class public final Lio/sentry/android/replay/h$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/sentry/android/replay/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/j;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Lio/sentry/android/replay/h$a;-><init>()V

    return-void
.end method

.method public static synthetic a(Lio/sentry/android/replay/h;Ljava/io/File;Ljava/lang/String;)Z
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Lio/sentry/android/replay/h$a;->b(Lio/sentry/android/replay/h;Ljava/io/File;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static final b(Lio/sentry/android/replay/h;Ljava/io/File;Ljava/lang/String;)Z
    .registers 14

    .line 1
    const-string v0, "$cache"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "name"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/s;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x2

    .line 12
    const/4 v1, 0x0

    .line 13
    const-string v2, ".jpg"

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-static {p2, v2, v3, v0, v1}, LK4/x;->x(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_2f

    .line 21
    .line 22
    new-instance v5, Ljava/io/File;

    .line 23
    .line 24
    invoke-direct {v5, p1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-static {v5}, Lz4/l;->o(Ljava/io/File;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-static {p1}, LK4/w;->r(Ljava/lang/String;)Ljava/lang/Long;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    if-eqz p1, :cond_2f

    .line 36
    .line 37
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 38
    .line 39
    .line 40
    move-result-wide v6

    .line 41
    const/4 v9, 0x4

    .line 42
    const/4 v10, 0x0

    .line 43
    const/4 v8, 0x0

    .line 44
    move-object v4, p0

    .line 45
    invoke-static/range {v4 .. v10}, Lio/sentry/android/replay/h;->r(Lio/sentry/android/replay/h;Ljava/io/File;JLjava/lang/String;ILjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    return v3
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
.end method


# virtual methods
.method public final c(Lio/sentry/r2;Lio/sentry/protocol/r;LB4/l;)Lio/sentry/android/replay/c;
    .registers 29

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    const-string v3, ""

    const-string v4, "options"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "replayId"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-virtual/range {p0 .. p2}, Lio/sentry/android/replay/h$a;->d(Lio/sentry/r2;Lio/sentry/protocol/r;)Ljava/io/File;

    move-result-object v4

    .line 2
    new-instance v5, Ljava/io/File;

    const-string v6, ".ongoing_segment"

    invoke-direct {v5, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 3
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v6

    const/4 v7, 0x0

    if-nez v6, :cond_37

    .line 4
    invoke-virtual/range {p1 .. p1}, Lio/sentry/r2;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    sget-object v2, Lio/sentry/i2;->DEBUG:Lio/sentry/i2;

    const-string v3, "No ongoing segment found for replay: %s"

    filled-new-array/range {p2 .. p2}, [Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0, v2, v3, v1}, Lio/sentry/ILogger;->c(Lio/sentry/i2;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 5
    invoke-static {v4}, Lio/sentry/util/e;->a(Ljava/io/File;)Z

    return-object v7

    .line 6
    :cond_37
    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    .line 7
    sget-object v8, LK4/c;->b:Ljava/nio/charset/Charset;

    .line 8
    new-instance v9, Ljava/io/InputStreamReader;

    new-instance v10, Ljava/io/FileInputStream;

    invoke-direct {v10, v5}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v9, v10, v8}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    new-instance v5, Ljava/io/BufferedReader;

    const/16 v8, 0x2000

    invoke-direct {v5, v9, v8}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    :try_start_4f
    invoke-static {v5}, Lz4/o;->c(Ljava/io/BufferedReader;)LJ4/e;

    move-result-object v8

    .line 9
    invoke-interface {v8}, LJ4/e;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_57
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v9, :cond_96

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 10
    move-object v12, v9

    check-cast v12, Ljava/lang/String;

    .line 11
    const-string v9, "="

    filled-new-array {v9}, [Ljava/lang/String;

    move-result-object v13

    const/16 v16, 0x2

    const/16 v17, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x2

    invoke-static/range {v12 .. v17}, LK4/A;->C0(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 12
    invoke-static {v11, v9}, Lp4/t;->a(Ljava/lang/Object;Ljava/lang/Object;)Lp4/n;

    move-result-object v9

    .line 13
    invoke-virtual {v9}, Lp4/n;->c()Ljava/lang/Object;

    move-result-object v10

    invoke-virtual {v9}, Lp4/n;->d()Ljava/lang/Object;

    move-result-object v9

    invoke-interface {v6, v10, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_91
    .catchall {:try_start_4f .. :try_end_91} :catchall_92

    goto :goto_57

    :catchall_92
    move-exception v0

    move-object v1, v0

    goto/16 :goto_240

    .line 14
    :cond_96
    invoke-static {v5, v7}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 15
    const-string v5, "config.height"

    invoke-virtual {v6, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_a8

    invoke-static {v5}, LK4/w;->p(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    goto :goto_a9

    :cond_a8
    move-object v5, v7

    .line 16
    :goto_a9
    const-string v8, "config.width"

    invoke-virtual {v6, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    if-eqz v8, :cond_b8

    invoke-static {v8}, LK4/w;->p(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    goto :goto_b9

    :cond_b8
    move-object v8, v7

    .line 17
    :goto_b9
    const-string v9, "config.frame-rate"

    invoke-virtual {v6, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    if-eqz v9, :cond_c8

    invoke-static {v9}, LK4/w;->p(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    goto :goto_c9

    :cond_c8
    move-object v9, v7

    .line 18
    :goto_c9
    const-string v12, "config.bit-rate"

    invoke-virtual {v6, v12}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    if-eqz v12, :cond_d8

    invoke-static {v12}, LK4/w;->p(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v12

    goto :goto_d9

    :cond_d8
    move-object v12, v7

    .line 19
    :goto_d9
    const-string v13, "segment.id"

    invoke-virtual {v6, v13}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    if-eqz v13, :cond_e8

    invoke-static {v13}, LK4/w;->p(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v13

    goto :goto_e9

    :cond_e8
    move-object v13, v7

    .line 20
    :goto_e9
    :try_start_e9
    const-string v14, "segment.timestamp"

    invoke-virtual {v6, v14}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    if-nez v14, :cond_f4

    move-object v14, v3

    :cond_f4
    invoke-static {v14}, Lio/sentry/j;->e(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v14
    :try_end_f8
    .catchall {:try_start_e9 .. :try_end_f8} :catchall_f9

    goto :goto_fa

    :catchall_f9
    move-object v14, v7

    .line 21
    :goto_fa
    :try_start_fa
    const-string v15, "replay.type"

    invoke-virtual {v6, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    if-nez v15, :cond_105

    goto :goto_106

    :cond_105
    move-object v3, v15

    :goto_106
    invoke-static {v3}, Lio/sentry/s2$b;->valueOf(Ljava/lang/String;)Lio/sentry/s2$b;

    move-result-object v3
    :try_end_10a
    .catchall {:try_start_fa .. :try_end_10a} :catchall_10b

    goto :goto_10c

    :catchall_10b
    move-object v3, v7

    :goto_10c
    if-eqz v5, :cond_22d

    if-eqz v8, :cond_22d

    if-eqz v9, :cond_22d

    if-eqz v12, :cond_22d

    if-eqz v13, :cond_22d

    const/4 v15, -0x1

    .line 22
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v11

    if-eq v11, v15, :cond_22d

    if-eqz v14, :cond_22d

    if-nez v3, :cond_123

    goto/16 :goto_22d

    .line 23
    :cond_123
    new-instance v11, Lio/sentry/android/replay/u;

    .line 24
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v18

    .line 25
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v19

    .line 26
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v22

    .line 27
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v23

    const/high16 v20, 0x3f800000    # 1.0f

    const/high16 v21, 0x3f800000    # 1.0f

    move-object/from16 v17, v11

    .line 28
    invoke-direct/range {v17 .. v23}, Lio/sentry/android/replay/u;-><init>(IIFFII)V

    if-eqz v2, :cond_148

    .line 29
    invoke-interface {v2, v1}, LB4/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lio/sentry/android/replay/h;

    if-nez v2, :cond_14d

    :cond_148
    new-instance v2, Lio/sentry/android/replay/h;

    invoke-direct {v2, v0, v1}, Lio/sentry/android/replay/h;-><init>(Lio/sentry/r2;Lio/sentry/protocol/r;)V

    .line 30
    :cond_14d
    invoke-virtual {v2}, Lio/sentry/android/replay/h;->I0()Ljava/io/File;

    move-result-object v5

    if-eqz v5, :cond_15b

    new-instance v8, Lio/sentry/android/replay/g;

    invoke-direct {v8, v2}, Lio/sentry/android/replay/g;-><init>(Lio/sentry/android/replay/h;)V

    invoke-virtual {v5, v8}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    .line 31
    :cond_15b
    invoke-virtual {v2}, Lio/sentry/android/replay/h;->m0()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_178

    .line 32
    invoke-virtual/range {p1 .. p1}, Lio/sentry/r2;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    .line 33
    sget-object v2, Lio/sentry/i2;->DEBUG:Lio/sentry/i2;

    .line 34
    const-string v3, "No frames found for replay: %s, deleting the replay"

    .line 35
    filled-new-array/range {p2 .. p2}, [Ljava/lang/Object;

    move-result-object v1

    .line 36
    invoke-interface {v0, v2, v3, v1}, Lio/sentry/ILogger;->c(Lio/sentry/i2;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    invoke-static {v4}, Lio/sentry/util/e;->a(Ljava/io/File;)Z

    return-object v7

    .line 38
    :cond_178
    invoke-virtual {v2}, Lio/sentry/android/replay/h;->m0()Ljava/util/List;

    move-result-object v1

    .line 39
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-le v4, v10, :cond_18a

    new-instance v4, Lio/sentry/android/replay/h$a$a;

    invoke-direct {v4}, Lio/sentry/android/replay/h$a$a;-><init>()V

    invoke-static {v1, v4}, Lq4/s;->t(Ljava/util/List;Ljava/util/Comparator;)V

    .line 40
    :cond_18a
    sget-object v1, Lio/sentry/s2$b;->SESSION:Lio/sentry/s2$b;

    if-ne v3, v1, :cond_195

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v4

    move/from16 v19, v4

    goto :goto_197

    :cond_195
    const/16 v19, 0x0

    :goto_197
    if-ne v3, v1, :cond_19c

    :goto_199
    move-object/from16 v18, v14

    goto :goto_1b4

    .line 41
    :cond_19c
    invoke-virtual {v2}, Lio/sentry/android/replay/h;->m0()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Lq4/w;->J(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lio/sentry/android/replay/i;

    invoke-virtual {v1}, Lio/sentry/android/replay/i;->c()J

    move-result-wide v4

    invoke-static {v4, v5}, Lio/sentry/j;->d(J)Ljava/util/Date;

    move-result-object v14

    .line 42
    const-string v1, "{\n                // in \u2026.timestamp)\n            }"

    invoke-static {v14, v1}, Lkotlin/jvm/internal/s;->e(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_199

    .line 43
    :goto_1b4
    invoke-virtual {v2}, Lio/sentry/android/replay/h;->m0()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Lq4/w;->S(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lio/sentry/android/replay/i;

    invoke-virtual {v1}, Lio/sentry/android/replay/i;->c()J

    move-result-wide v4

    invoke-virtual/range {v18 .. v18}, Ljava/util/Date;->getTime()J

    move-result-wide v12

    sub-long/2addr v4, v12

    const/16 v1, 0x3e8

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v8

    div-int/2addr v1, v8

    int-to-long v8, v1

    add-long v20, v4, v8

    .line 44
    const-string v1, "replay.recording"

    invoke-virtual {v6, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_207

    .line 45
    new-instance v4, Ljava/io/StringReader;

    invoke-direct {v4, v1}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    .line 46
    invoke-virtual/range {p1 .. p1}, Lio/sentry/r2;->getSerializer()Lio/sentry/Z;

    move-result-object v0

    const-class v1, Lio/sentry/a1;

    invoke-interface {v0, v4, v1}, Lio/sentry/Z;->c(Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lio/sentry/a1;

    if-eqz v0, :cond_1f3

    .line 47
    invoke-virtual {v0}, Lio/sentry/a1;->a()Ljava/util/List;

    move-result-object v1

    goto :goto_1f4

    :cond_1f3
    move-object v1, v7

    :goto_1f4
    if-eqz v1, :cond_204

    .line 48
    new-instance v7, Ljava/util/LinkedList;

    invoke-virtual {v0}, Lio/sentry/a1;->a()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/s;->c(Ljava/lang/Object;)V

    check-cast v0, Ljava/util/Collection;

    invoke-direct {v7, v0}, Ljava/util/LinkedList;-><init>(Ljava/util/Collection;)V

    :cond_204
    if-eqz v7, :cond_207

    goto :goto_20b

    .line 49
    :cond_207
    invoke-static {}, Lq4/o;->h()Ljava/util/List;

    move-result-object v7

    .line 50
    :goto_20b
    new-instance v0, Lio/sentry/android/replay/c;

    .line 51
    const-string v1, "replay.screen-at-start"

    invoke-virtual {v6, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v23, v1

    check-cast v23, Ljava/lang/String;

    .line 52
    check-cast v7, Ljava/lang/Iterable;

    .line 53
    new-instance v1, Lio/sentry/android/replay/h$a$b;

    invoke-direct {v1}, Lio/sentry/android/replay/h$a$b;-><init>()V

    invoke-static {v7, v1}, Lq4/w;->a0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v24

    move-object v15, v0

    move-object/from16 v16, v11

    move-object/from16 v17, v2

    move-object/from16 v22, v3

    .line 54
    invoke-direct/range {v15 .. v24}, Lio/sentry/android/replay/c;-><init>(Lio/sentry/android/replay/u;Lio/sentry/android/replay/h;Ljava/util/Date;IJLio/sentry/s2$b;Ljava/lang/String;Ljava/util/List;)V

    return-object v0

    .line 55
    :cond_22d
    :goto_22d
    invoke-virtual/range {p1 .. p1}, Lio/sentry/r2;->getLogger()Lio/sentry/ILogger;

    move-result-object v0

    .line 56
    sget-object v2, Lio/sentry/i2;->DEBUG:Lio/sentry/i2;

    .line 57
    const-string v3, "Incorrect segment values found for replay: %s, deleting the replay"

    .line 58
    filled-new-array/range {p2 .. p2}, [Ljava/lang/Object;

    move-result-object v1

    .line 59
    invoke-interface {v0, v2, v3, v1}, Lio/sentry/ILogger;->c(Lio/sentry/i2;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 60
    invoke-static {v4}, Lio/sentry/util/e;->a(Ljava/io/File;)Z

    return-object v7

    .line 61
    :goto_240
    :try_start_240
    throw v1
    :try_end_241
    .catchall {:try_start_240 .. :try_end_241} :catchall_241

    :catchall_241
    move-exception v0

    move-object v2, v0

    invoke-static {v5, v1}, Lz4/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public final d(Lio/sentry/r2;Lio/sentry/protocol/r;)Ljava/io/File;
    .registers 6

    .line 1
    const-string v0, "options"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "replayId"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Lio/sentry/r2;->getCacheDirPath()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_38

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_17

    .line 22
    .line 23
    goto :goto_38

    .line 24
    :cond_17
    new-instance v0, Ljava/io/File;

    .line 25
    .line 26
    invoke-virtual {p1}, Lio/sentry/r2;->getCacheDirPath()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-static {p1}, Lkotlin/jvm/internal/s;->c(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    new-instance v1, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 36
    .line 37
    .line 38
    const-string v2, "replay_"

    .line 39
    .line 40
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-direct {v0, p1, p2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 54
    .line 55
    .line 56
    goto :goto_47

    .line 57
    :cond_38
    :goto_38
    invoke-virtual {p1}, Lio/sentry/r2;->getLogger()Lio/sentry/ILogger;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    sget-object p2, Lio/sentry/i2;->WARNING:Lio/sentry/i2;

    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    new-array v0, v0, [Ljava/lang/Object;

    .line 65
    .line 66
    const-string v1, "SentryOptions.cacheDirPath is not set, session replay is no-op"

    .line 67
    .line 68
    invoke-interface {p1, p2, v1, v0}, Lio/sentry/ILogger;->c(Lio/sentry/i2;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    :goto_47
    return-object v0
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method
