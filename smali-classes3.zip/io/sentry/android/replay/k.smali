.class public final synthetic Lio/sentry/android/replay/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/f1;


# instance fields
.field public final synthetic a:Lkotlin/jvm/internal/I;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/I;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lio/sentry/android/replay/k;->a:Lkotlin/jvm/internal/I;

    return-void
.end method


# virtual methods
.method public final a(Lio/sentry/V;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/replay/k;->a:Lkotlin/jvm/internal/I;

    invoke-static {v0, p1}, Lio/sentry/android/replay/ReplayIntegration;->V(Lkotlin/jvm/internal/I;Lio/sentry/V;)V

    return-void
.end method
