.class public final synthetic Lio/sentry/android/replay/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lio/sentry/android/replay/y;


# direct methods
.method public synthetic constructor <init>(Lio/sentry/android/replay/y;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lio/sentry/android/replay/x;->a:Lio/sentry/android/replay/y;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/replay/x;->a:Lio/sentry/android/replay/y;

    invoke-static {v0}, Lio/sentry/android/replay/y;->l(Lio/sentry/android/replay/y;)V

    return-void
.end method
