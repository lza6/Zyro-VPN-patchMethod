.class public final synthetic Lio/sentry/android/replay/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lio/sentry/android/replay/s;

.field public final synthetic b:Lio/sentry/android/replay/viewhierarchy/b;


# direct methods
.method public synthetic constructor <init>(Lio/sentry/android/replay/s;Lio/sentry/android/replay/viewhierarchy/b;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lio/sentry/android/replay/r;->a:Lio/sentry/android/replay/s;

    iput-object p2, p0, Lio/sentry/android/replay/r;->b:Lio/sentry/android/replay/viewhierarchy/b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/replay/r;->a:Lio/sentry/android/replay/s;

    iget-object v1, p0, Lio/sentry/android/replay/r;->b:Lio/sentry/android/replay/viewhierarchy/b;

    invoke-static {v0, v1}, Lio/sentry/android/replay/s;->b(Lio/sentry/android/replay/s;Lio/sentry/android/replay/viewhierarchy/b;)V

    return-void
.end method
