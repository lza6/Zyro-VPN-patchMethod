.class public interface abstract Lio/sentry/android/replay/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Landroid/view/View;Z)V
.end method
