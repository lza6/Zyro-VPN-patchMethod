.class public interface abstract LE4/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getValue(Ljava/lang/Object;LI4/i;)Ljava/lang/Object;
.end method
