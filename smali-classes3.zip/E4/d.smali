.class public interface abstract LE4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/c;


# virtual methods
.method public abstract getValue(Ljava/lang/Object;LI4/i;)Ljava/lang/Object;
.end method

.method public abstract setValue(Ljava/lang/Object;LI4/i;Ljava/lang/Object;)V
.end method
