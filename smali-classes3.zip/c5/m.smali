.class public interface abstract Lc5/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La5/f;
.implements La5/d;


# virtual methods
.method public abstract c()Lc5/a;
.end method

.method public abstract i(Lc5/h;)V
.end method
