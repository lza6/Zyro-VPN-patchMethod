.class public interface abstract Lc5/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La5/e;
.implements La5/c;


# virtual methods
.method public abstract c()Lc5/a;
.end method

.method public abstract n()Lc5/h;
.end method
