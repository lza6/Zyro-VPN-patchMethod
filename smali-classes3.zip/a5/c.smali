.class public interface abstract La5/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La5/c$a;
    }
.end annotation


# virtual methods
.method public abstract A(LZ4/f;I)J
.end method

.method public abstract B(LZ4/f;I)D
.end method

.method public abstract E(LZ4/f;I)C
.end method

.method public abstract G(LZ4/f;ILX4/b;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract a()Le5/b;
.end method

.method public abstract d(LZ4/f;)V
.end method

.method public abstract f(LZ4/f;I)S
.end method

.method public abstract g(LZ4/f;I)Z
.end method

.method public abstract i(LZ4/f;I)Ljava/lang/String;
.end method

.method public abstract j(LZ4/f;I)B
.end method

.method public abstract k(LZ4/f;I)La5/e;
.end method

.method public abstract l(LZ4/f;I)F
.end method

.method public abstract q(LZ4/f;I)I
.end method

.method public abstract t(LZ4/f;)I
.end method

.method public abstract v()Z
.end method

.method public abstract w(LZ4/f;)I
.end method

.method public abstract y(LZ4/f;ILX4/b;Ljava/lang/Object;)Ljava/lang/Object;
.end method
