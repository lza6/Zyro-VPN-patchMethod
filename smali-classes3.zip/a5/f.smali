.class public interface abstract La5/f;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La5/f$a;
    }
.end annotation


# virtual methods
.method public abstract A(I)V
.end method

.method public abstract D(LX4/k;Ljava/lang/Object;)V
.end method

.method public abstract E(J)V
.end method

.method public abstract F(LZ4/f;I)La5/d;
.end method

.method public abstract G(Ljava/lang/String;)V
.end method

.method public abstract a()Le5/b;
.end method

.method public abstract b(LZ4/f;)La5/d;
.end method

.method public abstract e()V
.end method

.method public abstract g(D)V
.end method

.method public abstract h(S)V
.end method

.method public abstract k(B)V
.end method

.method public abstract l(Z)V
.end method

.method public abstract n(F)V
.end method

.method public abstract p(C)V
.end method

.method public abstract q()V
.end method

.method public abstract t(LZ4/f;I)V
.end method

.method public abstract w(LZ4/f;)La5/f;
.end method
