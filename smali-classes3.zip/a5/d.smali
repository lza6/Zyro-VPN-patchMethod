.class public interface abstract La5/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La5/d$a;
    }
.end annotation


# virtual methods
.method public abstract B(LZ4/f;IZ)V
.end method

.method public abstract C(LZ4/f;ID)V
.end method

.method public abstract d(LZ4/f;)V
.end method

.method public abstract f(LZ4/f;II)V
.end method

.method public abstract j(LZ4/f;ILjava/lang/String;)V
.end method

.method public abstract m(LZ4/f;IJ)V
.end method

.method public abstract o(LZ4/f;IS)V
.end method

.method public abstract r(LZ4/f;IF)V
.end method

.method public abstract s(LZ4/f;ILX4/k;Ljava/lang/Object;)V
.end method

.method public abstract u(LZ4/f;IB)V
.end method

.method public abstract v(LZ4/f;I)La5/f;
.end method

.method public abstract x(LZ4/f;ILX4/k;Ljava/lang/Object;)V
.end method

.method public abstract y(LZ4/f;IC)V
.end method

.method public abstract z(LZ4/f;I)Z
.end method
