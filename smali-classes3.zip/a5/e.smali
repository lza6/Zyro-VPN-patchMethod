.class public interface abstract La5/e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La5/e$a;
    }
.end annotation


# virtual methods
.method public abstract C()S
.end method

.method public abstract D()F
.end method

.method public abstract F()D
.end method

.method public abstract H(LZ4/f;)La5/e;
.end method

.method public abstract a()Le5/b;
.end method

.method public abstract b(LZ4/f;)La5/c;
.end method

.method public abstract e()Z
.end method

.method public abstract h()C
.end method

.method public abstract m(LX4/b;)Ljava/lang/Object;
.end method

.method public abstract o()I
.end method

.method public abstract p()Ljava/lang/Void;
.end method

.method public abstract r()Ljava/lang/String;
.end method

.method public abstract s()J
.end method

.method public abstract u()Z
.end method

.method public abstract x(LZ4/f;)I
.end method

.method public abstract z()B
.end method
