.class public interface abstract Lb5/K;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LX4/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb5/K$a;
    }
.end annotation


# virtual methods
.method public abstract childSerializers()[LX4/c;
.end method

.method public abstract typeParametersSerializers()[LX4/c;
.end method
