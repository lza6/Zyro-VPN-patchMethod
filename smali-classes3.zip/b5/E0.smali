.class public interface abstract Lb5/E0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LI4/c;)LX4/c;
.end method
