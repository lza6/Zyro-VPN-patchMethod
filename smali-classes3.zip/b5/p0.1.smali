.class public interface abstract Lb5/p0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LI4/c;Ljava/util/List;)Ljava/lang/Object;
.end method
