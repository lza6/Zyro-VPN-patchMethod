.class public interface abstract LI4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/i;
.implements LB4/a;


# virtual methods
.method public abstract get()Ljava/lang/Object;
.end method
