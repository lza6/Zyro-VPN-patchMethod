.class public interface abstract LI4/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/a;


# virtual methods
.method public abstract b()Z
.end method

.method public abstract d()Ljava/util/List;
.end method

.method public abstract e()LI4/e;
.end method
