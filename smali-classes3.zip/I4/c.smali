.class public interface abstract LI4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/f;
.implements LI4/a;
.implements LI4/e;


# virtual methods
.method public abstract a()Ljava/lang/String;
.end method

.method public abstract c()Ljava/lang/String;
.end method

.method public abstract f(Ljava/lang/Object;)Z
.end method
