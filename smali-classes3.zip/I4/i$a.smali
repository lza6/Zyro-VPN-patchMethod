.class public interface abstract LI4/i$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LI4/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
