.class public interface abstract LI4/k$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/i$a;
.implements LB4/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LI4/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
