.class public interface abstract LI4/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/i;
.implements LB4/l;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LI4/k$a;
    }
.end annotation


# virtual methods
.method public abstract get(Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract getDelegate(Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract getGetter()LI4/k$a;
.end method
