.class public interface abstract LI4/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/i;
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LI4/l$a;
    }
.end annotation


# virtual methods
.method public abstract getGetter()LI4/l$a;
.end method

.method public abstract j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
