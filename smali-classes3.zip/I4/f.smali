.class public interface abstract LI4/f;
.super Ljava/lang/Object;
.source "SourceFile"
