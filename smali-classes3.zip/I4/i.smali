.class public interface abstract LI4/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI4/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LI4/i$a;
    }
.end annotation


# virtual methods
.method public abstract isConst()Z
.end method

.method public abstract isLateinit()Z
.end method
