.class public interface abstract LB4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/Function;


# virtual methods
.method public abstract invoke()Ljava/lang/Object;
.end method
