.class public interface abstract LB4/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/Function;


# virtual methods
.method public abstract invoke(Ljava/lang/Object;)Ljava/lang/Object;
.end method
