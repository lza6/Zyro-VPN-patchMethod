.class public final synthetic Li5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh5/r$c;


# instance fields
.field public final synthetic a:Lh5/r;


# direct methods
.method public synthetic constructor <init>(Lh5/r;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li5/b;->a:Lh5/r;

    return-void
.end method


# virtual methods
.method public final a(Lh5/e;)Lh5/r;
    .registers 3

    .line 1
    iget-object v0, p0, Li5/b;->a:Lh5/r;

    invoke-static {v0, p1}, Li5/d;->b(Lh5/r;Lh5/e;)Lh5/r;

    move-result-object p1

    return-object p1
.end method
