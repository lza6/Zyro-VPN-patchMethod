.class public abstract LD4/a;
.super Ljava/lang/Object;
.source "SourceFile"
