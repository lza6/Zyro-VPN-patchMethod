.class public final synthetic Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda6;->f$0:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .registers 3

    iget-object v0, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda6;->f$0:Landroid/widget/LinearLayout;

    invoke-static {v0, p1}, Lcom/Epic/custom/dialog/Customdialog;->lambda$zenx$4(Landroid/widget/LinearLayout;Landroid/content/DialogInterface;)V

    return-void
.end method
