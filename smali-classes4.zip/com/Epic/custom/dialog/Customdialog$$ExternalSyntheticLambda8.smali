.class public final synthetic Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Activity;

.field public final synthetic f$1:Landroid/graphics/Typeface;

.field public final synthetic f$2:Landroid/graphics/Typeface;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$0:Landroid/app/Activity;

    iput-object p2, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$1:Landroid/graphics/Typeface;

    iput-object p3, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$2:Landroid/graphics/Typeface;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    iget-object v0, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$0:Landroid/app/Activity;

    iget-object v1, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$1:Landroid/graphics/Typeface;

    iget-object v2, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;->f$2:Landroid/graphics/Typeface;

    invoke-static {v0, v1, v2, p1}, Lcom/Epic/custom/dialog/Customdialog;->lambda$zenx$10(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;Landroid/view/View;)V

    return-void
.end method
