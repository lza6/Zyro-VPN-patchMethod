.class public Lcom/Epic/custom/dialog/Customdialog;
.super Ljava/lang/Object;
.source "Customdialog.java"


# static fields
.field private static final KEY_DONT_SHOW:Ljava/lang/String; = "dont_show_dialog"

.field private static final PREFS_NAME:Ljava/lang/String; = "zenx_prefs"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1282
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static animateIn(Landroid/view/View;)V
    .registers 4
    .param p0, "root"    # Landroid/view/View;

    .line 1851
    const v0, 0x3f59999a    # 0.85f

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    .line 1852
    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    .line 1853
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    .line 1854
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1855
    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1856
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1857
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1858
    const-wide/16 v1, 0x118

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v1}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    .line 1859
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1860
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 1861
    return-void
.end method

.method private static animateOut(Landroid/view/View;Ljava/lang/Runnable;)V
    .registers 5
    .param p0, "root"    # Landroid/view/View;
    .param p1, "endAction"    # Ljava/lang/Runnable;

    .line 1864
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1865
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1866
    const v1, 0x3f59999a    # 0.85f

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1867
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1868
    const-wide/16 v1, 0xc8

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v1}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    .line 1869
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1870
    invoke-virtual {v0, p1}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 1871
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 1872
    return-void
.end method

.method private static createAppCard(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .registers 24
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "assetName"    # Ljava/lang/String;
    .param p2, "appName"    # Ljava/lang/String;
    .param p3, "link"    # Ljava/lang/String;

    .line 1768
    move-object/from16 v1, p0

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v0

    .line 1769
    .local v2, "card":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1770
    const/16 v0, 0x10

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1773
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 1774
    const/high16 v4, 0x43960000    # 300.0f

    invoke-static {v1, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    .line 1775
    const/high16 v5, 0x42a00000    # 80.0f

    invoke-static {v1, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    invoke-direct {v0, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v0

    .line 1777
    .local v4, "lp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v5, 0x41400000    # 12.0f

    invoke-static {v1, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    invoke-virtual {v4, v3, v3, v0, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1778
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1780
    invoke-static {v1, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v6

    .line 1781
    .local v6, "pad":I
    invoke-virtual {v2, v6, v6, v6, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1784
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v7, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v8, 0x2

    new-array v9, v8, [I

    .line 1786
    const-string v10, "#1A2636"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    aput v10, v9, v3

    const-string v10, "#0A1A2F"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/4 v11, 0x1

    aput v10, v9, v11

    invoke-direct {v0, v7, v9}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v7, v0

    .line 1787
    .local v7, "cardBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v9, 0x41800000    # 16.0f

    invoke-static {v1, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v7, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1788
    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v1, v10}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    const-string v12, "#D3D3D3"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v7, v0, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1789
    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1790
    const/high16 v0, 0x40c00000    # 6.0f

    invoke-static {v1, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setElevation(F)V

    .line 1792
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v12, "fonts/Audiowide-Regular.ttf"

    invoke-static {v0, v12}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v12

    .line 1793
    .local v12, "fontAudiowide":Landroid/graphics/Typeface;
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v13, "fonts/Roboto-Bold.ttf"

    invoke-static {v0, v13}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v13

    .line 1794
    .local v13, "fontRobotoBold":Landroid/graphics/Typeface;
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v14, "fonts/Roboto-Regular.ttf"

    invoke-static {v0, v14}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v14

    .line 1797
    .local v14, "fontRobotoRegular":Landroid/graphics/Typeface;
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object v15, v0

    .line 1798
    .local v15, "icon":Landroid/widget/ImageView;
    const/high16 v0, 0x42400000    # 48.0f

    invoke-static {v1, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v10

    .line 1799
    .local v10, "iconSize":I
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v17, v0

    .line 1800
    .local v17, "iconLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    move-object/from16 v5, v17

    .end local v17    # "iconLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v5, "iconLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v5, v3, v3, v0, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1801
    invoke-virtual {v15, v5}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1802
    :try_start_b5
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0
    :try_end_b9
    .catch Ljava/io/IOException; {:try_start_b5 .. :try_end_b9} :catch_de

    move-object/from16 v3, p1

    :try_start_bb
    invoke-virtual {v0, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0
    :try_end_bf
    .catch Ljava/io/IOException; {:try_start_bb .. :try_end_bf} :catch_dc

    move-object/from16 v18, v0

    .line 1803
    .local v18, "is":Ljava/io/InputStream;
    :try_start_c1
    invoke-static/range {v18 .. v18}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 1804
    .local v0, "bm":Landroid/graphics/Bitmap;
    invoke-virtual {v15, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_c8
    .catchall {:try_start_c1 .. :try_end_c8} :catchall_ce

    .line 1805
    .end local v0    # "bm":Landroid/graphics/Bitmap;
    if-eqz v18, :cond_cd

    :try_start_ca
    invoke-virtual/range {v18 .. v18}, Ljava/io/InputStream;->close()V
    :try_end_cd
    .catch Ljava/io/IOException; {:try_start_ca .. :try_end_cd} :catch_dc

    .line 1807
    .end local v18    # "is":Ljava/io/InputStream;
    :cond_cd
    goto :goto_e4

    .line 1802
    .restart local v18    # "is":Ljava/io/InputStream;
    :catchall_ce
    move-exception v0

    move-object v11, v0

    if-eqz v18, :cond_db

    :try_start_d2
    invoke-virtual/range {v18 .. v18}, Ljava/io/InputStream;->close()V
    :try_end_d5
    .catchall {:try_start_d2 .. :try_end_d5} :catchall_d6

    goto :goto_db

    :catchall_d6
    move-exception v0

    move-object v8, v0

    :try_start_d8
    invoke-virtual {v11, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v2    # "card":Landroid/widget/LinearLayout;
    .end local v4    # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5    # "iconLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6    # "pad":I
    .end local v7    # "cardBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v10    # "iconSize":I
    .end local v12    # "fontAudiowide":Landroid/graphics/Typeface;
    .end local v13    # "fontRobotoBold":Landroid/graphics/Typeface;
    .end local v14    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .end local v15    # "icon":Landroid/widget/ImageView;
    .end local p0    # "activity":Landroid/app/Activity;
    .end local p1    # "assetName":Ljava/lang/String;
    .end local p2    # "appName":Ljava/lang/String;
    .end local p3    # "link":Ljava/lang/String;
    :cond_db
    :goto_db
    throw v11
    :try_end_dc
    .catch Ljava/io/IOException; {:try_start_d8 .. :try_end_dc} :catch_dc

    .line 1805
    .end local v18    # "is":Ljava/io/InputStream;
    .restart local v2    # "card":Landroid/widget/LinearLayout;
    .restart local v4    # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .restart local v5    # "iconLp":Landroid/widget/LinearLayout$LayoutParams;
    .restart local v6    # "pad":I
    .restart local v7    # "cardBg":Landroid/graphics/drawable/GradientDrawable;
    .restart local v10    # "iconSize":I
    .restart local v12    # "fontAudiowide":Landroid/graphics/Typeface;
    .restart local v13    # "fontRobotoBold":Landroid/graphics/Typeface;
    .restart local v14    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .restart local v15    # "icon":Landroid/widget/ImageView;
    .restart local p0    # "activity":Landroid/app/Activity;
    .restart local p1    # "assetName":Ljava/lang/String;
    .restart local p2    # "appName":Ljava/lang/String;
    .restart local p3    # "link":Ljava/lang/String;
    :catch_dc
    move-exception v0

    goto :goto_e1

    :catch_de
    move-exception v0

    move-object/from16 v3, p1

    .line 1806
    .local v0, "e":Ljava/io/IOException;
    :goto_e1
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 1808
    .end local v0    # "e":Ljava/io/IOException;
    :goto_e4
    invoke-virtual {v2, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1811
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1812
    .local v0, "name":Landroid/widget/TextView;
    move-object/from16 v8, p2

    invoke-virtual {v0, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1813
    const/4 v11, -0x1

    invoke-virtual {v0, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1814
    invoke-virtual {v0, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1815
    const/4 v11, 0x2

    invoke-virtual {v0, v11, v9}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1816
    const/4 v9, 0x1

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1817
    sget-object v9, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1819
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    move-object/from16 v16, v4

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    .end local v4    # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .local v16, "lp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-direct {v9, v3, v11, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v4, v9

    .line 1821
    .local v4, "nameLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v9, 0x41000000    # 8.0f

    invoke-static {v1, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v11

    invoke-virtual {v4, v3, v3, v11, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1822
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1823
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1826
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1827
    .local v3, "getNow":Landroid/widget/TextView;
    const-string v11, "\u7acb\u5373\u4e0b\u8f7d"

    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1828
    const/4 v11, -0x1

    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1829
    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1830
    const/high16 v11, 0x41600000    # 14.0f

    const/4 v9, 0x2

    invoke-virtual {v3, v9, v11}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1831
    const/16 v9, 0x11

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setGravity(I)V

    .line 1832
    const/high16 v9, 0x41400000    # 12.0f

    invoke-static {v1, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v11

    move-object/from16 v19, v0

    move-object/from16 v18, v4

    const/high16 v0, 0x41000000    # 8.0f

    .end local v0    # "name":Landroid/widget/TextView;
    .end local v4    # "nameLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v18, "nameLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v19, "name":Landroid/widget/TextView;
    invoke-static {v1, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    invoke-static {v1, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    invoke-static {v1, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    invoke-virtual {v3, v11, v4, v9, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1834
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v4, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v9, 0x2

    new-array v9, v9, [I

    .line 1836
    const-string v11, "#6A11CB"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const/16 v17, 0x0

    aput v11, v9, v17

    const-string v11, "#2575FC"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const/16 v17, 0x1

    aput v11, v9, v17

    invoke-direct {v0, v4, v9}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 1837
    .local v0, "btnBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v4, 0x41600000    # 14.0f

    invoke-static {v1, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1838
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1840
    new-instance v4, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda2;

    move-object/from16 v9, p3

    invoke-direct {v4, v9, v1}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;Landroid/app/Activity;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1845
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1847
    return-object v2
.end method

.method private static dp(Landroid/app/Activity;F)I
    .registers 3
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "dp"    # F

    .line 1874
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float v0, v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method static synthetic lambda$createAppCard$11(Ljava/lang/String;Landroid/app/Activity;Landroid/view/View;)V
    .registers 6
    .param p0, "link"    # Ljava/lang/String;
    .param p1, "activity"    # Landroid/app/Activity;
    .param p2, "v"    # Landroid/view/View;

    .line 1841
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 1842
    .local v0, "browser":Landroid/content/Intent;
    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 1843
    return-void
.end method

.method static synthetic lambda$zenx$0(Landroid/content/SharedPreferences;Landroid/widget/CompoundButton;Z)V
    .registers 5
    .param p0, "prefs"    # Landroid/content/SharedPreferences;
    .param p1, "buttonView"    # Landroid/widget/CompoundButton;
    .param p2, "isChecked"    # Z

    .line 1447
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "dont_show_dialog"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1448
    return-void
.end method

.method static synthetic lambda$zenx$1([ZLandroid/content/SharedPreferences;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 9
    .param p0, "isDismissing"    # [Z
    .param p1, "prefs"    # Landroid/content/SharedPreferences;
    .param p2, "dontShowSwitch"    # Landroid/widget/Switch;
    .param p3, "outer"    # Landroid/widget/LinearLayout;
    .param p4, "dialog"    # Landroid/app/Dialog;
    .param p5, "v"    # Landroid/view/View;

    .line 1502
    const/4 v0, 0x0

    aget-boolean v1, p0, v0

    if-eqz v1, :cond_6

    return-void

    .line 1503
    :cond_6
    const/4 v1, 0x1

    aput-boolean v1, p0, v0

    .line 1505
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "dont_show_dialog"

    invoke-virtual {p2}, Landroid/widget/Switch;->isChecked()Z

    move-result v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1506
    invoke-static {p4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;

    invoke-direct {v0, p4}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;-><init>(Landroid/app/Dialog;)V

    invoke-static {p3, v0}, Lcom/Epic/custom/dialog/Customdialog;->animateOut(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 1507
    return-void
.end method

.method static synthetic lambda$zenx$10(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;Landroid/view/View;)V
    .registers 25
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "fontRobotoBold"    # Landroid/graphics/Typeface;
    .param p2, "fontRobotoRegular"    # Landroid/graphics/Typeface;
    .param p3, "v"    # Landroid/view/View;

    .line 1652
    move-object/from16 v0, p0

    new-instance v1, Landroid/app/Dialog;

    invoke-direct {v1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 1653
    .local v1, "cardsDialog":Landroid/app/Dialog;
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 1654
    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 1656
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1657
    .local v3, "cardsOuter":Landroid/widget/LinearLayout;
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1658
    const/high16 v4, 0x41800000    # 16.0f

    invoke-static {v0, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    .line 1659
    .local v5, "pad":I
    invoke-virtual {v3, v5, v5, v5, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1662
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1663
    .local v6, "bg":Landroid/graphics/drawable/GradientDrawable;
    const-string v7, "#E60F1113"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1664
    const/high16 v7, 0x41d00000    # 26.0f

    invoke-static {v0, v7}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1665
    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v0, v7}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v8

    const-string v9, "#2575FC"

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1666
    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1669
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1670
    .local v8, "cardsTitle":Landroid/widget/TextView;
    const-string v9, "\u7cbe\u9009\u8d44\u6e90"

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1671
    const/high16 v9, 0x41900000    # 18.0f

    const/4 v10, 0x2

    invoke-virtual {v8, v10, v9}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1672
    move-object/from16 v9, p1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1674
    const/4 v11, -0x1

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1675
    const/16 v12, 0x11

    invoke-virtual {v8, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 1676
    const/high16 v13, 0x41400000    # 12.0f

    invoke-static {v0, v13}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v8, v15, v15, v15, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1677
    invoke-virtual {v3, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1680
    new-instance v14, Landroid/widget/ScrollView;

    invoke-direct {v14, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 1681
    .local v14, "listScroll":Landroid/widget/ScrollView;
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 1682
    const/high16 v12, 0x43aa0000    # 340.0f

    invoke-static {v0, v12}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v12

    invoke-direct {v7, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1683
    .local v7, "listScrollLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v14, v7}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1685
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1686
    .local v12, "list":Landroid/widget/LinearLayout;
    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1687
    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1688
    invoke-virtual {v12, v15, v15, v15, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1691
    const/16 v11, 0x8

    new-array v11, v11, [[Ljava/lang/String;

    const-string v4, "CapCut Pro"

    const-string v13, "https://t.me/bpapk/16356"

    const-string v10, "apps/capcut.png"

    filled-new-array {v10, v4, v13}, [Ljava/lang/String;

    move-result-object v4

    aput-object v4, v11, v15

    const-string v4, "Spotify"

    const-string v10, "https://t.me/bpapk/15797"

    const-string v13, "apps/spotify.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    aput-object v4, v11, v2

    const-string v4, "Telegram"

    const-string v10, "https://t.me/bpapk/16316"

    const-string v13, "apps/telegram.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x2

    aput-object v4, v11, v10

    const-string v4, "YouTube"

    const-string v10, "https://t.me/bpapk/16303"

    const-string v13, "apps/youtube.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x3

    aput-object v4, v11, v10

    const-string v4, "TikTok"

    const-string v10, "https://t.me/bpapk/16258"

    const-string v13, "apps/TikTok.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x4

    aput-object v4, v11, v10

    const-string v4, "X"

    const-string v10, "https://t.me/bpapk/16390"

    const-string v13, "apps/X.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x5

    aput-object v4, v11, v10

    const-string v4, "bilibili"

    const-string v10, "https://t.me/bpapk/15478"

    const-string v13, "apps/bilibili.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x6

    aput-object v4, v11, v10

    const-string v4, "kuwo"

    const-string v10, "https://t.me/bpapk/15864"

    const-string v13, "apps/kuwo.png"

    filled-new-array {v13, v4, v10}, [Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x7

    aput-object v4, v11, v10

    move-object v4, v11

    .line 1703
    .local v4, "apps":[[Ljava/lang/String;
    array-length v10, v4

    const/4 v11, 0x0

    :goto_102
    if-ge v11, v10, :cond_136

    aget-object v13, v4, v11

    .line 1704
    .local v13, "app":[Ljava/lang/String;
    move-object/from16 v20, v4

    .end local v4    # "apps":[[Ljava/lang/String;
    .local v20, "apps":[[Ljava/lang/String;
    aget-object v4, v13, v15

    aget-object v15, v13, v2

    const/16 v19, 0x2

    aget-object v2, v13, v19

    invoke-static {v0, v4, v15, v2}, Lcom/Epic/custom/dialog/Customdialog;->createAppCard(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    .line 1706
    .local v2, "card":Landroid/widget/LinearLayout;
    nop

    .line 1707
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 1708
    .local v4, "cardLp":Landroid/widget/LinearLayout$LayoutParams;
    move/from16 v18, v5

    const/high16 v15, 0x41400000    # 12.0f

    .end local v5    # "pad":I
    .local v18, "pad":I
    invoke-static {v0, v15}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    const/4 v15, 0x0

    invoke-virtual {v4, v15, v15, v15, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1709
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1711
    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1703
    .end local v2    # "card":Landroid/widget/LinearLayout;
    .end local v4    # "cardLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "app":[Ljava/lang/String;
    add-int/lit8 v11, v11, 0x1

    move/from16 v5, v18

    move-object/from16 v4, v20

    const/4 v2, 0x1

    const/4 v15, 0x0

    goto :goto_102

    .line 1714
    .end local v18    # "pad":I
    .end local v20    # "apps":[[Ljava/lang/String;
    .local v4, "apps":[[Ljava/lang/String;
    .restart local v5    # "pad":I
    :cond_136
    move-object/from16 v20, v4

    move/from16 v18, v5

    .end local v4    # "apps":[[Ljava/lang/String;
    .end local v5    # "pad":I
    .restart local v18    # "pad":I
    .restart local v20    # "apps":[[Ljava/lang/String;
    invoke-virtual {v14, v12}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1715
    invoke-virtual {v3, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1718
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1719
    .local v2, "closeCards":Landroid/widget/TextView;
    const-string v4, "\u8fdb\u5165\u8f6f\u4ef6"

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1720
    move-object/from16 v4, p2

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1721
    const/high16 v5, 0x41800000    # 16.0f

    const/4 v10, 0x2

    invoke-virtual {v2, v10, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1722
    const/4 v5, -0x1

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1723
    const/16 v5, 0x11

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 1724
    const/high16 v5, 0x41600000    # 14.0f

    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v10

    const/high16 v11, 0x41200000    # 10.0f

    invoke-static {v0, v11}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v13

    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v15

    invoke-static {v0, v11}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v11

    invoke-virtual {v2, v10, v13, v15, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1726
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1727
    .local v10, "closeCardsBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v10, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1728
    const-string v5, "#222428"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v10, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1729
    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    const-string v11, "#D3D3D3"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v5, v11}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1730
    invoke-virtual {v2, v10}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1732
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v5, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1734
    .local v5, "closeCardsLp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v13, 0x11

    iput v13, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1735
    const/high16 v13, 0x41800000    # 16.0f

    invoke-static {v0, v13}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v13

    const/4 v15, 0x0

    invoke-virtual {v5, v15, v13, v15, v15}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1736
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1738
    const/4 v13, 0x1

    new-array v13, v13, [Z

    aput-boolean v15, v13, v15

    .line 1739
    .local v13, "isClosingCards":[Z
    new-instance v15, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda10;

    invoke-direct {v15, v13, v3, v1}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda10;-><init>([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;)V

    invoke-virtual {v2, v15}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1744
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1746
    invoke-virtual {v1, v3}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 1747
    new-instance v15, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda11;

    invoke-direct {v15, v3}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda11;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual {v1, v15}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 1749
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v15

    if-eqz v15, :cond_21e

    .line 1750
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v15

    const v11, 0x106000d

    invoke-virtual {v15, v11}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 1751
    new-instance v11, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v11}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    .line 1752
    .local v11, "lp":Landroid/view/WindowManager$LayoutParams;
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v15

    invoke-virtual {v15}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v15

    invoke-virtual {v11, v15}, Landroid/view/WindowManager$LayoutParams;->copyFrom(Landroid/view/WindowManager$LayoutParams;)I

    .line 1753
    const/4 v15, -0x2

    iput v15, v11, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 1754
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v15

    invoke-virtual {v15, v11}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 1757
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    invoke-virtual {v15}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v15

    iget v15, v15, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 1758
    .local v15, "screenWidth":I
    move-object/from16 v16, v2

    .end local v2    # "closeCards":Landroid/widget/TextView;
    .local v16, "closeCards":Landroid/widget/TextView;
    int-to-float v2, v15

    const v17, 0x3f6147ae    # 0.88f

    mul-float v2, v2, v17

    float-to-int v2, v2

    move-object/from16 v17, v3

    .end local v3    # "cardsOuter":Landroid/widget/LinearLayout;
    .local v17, "cardsOuter":Landroid/widget/LinearLayout;
    const/high16 v3, 0x40800000    # 4.0f

    invoke-static {v0, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    add-int/2addr v2, v3

    .line 1759
    .local v2, "targetWidth":I
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/4 v0, -0x2

    invoke-virtual {v3, v2, v0}, Landroid/view/Window;->setLayout(II)V

    goto :goto_222

    .line 1749
    .end local v11    # "lp":Landroid/view/WindowManager$LayoutParams;
    .end local v15    # "screenWidth":I
    .end local v16    # "closeCards":Landroid/widget/TextView;
    .end local v17    # "cardsOuter":Landroid/widget/LinearLayout;
    .local v2, "closeCards":Landroid/widget/TextView;
    .restart local v3    # "cardsOuter":Landroid/widget/LinearLayout;
    :cond_21e
    move-object/from16 v16, v2

    move-object/from16 v17, v3

    .line 1762
    .end local v2    # "closeCards":Landroid/widget/TextView;
    .end local v3    # "cardsOuter":Landroid/widget/LinearLayout;
    .restart local v16    # "closeCards":Landroid/widget/TextView;
    .restart local v17    # "cardsOuter":Landroid/widget/LinearLayout;
    :goto_222
    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 1763
    return-void
.end method

.method static synthetic lambda$zenx$2(Landroid/app/Dialog;Landroid/app/Activity;)V
    .registers 5
    .param p0, "dialog"    # Landroid/app/Dialog;
    .param p1, "activity"    # Landroid/app/Activity;

    .line 1515
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    .line 1516
    new-instance v0, Landroid/content/Intent;

    .line 1517
    const-string v1, "https://t.me/bpapk"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 1518
    .local v0, "browser":Landroid/content/Intent;
    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 1519
    return-void
.end method

.method static synthetic lambda$zenx$3([ZLandroid/content/SharedPreferences;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/app/Activity;Landroid/view/View;)V
    .registers 10
    .param p0, "isDismissing"    # [Z
    .param p1, "prefs"    # Landroid/content/SharedPreferences;
    .param p2, "dontShowSwitch"    # Landroid/widget/Switch;
    .param p3, "outer"    # Landroid/widget/LinearLayout;
    .param p4, "dialog"    # Landroid/app/Dialog;
    .param p5, "activity"    # Landroid/app/Activity;
    .param p6, "v"    # Landroid/view/View;

    .line 1510
    const/4 v0, 0x0

    aget-boolean v1, p0, v0

    if-eqz v1, :cond_6

    return-void

    .line 1511
    :cond_6
    const/4 v1, 0x1

    aput-boolean v1, p0, v0

    .line 1513
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "dont_show_dialog"

    invoke-virtual {p2}, Landroid/widget/Switch;->isChecked()Z

    move-result v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1514
    new-instance v0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda3;

    invoke-direct {v0, p4, p5}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda3;-><init>(Landroid/app/Dialog;Landroid/app/Activity;)V

    invoke-static {p3, v0}, Lcom/Epic/custom/dialog/Customdialog;->animateOut(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 1520
    return-void
.end method

.method static synthetic lambda$zenx$4(Landroid/widget/LinearLayout;Landroid/content/DialogInterface;)V
    .registers 2
    .param p0, "outer"    # Landroid/widget/LinearLayout;
    .param p1, "d"    # Landroid/content/DialogInterface;

    .line 1527
    invoke-static {p0}, Lcom/Epic/custom/dialog/Customdialog;->animateIn(Landroid/view/View;)V

    return-void
.end method

.method static synthetic lambda$zenx$5([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 6
    .param p0, "isClosingFull"    # [Z
    .param p1, "fullOuter"    # Landroid/widget/LinearLayout;
    .param p2, "fullDialog"    # Landroid/app/Dialog;
    .param p3, "x"    # Landroid/view/View;

    .line 1624
    const/4 v0, 0x0

    aget-boolean v1, p0, v0

    if-eqz v1, :cond_6

    return-void

    .line 1625
    :cond_6
    const/4 v1, 0x1

    aput-boolean v1, p0, v0

    .line 1626
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;

    invoke-direct {v0, p2}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;-><init>(Landroid/app/Dialog;)V

    invoke-static {p1, v0}, Lcom/Epic/custom/dialog/Customdialog;->animateOut(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 1627
    return-void
.end method

.method static synthetic lambda$zenx$6(Landroid/widget/LinearLayout;Landroid/content/DialogInterface;)V
    .registers 2
    .param p0, "fullOuter"    # Landroid/widget/LinearLayout;
    .param p1, "d"    # Landroid/content/DialogInterface;

    .line 1631
    invoke-static {p0}, Lcom/Epic/custom/dialog/Customdialog;->animateIn(Landroid/view/View;)V

    return-void
.end method

.method static synthetic lambda$zenx$7(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;Landroid/view/View;)V
    .registers 22
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "fontRobotoBold"    # Landroid/graphics/Typeface;
    .param p2, "fontRobotoRegular"    # Landroid/graphics/Typeface;
    .param p3, "v"    # Landroid/view/View;

    .line 1551
    move-object/from16 v0, p0

    move-object/from16 v1, p2

    new-instance v2, Landroid/app/Dialog;

    invoke-direct {v2, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 1552
    .local v2, "fullDialog":Landroid/app/Dialog;
    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 1553
    invoke-virtual {v2, v3}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 1555
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1556
    .local v4, "fullOuter":Landroid/widget/LinearLayout;
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1557
    const/high16 v5, 0x41800000    # 16.0f

    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v6

    .line 1558
    .local v6, "pad":I
    invoke-virtual {v4, v6, v6, v6, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1560
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1561
    .local v7, "fullBg":Landroid/graphics/drawable/GradientDrawable;
    const-string v8, "#E60F1113"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1562
    const/high16 v8, 0x41d00000    # 26.0f

    invoke-static {v0, v8}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1563
    const/high16 v8, 0x3f800000    # 1.0f

    invoke-static {v0, v8}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    const-string v10, "#2575FC"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v7, v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1564
    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1567
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1568
    .local v9, "fullTitle":Landroid/widget/TextView;
    const-string v10, "\u516c\u544a\u5927\u5168"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1569
    move-object/from16 v10, p1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1570
    const/high16 v11, 0x41900000    # 18.0f

    const/4 v12, 0x2

    invoke-virtual {v9, v12, v11}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1571
    const/4 v11, -0x1

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1572
    const/16 v13, 0x11

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 1573
    const/high16 v14, 0x41400000    # 12.0f

    invoke-static {v0, v14}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v9, v15, v15, v15, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1574
    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1577
    new-instance v14, Landroid/widget/ScrollView;

    invoke-direct {v14, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 1578
    .local v14, "scroll":Landroid/widget/ScrollView;
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 1579
    const/high16 v15, 0x43aa0000    # 340.0f

    invoke-static {v0, v15}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v15

    invoke-direct {v3, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1580
    .local v3, "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v14, v3}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1582
    new-instance v15, Landroid/widget/TextView;

    invoke-direct {v15, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1583
    .local v15, "fullDesc":Landroid/widget/TextView;
    const-string v8, "\u6b22\u8fce\u4f7f\u7528\n\n\u2022 \u9ad8\u7ea7\u529f\u80fd\u5df2\u89e3\u9501\uff1a\u5728\u9002\u7528\u60c5\u51b5\u4e0b\uff0c\u5e94\u7528\u5185\u8d2d\u4e70\u548c\u8ba2\u9605\u5df2\u9884\u5148\u542f\u7528\u3002\n\n\u2022 \u5df2\u79fb\u9664\u5e7f\u544a\u5e76\u6dfb\u52a0\u989d\u5916\u7684\u81ea\u5b9a\u4e49\u8bbe\u7f6e\uff0c\u4ee5\u589e\u5f3a\u53ef\u7528\u6027\u3002\n\u2022 \u63d0\u4f9b\u591a\u4e2a APK \u7248\u672c\uff08\u7a33\u5b9a\u7248\u3001\u7cbe\u7b80\u7248\u53ca\u4f18\u5316\u7248\uff09\uff0c\u4ee5\u9002\u914d\u4e0d\u540c\u8bbe\u5907\u3002\n\u2022 \u5b89\u5168\u7b2c\u4e00\uff1a\u6587\u4ef6\u5df2\u626b\u63cf\u5e38\u89c1\u5a01\u80c1\uff0c\u4f46\u65e0\u6cd5\u4fdd\u8bc1 100% \u5b89\u5168\u2014\u2014\u5b89\u88c5\u9700\u81ea\u884c\u627f\u62c5\u98ce\u9669\u3002\n\u2022 \u5b9a\u671f\u66f4\u65b0\uff1a\u6211\u4eec\u4f1a\u9891\u7e41\u53d1\u5e03\u7ecf\u8fc7\u6d4b\u8bd5\u7684\u8865\u4e01\u66f4\u65b0\u548c\u9519\u8bef\u4fee\u590d\u3002\n\u2022 \u793e\u533a\u652f\u6301\uff1a\u901a\u8fc7\u70b9\u51fb\u201c\u7acb\u5373\u52a0\u5165\u201d\u6309\u94ae\u52a0\u5165\u793e\u533a\u9891\u9053\uff0c\u53ef\u8bf7\u6c42\u4fee\u6539\u6216\u62a5\u544a\u95ee\u9898\u3002\n\u2022 \u5b89\u88c5\u63d0\u793a\uff1a\u542f\u7528\u672a\u77e5\u6765\u6e90\uff08\u6216\u4f7f\u7528\u5305\u5b89\u88c5\u5668\uff09\uff0c\u5b89\u88c5\u524d\u8bf7\u5907\u4efd\u6570\u636e\uff0c\u5e76\u4f18\u5148\u8fdb\u884c\u65e7\u7248\u672c\u7684\u5e72\u51c0\u5378\u8f7d\u3002\u514d\u8d23\u58f0\u660e\uff1a\u8fd9\u4e9b\u4fee\u6539\u4ec5\u7528\u4e8e\u6559\u80b2\u548c\u6d4b\u8bd5\u76ee\u7684\u3002\u8bf7\u8d1f\u8d23\u4efb\u5730\u5b89\u88c5\u5e76\u9075\u5b88\u5f53\u5730\u6cd5\u5f8b\u3002"

    invoke-virtual {v15, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1594
    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v15, v12, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1595
    invoke-virtual {v15, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1596
    invoke-virtual {v15, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1597
    const/4 v8, 0x0

    const v13, 0x3f99999a    # 1.2f

    invoke-virtual {v15, v8, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 1598
    invoke-virtual {v14, v15}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1599
    invoke-virtual {v4, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1602
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1603
    .local v8, "closeFull":Landroid/widget/TextView;
    const-string v13, "\u8fdb\u5165\u8f6f\u4ef6"

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1604
    invoke-virtual {v8, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1605
    invoke-virtual {v8, v12, v5}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1606
    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1607
    const/16 v11, 0x11

    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 1608
    const/high16 v11, 0x41600000    # 14.0f

    invoke-static {v0, v11}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v12

    const/high16 v13, 0x41200000    # 10.0f

    invoke-static {v0, v13}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    invoke-static {v0, v11}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v1

    invoke-static {v0, v13}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v13

    invoke-virtual {v8, v12, v5, v1, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1610
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1611
    .local v1, "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v0, v11}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1612
    const-string v5, "#222428"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1613
    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v0, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    const-string v11, "#D3D3D3"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v1, v5, v11}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1614
    invoke-virtual {v8, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1616
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v5, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1618
    .local v5, "closeFullLp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v12, 0x11

    iput v12, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1619
    const/high16 v12, 0x41800000    # 16.0f

    invoke-static {v0, v12}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v12

    const/4 v13, 0x0

    invoke-virtual {v5, v13, v12, v13, v13}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1620
    invoke-virtual {v8, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1622
    const/4 v12, 0x1

    new-array v12, v12, [Z

    aput-boolean v13, v12, v13

    .line 1623
    .local v12, "isClosingFull":[Z
    new-instance v13, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;

    invoke-direct {v13, v12, v4, v2}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;-><init>([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;)V

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1628
    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1630
    invoke-virtual {v2, v4}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 1631
    new-instance v13, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda1;

    invoke-direct {v13, v4}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda1;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual {v2, v13}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 1633
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v13

    if-eqz v13, :cond_183

    .line 1634
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v13

    const v11, 0x106000d

    invoke-virtual {v13, v11}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 1635
    new-instance v11, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v11}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    .line 1636
    .local v11, "lp2":Landroid/view/WindowManager$LayoutParams;
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v13

    invoke-virtual {v11, v13}, Landroid/view/WindowManager$LayoutParams;->copyFrom(Landroid/view/WindowManager$LayoutParams;)I

    .line 1637
    const/4 v13, -0x2

    iput v13, v11, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 1638
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v13

    invoke-virtual {v13, v11}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 1641
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    invoke-virtual {v13}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v13

    iget v13, v13, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 1642
    .local v13, "screenWidth2":I
    move-object/from16 v16, v1

    .end local v1    # "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    .local v16, "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    int-to-float v1, v13

    const v17, 0x3f6147ae    # 0.88f

    mul-float v1, v1, v17

    float-to-int v1, v1

    move-object/from16 v17, v3

    .end local v3    # "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v17, "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v3, 0x40800000    # 4.0f

    invoke-static {v0, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    add-int/2addr v1, v3

    .line 1643
    .local v1, "targetWidth2":I
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/4 v0, -0x2

    invoke-virtual {v3, v1, v0}, Landroid/view/Window;->setLayout(II)V

    goto :goto_187

    .line 1633
    .end local v11    # "lp2":Landroid/view/WindowManager$LayoutParams;
    .end local v13    # "screenWidth2":I
    .end local v16    # "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v17    # "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v1, "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    .restart local v3    # "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    :cond_183
    move-object/from16 v16, v1

    move-object/from16 v17, v3

    .line 1646
    .end local v1    # "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v3    # "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    .restart local v16    # "closeFullBg":Landroid/graphics/drawable/GradientDrawable;
    .restart local v17    # "scrollLp":Landroid/widget/LinearLayout$LayoutParams;
    :goto_187
    invoke-virtual {v2}, Landroid/app/Dialog;->show()V

    .line 1647
    return-void
.end method

.method static synthetic lambda$zenx$8([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 6
    .param p0, "isClosingCards"    # [Z
    .param p1, "cardsOuter"    # Landroid/widget/LinearLayout;
    .param p2, "cardsDialog"    # Landroid/app/Dialog;
    .param p3, "x"    # Landroid/view/View;

    .line 1740
    const/4 v0, 0x0

    aget-boolean v1, p0, v0

    if-eqz v1, :cond_6

    return-void

    .line 1741
    :cond_6
    const/4 v1, 0x1

    aput-boolean v1, p0, v0

    .line 1742
    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;

    invoke-direct {v0, p2}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda9;-><init>(Landroid/app/Dialog;)V

    invoke-static {p1, v0}, Lcom/Epic/custom/dialog/Customdialog;->animateOut(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 1743
    return-void
.end method

.method static synthetic lambda$zenx$9(Landroid/widget/LinearLayout;Landroid/content/DialogInterface;)V
    .registers 2
    .param p0, "cardsOuter"    # Landroid/widget/LinearLayout;
    .param p1, "d"    # Landroid/content/DialogInterface;

    .line 1747
    invoke-static {p0}, Lcom/Epic/custom/dialog/Customdialog;->animateIn(Landroid/view/View;)V

    return-void
.end method

.method public static zenx(Landroid/app/Activity;)V
    .registers 50
    .param p0, "activity"    # Landroid/app/Activity;

    .line 1289
    move-object/from16 v8, p0

    const-string v0, "zenx_prefs"

    const/4 v1, 0x0

    invoke-virtual {v8, v0, v1}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v15

    .line 1290
    .local v15, "prefs":Landroid/content/SharedPreferences;
    const-string v0, "dont_show_dialog"

    invoke-interface {v15, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    .line 1291
    .local v7, "dontShow":Z
    if-eqz v7, :cond_12

    return-void

    .line 1293
    :cond_12
    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, v8}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    move-object v6, v0

    .line 1294
    .local v6, "dialog":Landroid/app/Dialog;
    const/4 v2, 0x1

    invoke-virtual {v6, v2}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 1295
    invoke-virtual {v6, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 1296
    invoke-virtual {v6, v1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 1299
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v0

    .line 1300
    .local v5, "outer":Landroid/widget/LinearLayout;
    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1301
    const/high16 v3, 0x41800000    # 16.0f

    invoke-static {v8, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    .line 1302
    .local v4, "outerPadding":I
    invoke-virtual {v5, v4, v4, v4, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1304
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v14, -0x2

    invoke-direct {v0, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1309
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v10, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v11, 0x2

    new-array v12, v11, [I

    .line 1311
    const-string v13, "#0A1A2F"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v16

    aput v16, v12, v1

    const-string v16, "#000000"

    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v17

    aput v17, v12, v2

    invoke-direct {v0, v10, v12}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v12, v0

    .line 1312
    .local v12, "outerBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v0, 0x41d00000    # 26.0f

    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v12, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1313
    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v8, v10}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    const-string v17, "#2575FC"

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v12, v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1314
    invoke-virtual {v5, v12}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1316
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v3, "fonts/Audiowide-Regular.ttf"

    invoke-static {v0, v3}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v3

    .line 1317
    .local v3, "fontAudiowide":Landroid/graphics/Typeface;
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v2, "fonts/Roboto-Bold.ttf"

    invoke-static {v0, v2}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    .line 1318
    .local v2, "fontRobotoBold":Landroid/graphics/Typeface;
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v10, "fonts/Roboto-Regular.ttf"

    invoke-static {v0, v10}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v10

    .line 1321
    .local v10, "fontRobotoRegular":Landroid/graphics/Typeface;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v21, v0

    .line 1322
    .local v21, "header":Landroid/widget/LinearLayout;
    move-object/from16 v11, v21

    .end local v21    # "header":Landroid/widget/LinearLayout;
    .local v11, "header":Landroid/widget/LinearLayout;
    invoke-virtual {v11, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1323
    const/16 v1, 0x10

    invoke-virtual {v11, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1324
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1328
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object/from16 v23, v0

    .line 1329
    .local v23, "logo":Landroid/widget/ImageView;
    const/high16 v0, 0x42700000    # 60.0f

    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v1

    .line 1330
    .local v1, "logoSize":I
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v25, v0

    .line 1331
    .local v25, "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v14, 0x41200000    # 10.0f

    invoke-static {v8, v14}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    move-object/from16 v14, v25

    const/4 v9, 0x0

    .end local v25    # "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v14, "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v14, v9, v9, v0, v9}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1332
    move-object/from16 v9, v23

    .end local v23    # "logo":Landroid/widget/ImageView;
    .local v9, "logo":Landroid/widget/ImageView;
    invoke-virtual {v9, v14}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1333
    :try_start_d1
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0
    :try_end_d5
    .catch Ljava/io/IOException; {:try_start_d1 .. :try_end_d5} :catch_10f

    move/from16 v23, v1

    .end local v1    # "logoSize":I
    .local v23, "logoSize":I
    :try_start_d7
    const-string v1, "image.png"

    invoke-virtual {v0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0
    :try_end_dd
    .catch Ljava/io/IOException; {:try_start_d7 .. :try_end_dd} :catch_10b

    move-object v1, v0

    .line 1334
    .local v1, "is":Ljava/io/InputStream;
    :try_start_de
    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 1335
    .local v0, "bitmap":Landroid/graphics/Bitmap;
    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_e5
    .catchall {:try_start_de .. :try_end_e5} :catchall_f2

    .line 1336
    .end local v0    # "bitmap":Landroid/graphics/Bitmap;
    if-eqz v1, :cond_ef

    :try_start_e7
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_ea
    .catch Ljava/io/IOException; {:try_start_e7 .. :try_end_ea} :catch_eb

    goto :goto_ef

    .end local v1    # "is":Ljava/io/InputStream;
    :catch_eb
    move-exception v0

    move-object/from16 v28, v2

    goto :goto_114

    .line 1338
    :cond_ef
    :goto_ef
    move-object/from16 v28, v2

    goto :goto_117

    .line 1333
    .restart local v1    # "is":Ljava/io/InputStream;
    :catchall_f2
    move-exception v0

    move-object/from16 v28, v2

    move-object v2, v0

    .end local v2    # "fontRobotoBold":Landroid/graphics/Typeface;
    .local v28, "fontRobotoBold":Landroid/graphics/Typeface;
    if-eqz v1, :cond_106

    :try_start_f8
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_fb
    .catchall {:try_start_f8 .. :try_end_fb} :catchall_fe

    move-object/from16 v29, v1

    goto :goto_108

    :catchall_fe
    move-exception v0

    move-object/from16 v29, v1

    move-object v1, v0

    .end local v1    # "is":Ljava/io/InputStream;
    .local v29, "is":Ljava/io/InputStream;
    :try_start_102
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_108

    .end local v29    # "is":Ljava/io/InputStream;
    .restart local v1    # "is":Ljava/io/InputStream;
    :cond_106
    move-object/from16 v29, v1

    .end local v1    # "is":Ljava/io/InputStream;
    .end local v3    # "fontAudiowide":Landroid/graphics/Typeface;
    .end local v4    # "outerPadding":I
    .end local v5    # "outer":Landroid/widget/LinearLayout;
    .end local v6    # "dialog":Landroid/app/Dialog;
    .end local v7    # "dontShow":Z
    .end local v9    # "logo":Landroid/widget/ImageView;
    .end local v10    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .end local v11    # "header":Landroid/widget/LinearLayout;
    .end local v12    # "outerBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v14    # "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v15    # "prefs":Landroid/content/SharedPreferences;
    .end local v23    # "logoSize":I
    .end local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    .end local p0    # "activity":Landroid/app/Activity;
    .restart local v29    # "is":Ljava/io/InputStream;
    :goto_108
    throw v2
    :try_end_109
    .catch Ljava/io/IOException; {:try_start_102 .. :try_end_109} :catch_109

    .line 1336
    .end local v29    # "is":Ljava/io/InputStream;
    .restart local v3    # "fontAudiowide":Landroid/graphics/Typeface;
    .restart local v4    # "outerPadding":I
    .restart local v5    # "outer":Landroid/widget/LinearLayout;
    .restart local v6    # "dialog":Landroid/app/Dialog;
    .restart local v7    # "dontShow":Z
    .restart local v9    # "logo":Landroid/widget/ImageView;
    .restart local v10    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .restart local v11    # "header":Landroid/widget/LinearLayout;
    .restart local v12    # "outerBg":Landroid/graphics/drawable/GradientDrawable;
    .restart local v14    # "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .restart local v15    # "prefs":Landroid/content/SharedPreferences;
    .restart local v23    # "logoSize":I
    .restart local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    .restart local p0    # "activity":Landroid/app/Activity;
    :catch_109
    move-exception v0

    goto :goto_114

    .end local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    .restart local v2    # "fontRobotoBold":Landroid/graphics/Typeface;
    :catch_10b
    move-exception v0

    move-object/from16 v28, v2

    .end local v2    # "fontRobotoBold":Landroid/graphics/Typeface;
    .restart local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    goto :goto_114

    .end local v23    # "logoSize":I
    .end local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    .local v1, "logoSize":I
    .restart local v2    # "fontRobotoBold":Landroid/graphics/Typeface;
    :catch_10f
    move-exception v0

    move/from16 v23, v1

    move-object/from16 v28, v2

    .line 1337
    .end local v1    # "logoSize":I
    .end local v2    # "fontRobotoBold":Landroid/graphics/Typeface;
    .local v0, "e":Ljava/io/IOException;
    .restart local v23    # "logoSize":I
    .restart local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    :goto_114
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 1341
    .end local v0    # "e":Ljava/io/IOException;
    :goto_117
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1342
    .local v0, "title":Landroid/widget/TextView;
    const-string v1, "\u7834\u89e3\u8f6f\u4ef6"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1343
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1344
    const/high16 v1, 0x41a00000    # 20.0f

    const/4 v2, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1345
    const/4 v2, -0x1

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1346
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v30, v3

    move/from16 v31, v4

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, -0x2

    const/4 v4, 0x0

    .end local v3    # "fontAudiowide":Landroid/graphics/Typeface;
    .end local v4    # "outerPadding":I
    .local v30, "fontAudiowide":Landroid/graphics/Typeface;
    .local v31, "outerPadding":I
    invoke-direct {v2, v4, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v4, v2

    .line 1348
    .local v4, "titleLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1351
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .line 1352
    .local v3, "moreApps":Landroid/widget/TextView;
    const-string v1, "\u66f4\u591a\u8d44\u6e90"

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1353
    const/high16 v1, 0x41700000    # 15.0f

    const/4 v2, 0x2

    invoke-virtual {v3, v2, v1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1354
    sget-object v2, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    const/4 v1, 0x0

    invoke-virtual {v3, v2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1355
    const/high16 v1, 0x41400000    # 12.0f

    invoke-static {v8, v1}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v2

    move-object/from16 v33, v4

    .end local v4    # "titleLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v33, "titleLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v4, 0x41000000    # 8.0f

    move-object/from16 v34, v12

    .end local v12    # "outerBg":Landroid/graphics/drawable/GradientDrawable;
    .local v34, "outerBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v8, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v12

    move-object/from16 v35, v14

    .end local v14    # "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v35, "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v8, v1}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    invoke-static {v8, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v1

    invoke-virtual {v3, v2, v12, v14, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1356
    const/4 v1, -0x1

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1357
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1358
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v1

    .line 1359
    .local v2, "moreAppsBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v1, 0x41400000    # 12.0f

    invoke-static {v8, v1}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v12

    int-to-float v1, v12

    invoke-virtual {v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1360
    const-string v1, "#222428"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v2, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1361
    const/high16 v12, 0x3f800000    # 1.0f

    invoke-static {v8, v12}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    const-string v12, "#747474"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v14, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1362
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1364
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1365
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1366
    invoke-virtual {v11, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1367
    invoke-virtual {v5, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1370
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1371
    .local v4, "descBox":Landroid/widget/LinearLayout;
    const/4 v14, 0x1

    invoke-virtual {v4, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1372
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v38, v2

    move-object/from16 v39, v3

    const/4 v2, -0x1

    const/4 v3, -0x2

    .end local v2    # "moreAppsBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v3    # "moreApps":Landroid/widget/TextView;
    .local v38, "moreAppsBg":Landroid/graphics/drawable/GradientDrawable;
    .local v39, "moreApps":Landroid/widget/TextView;
    invoke-direct {v14, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v14

    .line 1374
    .local v3, "descLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v2, 0x41a00000    # 20.0f

    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    move-object/from16 v40, v0

    const/high16 v2, 0x41800000    # 16.0f

    .end local v0    # "title":Landroid/widget/TextView;
    .local v40, "title":Landroid/widget/TextView;
    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    const/4 v2, 0x0

    invoke-virtual {v3, v2, v14, v2, v0}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1375
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1376
    const/high16 v0, 0x41400000    # 12.0f

    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v2

    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    move-object/from16 v41, v3

    .end local v3    # "descLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v41, "descLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    move-object/from16 v42, v9

    .end local v9    # "logo":Landroid/widget/ImageView;
    .local v42, "logo":Landroid/widget/ImageView;
    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    invoke-virtual {v4, v2, v14, v3, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1378
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v2, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v3, 0x2

    new-array v9, v3, [I

    .line 1380
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const/4 v13, 0x0

    aput v3, v9, v13

    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const/4 v13, 0x1

    aput v3, v9, v13

    invoke-direct {v0, v2, v9}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 1381
    .local v0, "descBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v2, 0x41800000    # 16.0f

    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    int-to-float v2, v3

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1382
    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v3, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1383
    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1385
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .line 1386
    .local v3, "desc":Landroid/widget/TextView;
    const-string v2, "\u2022 \u6b22\u8fce\u4f7f\u7528\n\u2022 \u9ad8\u7ea7\u529f\u80fd\u5df2\u89e3\u9501\n\u2022 \u4eab\u53d7\u65e0\u5e7f\u544a\u4f53\u9a8c"

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1387
    const/high16 v2, 0x41600000    # 14.0f

    const/4 v9, 0x2

    invoke-virtual {v3, v9, v2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1388
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1389
    const/4 v9, -0x1

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1390
    const/4 v9, 0x0

    const v13, 0x3f99999a    # 1.2f

    invoke-virtual {v3, v9, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 1391
    const/high16 v9, 0x40c00000    # 6.0f

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v13

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v14

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v2

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    invoke-virtual {v3, v13, v14, v2, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1393
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1394
    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1397
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1398
    .local v2, "actionsRow":Landroid/widget/LinearLayout;
    const/4 v9, 0x0

    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1399
    const/16 v9, 0x10

    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1400
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v9, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1404
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v14, v9

    .line 1405
    .local v14, "more":Landroid/widget/TextView;
    const-string v9, "\u6e29\u99a8\u63d0\u793a"

    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1406
    invoke-virtual {v14, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1407
    const/high16 v9, 0x41700000    # 15.0f

    const/4 v13, 0x2

    invoke-virtual {v14, v13, v9}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1408
    const/4 v9, -0x1

    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1409
    const/high16 v9, 0x41400000    # 12.0f

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v13

    move-object/from16 v24, v0

    move-object/from16 v32, v3

    const/high16 v0, 0x41000000    # 8.0f

    .end local v0    # "descBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v3    # "desc":Landroid/widget/TextView;
    .local v24, "descBg":Landroid/graphics/drawable/GradientDrawable;
    .local v32, "desc":Landroid/widget/TextView;
    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    move-object/from16 v43, v4

    .end local v4    # "descBox":Landroid/widget/LinearLayout;
    .local v43, "descBox":Landroid/widget/LinearLayout;
    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    invoke-static {v8, v0}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    invoke-virtual {v14, v13, v3, v4, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1411
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1412
    .local v0, "moreBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v3, 0x41400000    # 12.0f

    invoke-static {v8, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    int-to-float v3, v4

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1413
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1414
    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v8, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v4

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1415
    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1417
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v3, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v3

    .line 1419
    .local v4, "moreLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v3, 0x41400000    # 12.0f

    invoke-static {v8, v3}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v3

    const/4 v9, 0x0

    invoke-virtual {v4, v9, v9, v3, v9}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1420
    invoke-virtual {v14, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1421
    invoke-virtual {v2, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1424
    new-instance v3, Landroid/view/View;

    invoke-direct {v3, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 1425
    .local v3, "spacer":Landroid/view/View;
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v12, v9, v9, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1426
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1429
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v13, v9

    .line 1430
    .local v13, "dontShowLabel":Landroid/widget/TextView;
    const-string v9, "\u4e0d\u518d\u63d0\u793a"

    invoke-virtual {v13, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1431
    invoke-virtual {v13, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1432
    const/high16 v9, 0x41600000    # 14.0f

    const/4 v12, 0x2

    invoke-virtual {v13, v12, v9}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 1433
    const-string v9, "#E0E0E0"

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v13, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1434
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v9, v12, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v12, v9

    .line 1436
    .local v12, "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v9, 0x41000000    # 8.0f

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    move-object/from16 v16, v3

    const/4 v3, 0x0

    .end local v3    # "spacer":Landroid/view/View;
    .local v16, "spacer":Landroid/view/View;
    invoke-virtual {v12, v3, v3, v9, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1437
    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1438
    invoke-virtual {v2, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1441
    new-instance v3, Landroid/widget/Switch;

    invoke-direct {v3, v8}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    .line 1442
    .local v3, "dontShowSwitch":Landroid/widget/Switch;
    invoke-virtual {v3, v7}, Landroid/widget/Switch;->setChecked(Z)V

    .line 1443
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1446
    new-instance v9, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda0;

    invoke-direct {v9, v15}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda0;-><init>(Landroid/content/SharedPreferences;)V

    invoke-virtual {v3, v9}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 1451
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v4

    move/from16 v37, v7

    const/4 v4, -0x1

    const/4 v7, -0x2

    .end local v4    # "moreLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v7    # "dontShow":Z
    .local v36, "moreLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v37, "dontShow":Z
    invoke-direct {v9, v4, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v7, v9

    .line 1453
    .local v7, "rowLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v4, 0x41a00000    # 20.0f

    invoke-static {v8, v4}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    const/4 v4, 0x0

    invoke-virtual {v7, v4, v4, v4, v9}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1454
    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1456
    invoke-virtual {v5, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1459
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1460
    .local v9, "bottomRow":Landroid/widget/LinearLayout;
    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1461
    const/16 v4, 0x11

    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1462
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v44, v2

    move-object/from16 v26, v7

    const/4 v2, -0x1

    const/4 v7, -0x2

    .end local v2    # "actionsRow":Landroid/widget/LinearLayout;
    .end local v7    # "rowLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v26, "rowLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v44, "actionsRow":Landroid/widget/LinearLayout;
    invoke-direct {v4, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1466
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v4, v2

    .line 1467
    .local v4, "closeBtn":Landroid/widget/Button;
    const-string v2, "\u8fdb\u5165\u8f6f\u4ef6"

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1468
    invoke-virtual {v4, v10}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1469
    const/4 v2, 0x0

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 1470
    const/4 v2, 0x2

    const/high16 v7, 0x41800000    # 16.0f

    invoke-virtual {v4, v2, v7}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1471
    const/4 v2, -0x1

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 1472
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 1473
    const/high16 v7, 0x42480000    # 50.0f

    move-object/from16 v45, v0

    .end local v0    # "moreBg":Landroid/graphics/drawable/GradientDrawable;
    .local v45, "moreBg":Landroid/graphics/drawable/GradientDrawable;
    invoke-static {v8, v7}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v0

    move-object/from16 v46, v9

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v9, 0x0

    .end local v9    # "bottomRow":Landroid/widget/LinearLayout;
    .local v46, "bottomRow":Landroid/widget/LinearLayout;
    invoke-direct {v2, v9, v0, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v0, v2

    .line 1474
    .local v0, "closeLp":Landroid/widget/LinearLayout$LayoutParams;
    const/high16 v2, 0x41200000    # 10.0f

    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v2

    invoke-virtual {v0, v9, v9, v2, v9}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1475
    invoke-virtual {v4, v0}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1477
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v7, v2

    .line 1478
    .local v7, "closeBg":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v2, 0x41a00000    # 20.0f

    invoke-static {v8, v2}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    int-to-float v2, v9

    invoke-virtual {v7, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1479
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1480
    invoke-virtual {v4, v7}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1483
    new-instance v1, Landroid/widget/Button;

    invoke-direct {v1, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 1484
    .local v2, "joinBtn":Landroid/widget/Button;
    const-string v1, "\u52a0\u5165\u6211\u4eec"

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1485
    const/4 v1, 0x0

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 1486
    invoke-virtual {v2, v10}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1487
    const/4 v1, 0x2

    const/high16 v9, 0x41800000    # 16.0f

    invoke-virtual {v2, v1, v9}, Landroid/widget/Button;->setTextSize(IF)V

    .line 1488
    const/4 v1, -0x1

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setTextColor(I)V

    .line 1489
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 1490
    const/high16 v9, 0x42480000    # 50.0f

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    move-object/from16 v18, v7

    move-object/from16 v20, v10

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v10, 0x0

    .end local v7    # "closeBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v10    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .local v18, "closeBg":Landroid/graphics/drawable/GradientDrawable;
    .local v20, "fontRobotoRegular":Landroid/graphics/Typeface;
    invoke-direct {v1, v10, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v7, v1

    .line 1491
    .local v7, "joinLp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v2, v7}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1493
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    sget-object v9, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v10, 0x2

    new-array v10, v10, [I

    .line 1495
    const-string v22, "#6A11CB"

    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v22

    const/16 v21, 0x0

    aput v22, v10, v21

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v17

    move-object/from16 v22, v7

    const/4 v7, 0x1

    .end local v7    # "joinLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v22, "joinLp":Landroid/widget/LinearLayout$LayoutParams;
    aput v17, v10, v7

    invoke-direct {v1, v9, v10}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 1496
    .local v1, "joinGrad":Landroid/graphics/drawable/GradientDrawable;
    const/high16 v9, 0x41a00000    # 20.0f

    invoke-static {v8, v9}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v9

    int-to-float v9, v9

    invoke-virtual {v1, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1497
    invoke-virtual {v2, v1}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1499
    new-array v10, v7, [Z

    const/4 v7, 0x0

    aput-boolean v7, v10, v7

    move-object/from16 v7, v20

    .line 1501
    .end local v20    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .local v7, "fontRobotoRegular":Landroid/graphics/Typeface;
    .local v10, "isDismissing":[Z
    new-instance v9, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda4;

    move-object/from16 v19, v0

    move-object/from16 v20, v9

    move-object/from16 v17, v42

    move-object/from16 v0, v46

    .end local v42    # "logo":Landroid/widget/ImageView;
    .end local v46    # "bottomRow":Landroid/widget/LinearLayout;
    .local v0, "bottomRow":Landroid/widget/LinearLayout;
    .local v17, "logo":Landroid/widget/ImageView;
    .local v19, "closeLp":Landroid/widget/LinearLayout$LayoutParams;
    move-object/from16 v21, v11

    .end local v11    # "header":Landroid/widget/LinearLayout;
    .restart local v21    # "header":Landroid/widget/LinearLayout;
    move-object v11, v15

    move-object/from16 v27, v12

    move-object/from16 v25, v34

    .end local v12    # "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v34    # "outerBg":Landroid/graphics/drawable/GradientDrawable;
    .local v25, "outerBg":Landroid/graphics/drawable/GradientDrawable;
    .local v27, "labelLp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v12, v3

    move-object/from16 v29, v13

    .end local v13    # "dontShowLabel":Landroid/widget/TextView;
    .local v29, "dontShowLabel":Landroid/widget/TextView;
    move-object v13, v5

    move-object/from16 v47, v14

    move-object/from16 v34, v35

    const/4 v8, -0x2

    .end local v14    # "more":Landroid/widget/TextView;
    .end local v35    # "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v34, "logoLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v47, "more":Landroid/widget/TextView;
    move-object v14, v6

    invoke-direct/range {v9 .. v14}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda4;-><init>([ZLandroid/content/SharedPreferences;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/app/Dialog;)V

    invoke-virtual {v4, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1509
    new-instance v9, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda5;

    move-object v12, v1

    move/from16 v11, v23

    .end local v1    # "joinGrad":Landroid/graphics/drawable/GradientDrawable;
    .end local v23    # "logoSize":I
    .local v11, "logoSize":I
    .local v12, "joinGrad":Landroid/graphics/drawable/GradientDrawable;
    move-object v1, v9

    move-object v8, v2

    move-object/from16 v13, v28

    move-object/from16 v14, v38

    move-object/from16 v20, v44

    .end local v2    # "joinBtn":Landroid/widget/Button;
    .end local v28    # "fontRobotoBold":Landroid/graphics/Typeface;
    .end local v38    # "moreAppsBg":Landroid/graphics/drawable/GradientDrawable;
    .end local v44    # "actionsRow":Landroid/widget/LinearLayout;
    .local v8, "joinBtn":Landroid/widget/Button;
    .local v13, "fontRobotoBold":Landroid/graphics/Typeface;
    .local v14, "moreAppsBg":Landroid/graphics/drawable/GradientDrawable;
    .local v20, "actionsRow":Landroid/widget/LinearLayout;
    move-object v2, v10

    move-object/from16 v35, v3

    move-object/from16 v23, v10

    move-object/from16 v10, v39

    move-object/from16 v28, v41

    move-object/from16 v48, v32

    move-object/from16 v32, v16

    move-object/from16 v16, v30

    move-object/from16 v30, v48

    .end local v3    # "dontShowSwitch":Landroid/widget/Switch;
    .end local v39    # "moreApps":Landroid/widget/TextView;
    .end local v41    # "descLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v10, "moreApps":Landroid/widget/TextView;
    .local v16, "fontAudiowide":Landroid/graphics/Typeface;
    .local v23, "isDismissing":[Z
    .local v28, "descLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v30, "desc":Landroid/widget/TextView;
    .local v32, "spacer":Landroid/view/View;
    .local v35, "dontShowSwitch":Landroid/widget/Switch;
    move-object v3, v15

    move/from16 v39, v11

    move-object/from16 v38, v36

    move-object/from16 v36, v43

    move-object v11, v4

    .end local v4    # "closeBtn":Landroid/widget/Button;
    .end local v43    # "descBox":Landroid/widget/LinearLayout;
    .local v11, "closeBtn":Landroid/widget/Button;
    .local v36, "descBox":Landroid/widget/LinearLayout;
    .local v38, "moreLp":Landroid/widget/LinearLayout$LayoutParams;
    .local v39, "logoSize":I
    move-object/from16 v4, v35

    move-object/from16 v41, v5

    .end local v5    # "outer":Landroid/widget/LinearLayout;
    .local v41, "outer":Landroid/widget/LinearLayout;
    move-object/from16 v42, v6

    .end local v6    # "dialog":Landroid/app/Dialog;
    .local v42, "dialog":Landroid/app/Dialog;
    move-object/from16 v43, v22

    move-object/from16 v22, v12

    move-object v12, v7

    move/from16 v48, v37

    move-object/from16 v37, v18

    move/from16 v18, v48

    .end local v7    # "fontRobotoRegular":Landroid/graphics/Typeface;
    .local v12, "fontRobotoRegular":Landroid/graphics/Typeface;
    .local v18, "dontShow":Z
    .local v22, "joinGrad":Landroid/graphics/drawable/GradientDrawable;
    .local v37, "closeBg":Landroid/graphics/drawable/GradientDrawable;
    .local v43, "joinLp":Landroid/widget/LinearLayout$LayoutParams;
    move-object/from16 v7, p0

    invoke-direct/range {v1 .. v7}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda5;-><init>([ZLandroid/content/SharedPreferences;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/app/Activity;)V

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1522
    invoke-virtual {v0, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1523
    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1524
    move-object/from16 v1, v41

    .end local v41    # "outer":Landroid/widget/LinearLayout;
    .local v1, "outer":Landroid/widget/LinearLayout;
    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1526
    move-object/from16 v2, v42

    .end local v42    # "dialog":Landroid/app/Dialog;
    .local v2, "dialog":Landroid/app/Dialog;
    invoke-virtual {v2, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 1527
    new-instance v3, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda6;

    invoke-direct {v3, v1}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda6;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 1529
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    if-eqz v3, :cond_4d6

    .line 1530
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    const v4, 0x106000d

    invoke-virtual {v3, v4}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 1531
    new-instance v3, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v3}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    .line 1532
    .local v3, "lp":Landroid/view/WindowManager$LayoutParams;
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/view/WindowManager$LayoutParams;->copyFrom(Landroid/view/WindowManager$LayoutParams;)I

    .line 1533
    const/4 v4, -0x2

    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 1534
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 1537
    .end local v3    # "lp":Landroid/view/WindowManager$LayoutParams;
    :cond_4d6
    invoke-virtual {v2}, Landroid/app/Dialog;->show()V

    .line 1539
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v3

    if-eqz v3, :cond_516

    .line 1540
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 1541
    .local v3, "screenWidth":I
    int-to-float v4, v3

    const v5, 0x3f6147ae    # 0.88f

    mul-float v4, v4, v5

    float-to-int v4, v4

    const/high16 v5, 0x40800000    # 4.0f

    move-object/from16 v6, p0

    invoke-static {v6, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    add-int/2addr v4, v5

    .line 1542
    .local v4, "targetWidth":I
    const/high16 v5, 0x43960000    # 300.0f

    invoke-static {v6, v5}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v5

    .line 1543
    .local v5, "minWidth":I
    const/high16 v7, 0x44340000    # 720.0f

    invoke-static {v6, v7}, Lcom/Epic/custom/dialog/Customdialog;->dp(Landroid/app/Activity;F)I

    move-result v7

    .line 1544
    .local v7, "maxWidth":I
    if-ge v4, v5, :cond_508

    move v4, v5

    .line 1545
    :cond_508
    if-le v4, v7, :cond_50b

    move v4, v7

    .line 1546
    :cond_50b
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v9

    move-object/from16 v41, v1

    const/4 v1, -0x2

    .end local v1    # "outer":Landroid/widget/LinearLayout;
    .restart local v41    # "outer":Landroid/widget/LinearLayout;
    invoke-virtual {v9, v4, v1}, Landroid/view/Window;->setLayout(II)V

    goto :goto_51a

    .line 1539
    .end local v3    # "screenWidth":I
    .end local v4    # "targetWidth":I
    .end local v5    # "minWidth":I
    .end local v7    # "maxWidth":I
    .end local v41    # "outer":Landroid/widget/LinearLayout;
    .restart local v1    # "outer":Landroid/widget/LinearLayout;
    :cond_516
    move-object/from16 v6, p0

    move-object/from16 v41, v1

    .line 1550
    .end local v1    # "outer":Landroid/widget/LinearLayout;
    .restart local v41    # "outer":Landroid/widget/LinearLayout;
    :goto_51a
    new-instance v1, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda7;

    invoke-direct {v1, v6, v13, v12}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda7;-><init>(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;)V

    move-object/from16 v3, v47

    .end local v47    # "more":Landroid/widget/TextView;
    .local v3, "more":Landroid/widget/TextView;
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1651
    new-instance v1, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;

    invoke-direct {v1, v6, v13, v12}, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda8;-><init>(Landroid/app/Activity;Landroid/graphics/Typeface;Landroid/graphics/Typeface;)V

    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1764
    return-void
.end method
