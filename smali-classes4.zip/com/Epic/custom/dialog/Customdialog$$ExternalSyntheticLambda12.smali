.class public final synthetic Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:[Z

.field public final synthetic f$1:Landroid/widget/LinearLayout;

.field public final synthetic f$2:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$0:[Z

    iput-object p2, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$1:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$2:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    iget-object v0, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$0:[Z

    iget-object v1, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$1:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/Epic/custom/dialog/Customdialog$$ExternalSyntheticLambda12;->f$2:Landroid/app/Dialog;

    invoke-static {v0, v1, v2, p1}, Lcom/Epic/custom/dialog/Customdialog;->lambda$zenx$5([ZLandroid/widget/LinearLayout;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method
