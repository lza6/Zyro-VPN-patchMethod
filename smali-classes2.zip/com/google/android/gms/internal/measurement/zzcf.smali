.class public final Lcom/google/android/gms/internal/measurement/zzcf;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static volatile zza:Lcom/google/android/gms/internal/measurement/zzci;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lcom/google/android/gms/internal/measurement/zzch;

    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzch;-><init>()V

    .line 6
    sput-object v0, Lcom/google/android/gms/internal/measurement/zzcf;->zza:Lcom/google/android/gms/internal/measurement/zzci;

    .line 8
    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/measurement/zzci;
    .registers 1

    .line 1
    sget-object v0, Lcom/google/android/gms/internal/measurement/zzcf;->zza:Lcom/google/android/gms/internal/measurement/zzci;

    .line 3
    return-object v0
.end method
