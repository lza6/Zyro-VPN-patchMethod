.class public final Lcom/google/android/gms/internal/consent_sdk/zzcm;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static zza:Ljava/lang/String;


# direct methods
.method public static declared-synchronized zza(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    .line 1
    const-class v0, Lcom/google/android/gms/internal/consent_sdk/zzcm;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzcm;->zza:Ljava/lang/String;

    .line 6
    if-nez v1, :cond_29

    .line 8
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 11
    move-result-object p0

    .line 12
    if-nez p0, :cond_f

    .line 14
    const/4 p0, 0x0

    .line 15
    goto :goto_15

    .line 16
    :cond_f
    const-string v1, "android_id"

    .line 18
    invoke-static {p0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    move-result-object p0

    .line 22
    :goto_15
    if-eqz p0, :cond_21

    .line 24
    const/4 v1, 0x1

    .line 25
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzcu;->zza(Z)Z

    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_23

    .line 31
    goto :goto_21

    .line 32
    :catchall_1f
    move-exception p0

    .line 33
    goto :goto_2d

    .line 34
    :cond_21
    :goto_21
    const-string p0, "emulator"

    .line 36
    :cond_23
    invoke-static {p0}, Lcom/google/android/gms/internal/consent_sdk/zzcm;->zzb(Ljava/lang/String;)Ljava/lang/String;

    .line 39
    move-result-object p0

    .line 40
    sput-object p0, Lcom/google/android/gms/internal/consent_sdk/zzcm;->zza:Ljava/lang/String;

    .line 42
    :cond_29
    sget-object p0, Lcom/google/android/gms/internal/consent_sdk/zzcm;->zza:Ljava/lang/String;
    :try_end_2b
    .catchall {:try_start_3 .. :try_end_2b} :catchall_1f

    .line 44
    monitor-exit v0

    .line 45
    return-object p0

    .line 46
    :goto_2d
    monitor-exit v0

    .line 47
    throw p0
.end method

.method private static zzb(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    const/4 v1, 0x3

    .line 3
    if-ge v0, v1, :cond_29

    .line 5
    :try_start_4
    const-string v1, "MD5"

    .line 7
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    .line 14
    move-result-object v2

    .line 15
    invoke-virtual {v1, v2}, Ljava/security/MessageDigest;->update([B)V

    .line 18
    const-string v2, "%032X"

    .line 20
    new-instance v3, Ljava/math/BigInteger;

    .line 22
    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    .line 25
    move-result-object v1

    .line 26
    const/4 v4, 0x1

    .line 27
    invoke-direct {v3, v4, v1}, Ljava/math/BigInteger;-><init>(I[B)V

    .line 30
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 33
    move-result-object v1

    .line 34
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 37
    move-result-object p0
    :try_end_25
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_4 .. :try_end_25} :catch_26
    .catch Ljava/lang/ArithmeticException; {:try_start_4 .. :try_end_25} :catch_29

    .line 38
    return-object p0

    .line 39
    :catch_26
    add-int/lit8 v0, v0, 0x1

    .line 41
    goto :goto_1

    .line 42
    :catch_29
    :cond_29
    const-string p0, ""

    .line 44
    return-object p0
.end method
