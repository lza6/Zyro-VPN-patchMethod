.class public final Lcom/google/android/gms/internal/consent_sdk/zzaf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/internal/consent_sdk/zzdo;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic zza()Ljava/lang/Object;
    .registers 2

    new-instance v0, Lcom/google/android/gms/internal/consent_sdk/zzad;

    invoke-direct {v0}, Lcom/google/android/gms/internal/consent_sdk/zzad;-><init>()V

    return-object v0
.end method
