.class public final synthetic Lcom/google/android/gms/internal/consent_sdk/zzbn;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD2/f$a;


# instance fields
.field public final synthetic zza:LD2/b$a;


# direct methods
.method public synthetic constructor <init>(LD2/b$a;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzbn;->zza:LD2/b$a;

    .line 6
    return-void
.end method


# virtual methods
.method public final onConsentFormLoadFailure(LD2/e;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/internal/consent_sdk/zzbn;->zza:LD2/b$a;

    .line 3
    invoke-interface {v0, p1}, LD2/b$a;->onConsentFormDismissed(LD2/e;)V

    .line 6
    return-void
.end method
