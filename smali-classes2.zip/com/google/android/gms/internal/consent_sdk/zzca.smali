.class public final synthetic Lcom/google/android/gms/internal/consent_sdk/zzca;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic zza:Lcom/google/android/gms/internal/consent_sdk/zzcb;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/internal/consent_sdk/zzcb;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzca;->zza:Lcom/google/android/gms/internal/consent_sdk/zzcb;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/google/android/gms/internal/consent_sdk/zzca;->zza:Lcom/google/android/gms/internal/consent_sdk/zzcb;

    invoke-static {v0}, Lcom/google/android/gms/internal/consent_sdk/zzcb;->zzc(Lcom/google/android/gms/internal/consent_sdk/zzcb;)V

    return-void
.end method
