.class final Lcom/google/android/gms/internal/consent_sdk/zzba;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD2/f$b;
.implements LD2/f$a;


# instance fields
.field private final zza:LD2/f$b;

.field private final zzb:LD2/f$a;


# direct methods
.method public synthetic constructor <init>(LD2/f$b;LD2/f$a;Lcom/google/android/gms/internal/consent_sdk/zzbb;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzba;->zza:LD2/f$b;

    .line 6
    iput-object p2, p0, Lcom/google/android/gms/internal/consent_sdk/zzba;->zzb:LD2/f$a;

    .line 8
    return-void
.end method


# virtual methods
.method public final onConsentFormLoadFailure(LD2/e;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/internal/consent_sdk/zzba;->zzb:LD2/f$a;

    .line 3
    invoke-interface {v0, p1}, LD2/f$a;->onConsentFormLoadFailure(LD2/e;)V

    .line 6
    return-void
.end method

.method public final onConsentFormLoadSuccess(LD2/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/internal/consent_sdk/zzba;->zza:LD2/f$b;

    .line 3
    invoke-interface {v0, p1}, LD2/f$b;->onConsentFormLoadSuccess(LD2/b;)V

    .line 6
    return-void
.end method
