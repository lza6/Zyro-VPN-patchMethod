.class public final synthetic Lcom/google/android/gms/internal/consent_sdk/zzt;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic zza:LD2/c$b;


# direct methods
.method public synthetic constructor <init>(LD2/c$b;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzt;->zza:LD2/c$b;

    .line 6
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/google/android/gms/internal/consent_sdk/zzt;->zza:LD2/c$b;

    invoke-interface {v0}, LD2/c$b;->onConsentInfoUpdateSuccess()V

    return-void
.end method
