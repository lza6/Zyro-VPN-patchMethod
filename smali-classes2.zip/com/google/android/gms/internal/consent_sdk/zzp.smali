.class final Lcom/google/android/gms/internal/consent_sdk/zzp;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final zza:Lcom/google/android/gms/internal/consent_sdk/zzn;

.field private final zzb:Landroid/app/Activity;

.field private final zzc:LD2/a;

.field private final zzd:LD2/d;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/internal/consent_sdk/zzn;Landroid/app/Activity;LD2/a;LD2/d;Lcom/google/android/gms/internal/consent_sdk/zzo;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zza:Lcom/google/android/gms/internal/consent_sdk/zzn;

    .line 6
    iput-object p2, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzb:Landroid/app/Activity;

    .line 8
    iput-object p3, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzc:LD2/a;

    .line 10
    iput-object p4, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzd:LD2/d;

    .line 12
    return-void
.end method

.method public static bridge synthetic zza(Lcom/google/android/gms/internal/consent_sdk/zzp;)Lcom/google/android/gms/internal/consent_sdk/zzcj;
    .registers 11

    .line 1
    new-instance v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;

    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/internal/consent_sdk/zzcj;-><init>()V

    .line 6
    iget-object v1, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzd:LD2/d;

    .line 8
    invoke-virtual {v1}, LD2/d;->c()Ljava/lang/String;

    .line 11
    move-result-object v1

    .line 12
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x3

    .line 17
    const/4 v4, 0x0

    .line 18
    if-nez v2, :cond_14

    .line 20
    goto :goto_3e

    .line 21
    :cond_14
    :try_start_14
    iget-object v2, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zza:Lcom/google/android/gms/internal/consent_sdk/zzn;

    .line 23
    invoke-static {v2}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 26
    move-result-object v5

    .line 27
    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 30
    move-result-object v5

    .line 31
    invoke-static {v2}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 34
    move-result-object v2

    .line 35
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 38
    move-result-object v2

    .line 39
    const/16 v6, 0x80

    .line 41
    invoke-virtual {v5, v2, v6}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 44
    move-result-object v2

    .line 45
    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;
    :try_end_2e
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_14 .. :try_end_2e} :catch_2f

    .line 47
    goto :goto_30

    .line 48
    :catch_2f
    move-object v2, v4

    .line 49
    :goto_30
    if-eqz v2, :cond_38

    .line 51
    const-string v1, "com.google.android.gms.ads.APPLICATION_ID"

    .line 53
    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    move-result-object v1

    .line 57
    :cond_38
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 60
    move-result v2

    .line 61
    if-nez v2, :cond_1da

    .line 63
    :goto_3e
    iput-object v1, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zza:Ljava/lang/String;

    .line 65
    iget-object v1, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzc:LD2/a;

    .line 67
    invoke-virtual {v1}, LD2/a;->b()Z

    .line 70
    move-result v2

    .line 71
    const/4 v5, 0x2

    .line 72
    if-nez v2, :cond_4e

    .line 74
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 77
    move-result-object v1

    .line 78
    goto :goto_7f

    .line 79
    :cond_4e
    new-instance v2, Ljava/util/ArrayList;

    .line 81
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 84
    invoke-virtual {v1}, LD2/a;->a()I

    .line 87
    move-result v1

    .line 88
    const/4 v6, 0x1

    .line 89
    if-eq v1, v6, :cond_74

    .line 91
    if-eq v1, v5, :cond_6e

    .line 93
    if-eq v1, v3, :cond_68

    .line 95
    const/4 v3, 0x4

    .line 96
    if-eq v1, v3, :cond_62

    .line 98
    goto :goto_79

    .line 99
    :cond_62
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzce;->zze:Lcom/google/android/gms/internal/consent_sdk/zzce;

    .line 101
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 104
    goto :goto_79

    .line 105
    :cond_68
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzce;->zzd:Lcom/google/android/gms/internal/consent_sdk/zzce;

    .line 107
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 110
    goto :goto_79

    .line 111
    :cond_6e
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzce;->zzf:Lcom/google/android/gms/internal/consent_sdk/zzce;

    .line 113
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 116
    goto :goto_79

    .line 117
    :cond_74
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzce;->zzc:Lcom/google/android/gms/internal/consent_sdk/zzce;

    .line 119
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 122
    :goto_79
    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/zzce;->zzg:Lcom/google/android/gms/internal/consent_sdk/zzce;

    .line 124
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 127
    move-object v1, v2

    .line 128
    :goto_7f
    iput-object v1, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzi:Ljava/util/List;

    .line 130
    iget-object v1, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zza:Lcom/google/android/gms/internal/consent_sdk/zzn;

    .line 132
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zzb(Lcom/google/android/gms/internal/consent_sdk/zzn;)Lcom/google/android/gms/internal/consent_sdk/zzaq;

    .line 135
    move-result-object v2

    .line 136
    invoke-virtual {v2}, Lcom/google/android/gms/internal/consent_sdk/zzaq;->zzc()Ljava/util/Map;

    .line 139
    move-result-object v2

    .line 140
    iput-object v2, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zze:Ljava/util/Map;

    .line 142
    iget-object v2, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzd:LD2/d;

    .line 144
    invoke-virtual {v2}, LD2/d;->b()Z

    .line 147
    move-result v2

    .line 148
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 151
    move-result-object v2

    .line 152
    iput-object v2, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzd:Ljava/lang/Boolean;

    .line 154
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 157
    move-result-object v2

    .line 158
    invoke-virtual {v2}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    .line 161
    move-result-object v2

    .line 162
    iput-object v2, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzc:Ljava/lang/String;

    .line 164
    new-instance v2, Lcom/google/android/gms/internal/consent_sdk/zzcf;

    .line 166
    invoke-direct {v2}, Lcom/google/android/gms/internal/consent_sdk/zzcf;-><init>()V

    .line 169
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 171
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 174
    move-result-object v6

    .line 175
    iput-object v6, v2, Lcom/google/android/gms/internal/consent_sdk/zzcf;->zzb:Ljava/lang/Integer;

    .line 177
    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 179
    iput-object v6, v2, Lcom/google/android/gms/internal/consent_sdk/zzcf;->zza:Ljava/lang/String;

    .line 181
    iput v5, v2, Lcom/google/android/gms/internal/consent_sdk/zzcf;->zzc:I

    .line 183
    iput-object v2, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzb:Lcom/google/android/gms/internal/consent_sdk/zzcf;

    .line 185
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 188
    move-result-object v2

    .line 189
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 192
    move-result-object v2

    .line 193
    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 196
    move-result-object v2

    .line 197
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 200
    move-result-object v5

    .line 201
    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 204
    move-result-object v5

    .line 205
    invoke-virtual {v5}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 208
    new-instance v5, Lcom/google/android/gms/internal/consent_sdk/zzch;

    .line 210
    invoke-direct {v5}, Lcom/google/android/gms/internal/consent_sdk/zzch;-><init>()V

    .line 213
    iget v6, v2, Landroid/content/res/Configuration;->screenWidthDp:I

    .line 215
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 218
    move-result-object v6

    .line 219
    iput-object v6, v5, Lcom/google/android/gms/internal/consent_sdk/zzch;->zza:Ljava/lang/Integer;

    .line 221
    iget v2, v2, Landroid/content/res/Configuration;->screenHeightDp:I

    .line 223
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 226
    move-result-object v2

    .line 227
    iput-object v2, v5, Lcom/google/android/gms/internal/consent_sdk/zzch;->zzb:Ljava/lang/Integer;

    .line 229
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 232
    move-result-object v2

    .line 233
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 236
    move-result-object v2

    .line 237
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 240
    move-result-object v2

    .line 241
    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    .line 243
    float-to-double v6, v2

    .line 244
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 247
    move-result-object v2

    .line 248
    iput-object v2, v5, Lcom/google/android/gms/internal/consent_sdk/zzch;->zzc:Ljava/lang/Double;

    .line 250
    const/16 v2, 0x1c

    .line 252
    if-ge v3, v2, :cond_103

    .line 254
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 257
    move-result-object v3

    .line 258
    goto/16 :goto_174

    .line 260
    :cond_103
    iget-object v3, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zzb:Landroid/app/Activity;

    .line 262
    if-nez v3, :cond_109

    .line 264
    move-object v3, v4

    .line 265
    goto :goto_10d

    .line 266
    :cond_109
    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 269
    move-result-object v3

    .line 270
    :goto_10d
    if-nez v3, :cond_111

    .line 272
    move-object v3, v4

    .line 273
    goto :goto_115

    .line 274
    :cond_111
    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 277
    move-result-object v3

    .line 278
    :goto_115
    if-nez v3, :cond_119

    .line 280
    move-object v3, v4

    .line 281
    goto :goto_11d

    .line 282
    :cond_119
    invoke-virtual {v3}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    .line 285
    move-result-object v3

    .line 286
    :goto_11d
    if-nez v3, :cond_121

    .line 288
    move-object v3, v4

    .line 289
    goto :goto_125

    .line 290
    :cond_121
    invoke-static {v3}, LR/B0;->a(Landroid/view/WindowInsets;)Landroid/view/DisplayCutout;

    .line 293
    move-result-object v3

    .line 294
    :goto_125
    if-nez v3, :cond_12c

    .line 296
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 299
    move-result-object v3

    .line 300
    goto :goto_174

    .line 301
    :cond_12c
    invoke-static {v3}, LW0/k;->a(Landroid/view/DisplayCutout;)I

    .line 304
    new-instance v6, Ljava/util/ArrayList;

    .line 306
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 309
    invoke-static {v3}, Lcom/google/android/gms/ads/internal/util/l;->a(Landroid/view/DisplayCutout;)Ljava/util/List;

    .line 312
    move-result-object v3

    .line 313
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 316
    move-result-object v3

    .line 317
    :cond_13c
    :goto_13c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 320
    move-result v7

    .line 321
    if-eqz v7, :cond_173

    .line 323
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 326
    move-result-object v7

    .line 327
    check-cast v7, Landroid/graphics/Rect;

    .line 329
    if-eqz v7, :cond_13c

    .line 331
    new-instance v8, Lcom/google/android/gms/internal/consent_sdk/zzcg;

    .line 333
    invoke-direct {v8}, Lcom/google/android/gms/internal/consent_sdk/zzcg;-><init>()V

    .line 336
    iget v9, v7, Landroid/graphics/Rect;->left:I

    .line 338
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 341
    move-result-object v9

    .line 342
    iput-object v9, v8, Lcom/google/android/gms/internal/consent_sdk/zzcg;->zzb:Ljava/lang/Integer;

    .line 344
    iget v9, v7, Landroid/graphics/Rect;->right:I

    .line 346
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 349
    move-result-object v9

    .line 350
    iput-object v9, v8, Lcom/google/android/gms/internal/consent_sdk/zzcg;->zzc:Ljava/lang/Integer;

    .line 352
    iget v9, v7, Landroid/graphics/Rect;->top:I

    .line 354
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 357
    move-result-object v9

    .line 358
    iput-object v9, v8, Lcom/google/android/gms/internal/consent_sdk/zzcg;->zza:Ljava/lang/Integer;

    .line 360
    iget v7, v7, Landroid/graphics/Rect;->bottom:I

    .line 362
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 365
    move-result-object v7

    .line 366
    iput-object v7, v8, Lcom/google/android/gms/internal/consent_sdk/zzcg;->zzd:Ljava/lang/Integer;

    .line 368
    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 371
    goto :goto_13c

    .line 372
    :cond_173
    move-object v3, v6

    .line 373
    :goto_174
    iput-object v3, v5, Lcom/google/android/gms/internal/consent_sdk/zzch;->zzd:Ljava/util/List;

    .line 375
    iput-object v5, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzf:Lcom/google/android/gms/internal/consent_sdk/zzch;

    .line 377
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 380
    move-result-object v3

    .line 381
    :try_start_17c
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 384
    move-result-object v1

    .line 385
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 388
    move-result-object v1

    .line 389
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 392
    move-result-object v5

    .line 393
    const/4 v6, 0x0

    .line 394
    invoke-virtual {v1, v5, v6}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 397
    move-result-object v1
    :try_end_18d
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_17c .. :try_end_18d} :catch_18e

    .line 398
    goto :goto_18f

    .line 399
    :catch_18e
    move-object v1, v4

    .line 400
    :goto_18f
    new-instance v5, Lcom/google/android/gms/internal/consent_sdk/zzcd;

    .line 402
    invoke-direct {v5}, Lcom/google/android/gms/internal/consent_sdk/zzcd;-><init>()V

    .line 405
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 408
    move-result-object v3

    .line 409
    iput-object v3, v5, Lcom/google/android/gms/internal/consent_sdk/zzcd;->zza:Ljava/lang/String;

    .line 411
    iget-object p0, p0, Lcom/google/android/gms/internal/consent_sdk/zzp;->zza:Lcom/google/android/gms/internal/consent_sdk/zzn;

    .line 413
    invoke-static {p0}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 416
    move-result-object v3

    .line 417
    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 420
    move-result-object v3

    .line 421
    invoke-static {p0}, Lcom/google/android/gms/internal/consent_sdk/zzn;->zza(Lcom/google/android/gms/internal/consent_sdk/zzn;)Landroid/app/Application;

    .line 424
    move-result-object p0

    .line 425
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 428
    move-result-object p0

    .line 429
    invoke-virtual {v3, p0}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    .line 432
    move-result-object p0

    .line 433
    if-eqz p0, :cond_1b6

    .line 435
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 438
    move-result-object v4

    .line 439
    :cond_1b6
    iput-object v4, v5, Lcom/google/android/gms/internal/consent_sdk/zzcd;->zzb:Ljava/lang/String;

    .line 441
    if-eqz v1, :cond_1cc

    .line 443
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 445
    if-lt p0, v2, :cond_1c3

    .line 447
    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/a;->a(Landroid/content/pm/PackageInfo;)J

    .line 450
    move-result-wide v1

    .line 451
    goto :goto_1c6

    .line 452
    :cond_1c3
    iget p0, v1, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 454
    int-to-long v1, p0

    .line 455
    :goto_1c6
    invoke-static {v1, v2}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 458
    move-result-object p0

    .line 459
    iput-object p0, v5, Lcom/google/android/gms/internal/consent_sdk/zzcd;->zzc:Ljava/lang/String;

    .line 461
    :cond_1cc
    iput-object v5, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzg:Lcom/google/android/gms/internal/consent_sdk/zzcd;

    .line 463
    new-instance p0, Lcom/google/android/gms/internal/consent_sdk/zzci;

    .line 465
    invoke-direct {p0}, Lcom/google/android/gms/internal/consent_sdk/zzci;-><init>()V

    .line 468
    const-string v1, "3.2.0"

    .line 470
    iput-object v1, p0, Lcom/google/android/gms/internal/consent_sdk/zzci;->zza:Ljava/lang/String;

    .line 472
    iput-object p0, v0, Lcom/google/android/gms/internal/consent_sdk/zzcj;->zzh:Lcom/google/android/gms/internal/consent_sdk/zzci;

    .line 474
    return-object v0

    .line 475
    :cond_1da
    new-instance p0, Lcom/google/android/gms/internal/consent_sdk/zzg;

    .line 477
    const-string v0, "The UMP SDK requires a valid application ID in your AndroidManifest.xml through a com.google.android.gms.ads.APPLICATION_ID meta-data tag.\nExample AndroidManifest:\n    <meta-data\n        android:name=\"com.google.android.gms.ads.APPLICATION_ID\"\n        android:value=\"ca-app-pub-0000000000000000~0000000000\">"

    .line 479
    invoke-direct {p0, v3, v0}, Lcom/google/android/gms/internal/consent_sdk/zzg;-><init>(ILjava/lang/String;)V

    .line 482
    throw p0
.end method
