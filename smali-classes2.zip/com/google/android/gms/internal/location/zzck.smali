.class final Lcom/google/android/gms/internal/location/zzck;
.super Lcom/google/android/gms/internal/location/zzcl;
.source "SourceFile"


# instance fields
.field final synthetic zza:Ljava/util/List;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/location/zzcm;Lcom/google/android/gms/common/api/GoogleApiClient;Ljava/util/List;)V
    .registers 4

    .line 1
    iput-object p3, p0, Lcom/google/android/gms/internal/location/zzck;->zza:Ljava/util/List;

    .line 3
    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/location/zzcl;-><init>(Lcom/google/android/gms/common/api/GoogleApiClient;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final bridge synthetic doExecute(Lcom/google/android/gms/common/api/Api$AnyClient;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzck;->zza:Ljava/util/List;

    .line 3
    check-cast p1, Lcom/google/android/gms/internal/location/zzdu;

    .line 5
    invoke-static {v0}, Lcom/google/android/gms/internal/location/zzeh;->zza(Ljava/util/List;)Lcom/google/android/gms/internal/location/zzeh;

    .line 8
    move-result-object v0

    .line 9
    invoke-static {p0}, Lcom/google/android/gms/internal/location/zzcm;->zza(Lcom/google/android/gms/common/api/internal/BaseImplementation$ResultHolder;)Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {p1, v0, v1}, Lcom/google/android/gms/internal/location/zzdu;->zzF(Lcom/google/android/gms/internal/location/zzeh;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 16
    return-void
.end method
