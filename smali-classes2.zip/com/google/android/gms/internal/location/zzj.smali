.class public final Lcom/google/android/gms/internal/location/zzj;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/internal/location/zzj;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final zza:I

.field final zzb:Lcom/google/android/gms/internal/location/zzh;

.field final zzc:Lcom/google/android/gms/location/zzt;

.field final zzd:Lcom/google/android/gms/internal/location/zzr;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/google/android/gms/internal/location/zzk;

    invoke-direct {v0}, Lcom/google/android/gms/internal/location/zzk;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/location/zzj;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(ILcom/google/android/gms/internal/location/zzh;Landroid/os/IBinder;Landroid/os/IBinder;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    .line 4
    iput p1, p0, Lcom/google/android/gms/internal/location/zzj;->zza:I

    .line 6
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzj;->zzb:Lcom/google/android/gms/internal/location/zzh;

    .line 8
    const/4 p1, 0x0

    .line 9
    if-nez p3, :cond_c

    .line 11
    move-object p2, p1

    .line 12
    goto :goto_10

    .line 13
    :cond_c
    invoke-static {p3}, Lcom/google/android/gms/location/zzs;->zzb(Landroid/os/IBinder;)Lcom/google/android/gms/location/zzt;

    .line 16
    move-result-object p2

    .line 17
    :goto_10
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzj;->zzc:Lcom/google/android/gms/location/zzt;

    .line 19
    if-nez p4, :cond_15

    .line 21
    goto :goto_27

    .line 22
    :cond_15
    const-string p1, "com.google.android.gms.location.internal.IFusedLocationProviderCallback"

    .line 24
    invoke-interface {p4, p1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 27
    move-result-object p1

    .line 28
    instance-of p2, p1, Lcom/google/android/gms/internal/location/zzr;

    .line 30
    if-eqz p2, :cond_22

    .line 32
    check-cast p1, Lcom/google/android/gms/internal/location/zzr;

    .line 34
    goto :goto_27

    .line 35
    :cond_22
    new-instance p1, Lcom/google/android/gms/internal/location/zzp;

    .line 37
    invoke-direct {p1, p4}, Lcom/google/android/gms/internal/location/zzp;-><init>(Landroid/os/IBinder;)V

    .line 40
    :goto_27
    iput-object p1, p0, Lcom/google/android/gms/internal/location/zzj;->zzd:Lcom/google/android/gms/internal/location/zzr;

    .line 42
    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 7

    .line 1
    invoke-static {p1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->beginObjectHeader(Landroid/os/Parcel;)I

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    iget v2, p0, Lcom/google/android/gms/internal/location/zzj;->zza:I

    .line 8
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeInt(Landroid/os/Parcel;II)V

    .line 11
    iget-object v1, p0, Lcom/google/android/gms/internal/location/zzj;->zzb:Lcom/google/android/gms/internal/location/zzh;

    .line 13
    const/4 v2, 0x2

    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {p1, v2, v1, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeParcelable(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 18
    iget-object p2, p0, Lcom/google/android/gms/internal/location/zzj;->zzc:Lcom/google/android/gms/location/zzt;

    .line 20
    const/4 v1, 0x0

    .line 21
    if-nez p2, :cond_18

    .line 23
    move-object p2, v1

    .line 24
    goto :goto_1c

    .line 25
    :cond_18
    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    .line 28
    move-result-object p2

    .line 29
    :goto_1c
    const/4 v2, 0x3

    .line 30
    invoke-static {p1, v2, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeIBinder(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    .line 33
    iget-object p2, p0, Lcom/google/android/gms/internal/location/zzj;->zzd:Lcom/google/android/gms/internal/location/zzr;

    .line 35
    if-nez p2, :cond_25

    .line 37
    goto :goto_29

    .line 38
    :cond_25
    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    .line 41
    move-result-object v1

    .line 42
    :goto_29
    const/4 p2, 0x4

    .line 43
    invoke-static {p1, p2, v1, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeIBinder(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    .line 46
    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->finishObjectHeader(Landroid/os/Parcel;I)V

    .line 49
    return-void
.end method
