.class final synthetic Lcom/google/android/gms/internal/location/zzbz;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/internal/location/zzbg;


# static fields
.field static final synthetic zza:Lcom/google/android/gms/internal/location/zzbz;


# direct methods
.method public static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/google/android/gms/internal/location/zzbz;

    invoke-direct {v0}, Lcom/google/android/gms/internal/location/zzbz;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/location/zzbz;->zza:Lcom/google/android/gms/internal/location/zzbz;

    return-void
.end method

.method private synthetic constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic zza(Lcom/google/android/gms/internal/location/zzdu;Lcom/google/android/gms/common/api/internal/ListenerHolder$ListenerKey;ZLcom/google/android/gms/tasks/TaskCompletionSource;)V
    .registers 5

    invoke-virtual {p1, p2, p3, p4}, Lcom/google/android/gms/internal/location/zzdu;->zzw(Lcom/google/android/gms/common/api/internal/ListenerHolder$ListenerKey;ZLcom/google/android/gms/tasks/TaskCompletionSource;)V

    return-void
.end method
