.class public final Lcom/google/android/gms/internal/location/zzey;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static zza(Ljava/util/concurrent/CountDownLatch;JLjava/util/concurrent/TimeUnit;)Z
    .registers 7

    .line 1
    const-wide/16 p1, 0x1e

    .line 3
    const/4 v0, 0x0

    .line 4
    :try_start_3
    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    .line 7
    move-result-wide p1

    .line 8
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 11
    move-result-wide v1
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_1c

    .line 12
    add-long/2addr v1, p1

    .line 13
    :goto_c
    :try_start_c
    sget-object p3, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    .line 15
    invoke-virtual {p0, p1, p2, p3}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    .line 18
    move-result p0
    :try_end_12
    .catch Ljava/lang/InterruptedException; {:try_start_c .. :try_end_12} :catch_1e
    .catchall {:try_start_c .. :try_end_12} :catchall_1c

    .line 19
    if-eqz v0, :cond_1b

    .line 21
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 28
    :cond_1b
    return p0

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    goto :goto_26

    .line 31
    :catch_1e
    const/4 v0, 0x1

    .line 32
    :try_start_1f
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 35
    move-result-wide p1
    :try_end_23
    .catchall {:try_start_1f .. :try_end_23} :catchall_1c

    .line 36
    sub-long p1, v1, p1

    .line 38
    goto :goto_c

    .line 39
    :goto_26
    if-eqz v0, :cond_2f

    .line 41
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 48
    :cond_2f
    throw p0
.end method
