.class public final Lcom/google/android/gms/internal/location/zzed;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;
.source "SourceFile"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/internal/location/zzed;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final zza:I

.field private final zzb:Lcom/google/android/gms/internal/location/zzeb;

.field private final zzc:Lcom/google/android/gms/location/zzz;

.field private final zzd:Lcom/google/android/gms/location/zzw;

.field private final zze:Landroid/app/PendingIntent;

.field private final zzf:Lcom/google/android/gms/internal/location/zzr;

.field private final zzg:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/google/android/gms/internal/location/zzee;

    invoke-direct {v0}, Lcom/google/android/gms/internal/location/zzee;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/location/zzed;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(ILcom/google/android/gms/internal/location/zzeb;Landroid/os/IBinder;Landroid/os/IBinder;Landroid/app/PendingIntent;Landroid/os/IBinder;Ljava/lang/String;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    .line 4
    iput p1, p0, Lcom/google/android/gms/internal/location/zzed;->zza:I

    .line 6
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzed;->zzb:Lcom/google/android/gms/internal/location/zzeb;

    .line 8
    const/4 p1, 0x0

    .line 9
    if-eqz p3, :cond_f

    .line 11
    invoke-static {p3}, Lcom/google/android/gms/location/zzy;->zzb(Landroid/os/IBinder;)Lcom/google/android/gms/location/zzz;

    .line 14
    move-result-object p2

    .line 15
    goto :goto_10

    .line 16
    :cond_f
    move-object p2, p1

    .line 17
    :goto_10
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzed;->zzc:Lcom/google/android/gms/location/zzz;

    .line 19
    iput-object p5, p0, Lcom/google/android/gms/internal/location/zzed;->zze:Landroid/app/PendingIntent;

    .line 21
    if-eqz p4, :cond_1b

    .line 23
    invoke-static {p4}, Lcom/google/android/gms/location/zzv;->zzb(Landroid/os/IBinder;)Lcom/google/android/gms/location/zzw;

    .line 26
    move-result-object p2

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    move-object p2, p1

    .line 29
    :goto_1c
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzed;->zzd:Lcom/google/android/gms/location/zzw;

    .line 31
    if-eqz p6, :cond_32

    .line 33
    const-string p1, "com.google.android.gms.location.internal.IFusedLocationProviderCallback"

    .line 35
    invoke-interface {p6, p1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 38
    move-result-object p1

    .line 39
    instance-of p2, p1, Lcom/google/android/gms/internal/location/zzr;

    .line 41
    if-eqz p2, :cond_2d

    .line 43
    check-cast p1, Lcom/google/android/gms/internal/location/zzr;

    .line 45
    goto :goto_32

    .line 46
    :cond_2d
    new-instance p1, Lcom/google/android/gms/internal/location/zzp;

    .line 48
    invoke-direct {p1, p6}, Lcom/google/android/gms/internal/location/zzp;-><init>(Landroid/os/IBinder;)V

    .line 51
    :cond_32
    :goto_32
    iput-object p1, p0, Lcom/google/android/gms/internal/location/zzed;->zzf:Lcom/google/android/gms/internal/location/zzr;

    .line 53
    iput-object p7, p0, Lcom/google/android/gms/internal/location/zzed;->zzg:Ljava/lang/String;

    .line 55
    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 8

    .line 1
    iget v0, p0, Lcom/google/android/gms/internal/location/zzed;->zza:I

    .line 3
    invoke-static {p1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->beginObjectHeader(Landroid/os/Parcel;)I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    invoke-static {p1, v2, v0}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeInt(Landroid/os/Parcel;II)V

    .line 11
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzed;->zzb:Lcom/google/android/gms/internal/location/zzeb;

    .line 13
    const/4 v2, 0x2

    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {p1, v2, v0, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeParcelable(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 18
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzed;->zzc:Lcom/google/android/gms/location/zzz;

    .line 20
    const/4 v2, 0x0

    .line 21
    if-nez v0, :cond_18

    .line 23
    move-object v0, v2

    .line 24
    goto :goto_1c

    .line 25
    :cond_18
    invoke-interface {v0}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    .line 28
    move-result-object v0

    .line 29
    :goto_1c
    const/4 v4, 0x3

    .line 30
    invoke-static {p1, v4, v0, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeIBinder(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    .line 33
    const/4 v0, 0x4

    .line 34
    iget-object v4, p0, Lcom/google/android/gms/internal/location/zzed;->zze:Landroid/app/PendingIntent;

    .line 36
    invoke-static {p1, v0, v4, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeParcelable(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 39
    iget-object p2, p0, Lcom/google/android/gms/internal/location/zzed;->zzd:Lcom/google/android/gms/location/zzw;

    .line 41
    if-nez p2, :cond_2c

    .line 43
    move-object p2, v2

    .line 44
    goto :goto_30

    .line 45
    :cond_2c
    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    .line 48
    move-result-object p2

    .line 49
    :goto_30
    const/4 v0, 0x5

    .line 50
    invoke-static {p1, v0, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeIBinder(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    .line 53
    iget-object p2, p0, Lcom/google/android/gms/internal/location/zzed;->zzf:Lcom/google/android/gms/internal/location/zzr;

    .line 55
    if-nez p2, :cond_39

    .line 57
    goto :goto_3d

    .line 58
    :cond_39
    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    .line 61
    move-result-object v2

    .line 62
    :goto_3d
    const/4 p2, 0x6

    .line 63
    invoke-static {p1, p2, v2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeIBinder(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    .line 66
    const/16 p2, 0x8

    .line 68
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzed;->zzg:Ljava/lang/String;

    .line 70
    invoke-static {p1, p2, v0, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeString(Landroid/os/Parcel;ILjava/lang/String;Z)V

    .line 73
    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->finishObjectHeader(Landroid/os/Parcel;I)V

    .line 76
    return-void
.end method
