.class public final Lcom/google/android/gms/internal/location/zzeh;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/internal/location/zzeh;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final zza:Ljava/util/List;

.field private final zzb:Landroid/app/PendingIntent;

.field private final zzc:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/google/android/gms/internal/location/zzei;

    invoke-direct {v0}, Lcom/google/android/gms/internal/location/zzei;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/location/zzeh;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Ljava/util/List;Landroid/app/PendingIntent;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    .line 4
    if-nez p1, :cond_a

    .line 6
    invoke-static {}, Lcom/google/android/gms/internal/location/zzes;->zzi()Lcom/google/android/gms/internal/location/zzes;

    .line 9
    move-result-object p1

    .line 10
    goto :goto_e

    .line 11
    :cond_a
    invoke-static {p1}, Lcom/google/android/gms/internal/location/zzes;->zzj(Ljava/util/Collection;)Lcom/google/android/gms/internal/location/zzes;

    .line 14
    move-result-object p1

    .line 15
    :goto_e
    iput-object p1, p0, Lcom/google/android/gms/internal/location/zzeh;->zza:Ljava/util/List;

    .line 17
    iput-object p2, p0, Lcom/google/android/gms/internal/location/zzeh;->zzb:Landroid/app/PendingIntent;

    .line 19
    iput-object p3, p0, Lcom/google/android/gms/internal/location/zzeh;->zzc:Ljava/lang/String;

    .line 21
    return-void
.end method

.method public static zza(Ljava/util/List;)Lcom/google/android/gms/internal/location/zzeh;
    .registers 4

    .line 1
    const-string v0, "geofence can\'t be null."

    .line 3
    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/Preconditions;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 9
    move-result v0

    .line 10
    xor-int/lit8 v0, v0, 0x1

    .line 12
    const-string v1, "Geofences must contains at least one id."

    .line 14
    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/Preconditions;->checkArgument(ZLjava/lang/Object;)V

    .line 17
    new-instance v0, Lcom/google/android/gms/internal/location/zzeh;

    .line 19
    const/4 v1, 0x0

    .line 20
    const-string v2, ""

    .line 22
    invoke-direct {v0, p0, v1, v2}, Lcom/google/android/gms/internal/location/zzeh;-><init>(Ljava/util/List;Landroid/app/PendingIntent;Ljava/lang/String;)V

    .line 25
    return-object v0
.end method

.method public static zzb(Landroid/app/PendingIntent;)Lcom/google/android/gms/internal/location/zzeh;
    .registers 4

    .line 1
    const-string v0, "PendingIntent can not be null."

    .line 3
    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/Preconditions;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    new-instance v0, Lcom/google/android/gms/internal/location/zzeh;

    .line 8
    const/4 v1, 0x0

    .line 9
    const-string v2, ""

    .line 11
    invoke-direct {v0, v1, p0, v2}, Lcom/google/android/gms/internal/location/zzeh;-><init>(Ljava/util/List;Landroid/app/PendingIntent;Ljava/lang/String;)V

    .line 14
    return-object v0
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzeh;->zza:Ljava/util/List;

    .line 3
    invoke-static {p1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->beginObjectHeader(Landroid/os/Parcel;)I

    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    const/4 v3, 0x0

    .line 9
    invoke-static {p1, v2, v0, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeStringList(Landroid/os/Parcel;ILjava/util/List;Z)V

    .line 12
    const/4 v0, 0x2

    .line 13
    iget-object v2, p0, Lcom/google/android/gms/internal/location/zzeh;->zzb:Landroid/app/PendingIntent;

    .line 15
    invoke-static {p1, v0, v2, p2, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeParcelable(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    .line 18
    const/4 p2, 0x3

    .line 19
    iget-object v0, p0, Lcom/google/android/gms/internal/location/zzeh;->zzc:Ljava/lang/String;

    .line 21
    invoke-static {p1, p2, v0, v3}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeString(Landroid/os/Parcel;ILjava/lang/String;Z)V

    .line 24
    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->finishObjectHeader(Landroid/os/Parcel;I)V

    .line 27
    return-void
.end method
