.class public abstract LA2/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 3
    const-string v1, "unity"

    .line 5
    const-string v2, "native"

    .line 7
    filled-new-array {v2, v1}, [Ljava/lang/String;

    .line 10
    move-result-object v1

    .line 11
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 14
    move-result-object v1

    .line 15
    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 18
    new-instance v0, Ljava/util/HashMap;

    .line 20
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 23
    sput-object v0, LA2/n;->a:Ljava/util/Map;

    .line 25
    new-instance v0, LB2/f;

    .line 27
    const-string v1, "PlayCoreVersion"

    .line 29
    invoke-direct {v0, v1}, LB2/f;-><init>(Ljava/lang/String;)V

    .line 32
    return-void
.end method

.method public static declared-synchronized a()Ljava/util/Map;
    .registers 4

    .line 1
    const-class v0, LA2/n;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, LA2/n;->a:Ljava/util/Map;

    .line 6
    const-string v2, "java"

    .line 8
    const/16 v3, 0x4e22

    .line 10
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    move-result-object v3

    .line 14
    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_12

    .line 17
    monitor-exit v0

    .line 18
    return-object v1

    .line 19
    :catchall_12
    move-exception v1

    .line 20
    monitor-exit v0

    .line 21
    throw v1
.end method
