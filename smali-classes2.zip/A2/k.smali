.class public abstract LA2/k;
.super Lcom/google/android/play/core/review/internal/zzg;
.source "SourceFile"


# instance fields
.field public final a:LB2/f;

.field public final b:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field public final synthetic c:LA2/m;


# direct methods
.method public constructor <init>(LA2/m;LB2/f;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .registers 4

    .line 1
    iput-object p1, p0, LA2/k;->c:LA2/m;

    .line 3
    invoke-direct {p0}, Lcom/google/android/play/core/review/internal/zzg;-><init>()V

    .line 6
    iput-object p2, p0, LA2/k;->a:LB2/f;

    .line 8
    iput-object p3, p0, LA2/k;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 10
    return-void
.end method


# virtual methods
.method public zzb(Landroid/os/Bundle;)V
    .registers 4

    .line 1
    iget-object p1, p0, LA2/k;->c:LA2/m;

    .line 3
    iget-object p1, p1, LA2/m;->a:LB2/q;

    .line 5
    if-eqz p1, :cond_b

    .line 7
    iget-object v0, p0, LA2/k;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 9
    invoke-virtual {p1, v0}, LB2/q;->u(Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 12
    :cond_b
    iget-object p1, p0, LA2/k;->a:LB2/f;

    .line 14
    const/4 v0, 0x0

    .line 15
    new-array v0, v0, [Ljava/lang/Object;

    .line 17
    const-string v1, "onGetLaunchReviewFlowInfo"

    .line 19
    invoke-virtual {p1, v1, v0}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 22
    return-void
.end method
