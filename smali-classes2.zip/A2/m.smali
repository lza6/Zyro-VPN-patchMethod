.class public final LA2/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:LB2/f;


# instance fields
.field public a:LB2/q;

.field public final b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, LB2/f;

    .line 3
    const-string v1, "ReviewService"

    .line 5
    invoke-direct {v0, v1}, LB2/f;-><init>(Ljava/lang/String;)V

    .line 8
    sput-object v0, LA2/m;->c:LB2/f;

    .line 10
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, LA2/m;->b:Ljava/lang/String;

    .line 10
    invoke-static {p1}, LB2/t;->a(Landroid/content/Context;)Z

    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_2f

    .line 16
    new-instance v0, Landroid/content/Intent;

    .line 18
    const-string v1, "com.google.android.finsky.BIND_IN_APP_REVIEW_SERVICE"

    .line 20
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 23
    const-string v1, "com.android.vending"

    .line 25
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 28
    move-result-object v6

    .line 29
    new-instance v0, LB2/q;

    .line 31
    sget-object v4, LA2/m;->c:LB2/f;

    .line 33
    new-instance v7, LA2/i;

    .line 35
    invoke-direct {v7}, LA2/i;-><init>()V

    .line 38
    const-string v5, "com.google.android.finsky.inappreviewservice.InAppReviewService"

    .line 40
    const/4 v8, 0x0

    .line 41
    move-object v2, v0

    .line 42
    move-object v3, p1

    .line 43
    invoke-direct/range {v2 .. v8}, LB2/q;-><init>(Landroid/content/Context;LB2/f;Ljava/lang/String;Landroid/content/Intent;LA2/i;LB2/l;)V

    .line 46
    iput-object v0, p0, LA2/m;->a:LB2/q;

    .line 48
    :cond_2f
    return-void
.end method

.method public static bridge synthetic b()LB2/f;
    .registers 1

    .line 1
    sget-object v0, LA2/m;->c:LB2/f;

    .line 3
    return-object v0
.end method

.method public static bridge synthetic c(LA2/m;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, LA2/m;->b:Ljava/lang/String;

    .line 3
    return-object p0
.end method


# virtual methods
.method public final a()Lcom/google/android/gms/tasks/Task;
    .registers 4

    .line 1
    iget-object v0, p0, LA2/m;->b:Ljava/lang/String;

    .line 3
    sget-object v1, LA2/m;->c:LB2/f;

    .line 5
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    const-string v2, "requestInAppReview (%s)"

    .line 11
    invoke-virtual {v1, v2, v0}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 14
    iget-object v0, p0, LA2/m;->a:LB2/q;

    .line 16
    if-nez v0, :cond_24

    .line 18
    const/4 v0, 0x0

    .line 19
    new-array v0, v0, [Ljava/lang/Object;

    .line 21
    const-string v2, "Play Store app is either not installed or not the official version"

    .line 23
    invoke-virtual {v1, v2, v0}, LB2/f;->a(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 26
    new-instance v0, LA2/a;

    .line 28
    const/4 v1, -0x1

    .line 29
    invoke-direct {v0, v1}, LA2/a;-><init>(I)V

    .line 32
    invoke-static {v0}, Lcom/google/android/gms/tasks/Tasks;->forException(Ljava/lang/Exception;)Lcom/google/android/gms/tasks/Task;

    .line 35
    move-result-object v0

    .line 36
    return-object v0

    .line 37
    :cond_24
    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 39
    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    .line 42
    iget-object v1, p0, LA2/m;->a:LB2/q;

    .line 44
    new-instance v2, LA2/j;

    .line 46
    invoke-direct {v2, p0, v0, v0}, LA2/j;-><init>(LA2/m;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 49
    invoke-virtual {v1, v2, v0}, LB2/q;->s(LB2/g;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 52
    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    .line 55
    move-result-object v0

    .line 56
    return-object v0
.end method
