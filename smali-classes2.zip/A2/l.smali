.class public final LA2/l;
.super LA2/k;
.source "SourceFile"


# direct methods
.method public constructor <init>(LA2/m;Lcom/google/android/gms/tasks/TaskCompletionSource;Ljava/lang/String;)V
    .registers 5

    .line 1
    new-instance p3, LB2/f;

    .line 3
    const-string v0, "OnRequestInstallCallback"

    .line 5
    invoke-direct {p3, v0}, LB2/f;-><init>(Ljava/lang/String;)V

    .line 8
    invoke-direct {p0, p1, p3, p2}, LA2/k;-><init>(LA2/m;LB2/f;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final zzb(Landroid/os/Bundle;)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, LA2/k;->zzb(Landroid/os/Bundle;)V

    .line 4
    const-string v0, "confirmation_intent"

    .line 6
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Landroid/app/PendingIntent;

    .line 12
    const-string v1, "is_review_no_op"

    .line 14
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 17
    move-result p1

    .line 18
    new-instance v1, LA2/e;

    .line 20
    invoke-direct {v1, v0, p1}, LA2/e;-><init>(Landroid/app/PendingIntent;Z)V

    .line 23
    iget-object p1, p0, LA2/k;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 25
    invoke-virtual {p1, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetResult(Ljava/lang/Object;)Z

    .line 28
    return-void
.end method
