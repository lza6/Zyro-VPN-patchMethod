.class public final LA2/j;
.super LB2/g;
.source "SourceFile"


# instance fields
.field public final synthetic b:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field public final synthetic c:LA2/m;


# direct methods
.method public constructor <init>(LA2/m;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .registers 4

    .line 1
    iput-object p3, p0, LA2/j;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 3
    iput-object p1, p0, LA2/j;->c:LA2/m;

    .line 5
    invoke-direct {p0, p2}, LB2/g;-><init>(Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 9

    .line 1
    const-string v0, "unity"

    .line 3
    const-string v1, "native"

    .line 5
    :try_start_4
    iget-object v2, p0, LA2/j;->c:LA2/m;

    .line 7
    iget-object v2, v2, LA2/m;->a:LB2/q;

    .line 9
    invoke-virtual {v2}, LB2/q;->e()Landroid/os/IInterface;

    .line 12
    move-result-object v2

    .line 13
    check-cast v2, LB2/d;

    .line 15
    iget-object v3, p0, LA2/j;->c:LA2/m;

    .line 17
    invoke-static {v3}, LA2/m;->c(LA2/m;)Ljava/lang/String;

    .line 20
    move-result-object v3

    .line 21
    new-instance v4, Landroid/os/Bundle;

    .line 23
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 26
    invoke-static {}, LA2/n;->a()Ljava/util/Map;

    .line 29
    move-result-object v5

    .line 30
    const-string v6, "playcore_version_code"

    .line 32
    const-string v7, "java"

    .line 34
    invoke-interface {v5, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    move-result-object v7

    .line 38
    check-cast v7, Ljava/lang/Integer;

    .line 40
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 43
    move-result v7

    .line 44
    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 47
    invoke-interface {v5, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 50
    move-result v6

    .line 51
    if-eqz v6, :cond_46

    .line 53
    const-string v6, "playcore_native_version"

    .line 55
    invoke-interface {v5, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    move-result-object v1

    .line 59
    check-cast v1, Ljava/lang/Integer;

    .line 61
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 64
    move-result v1

    .line 65
    invoke-virtual {v4, v6, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 68
    goto :goto_46

    .line 69
    :catch_44
    move-exception v0

    .line 70
    goto :goto_6c

    .line 71
    :cond_46
    :goto_46
    invoke-interface {v5, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 74
    move-result v1

    .line 75
    if-eqz v1, :cond_5b

    .line 77
    const-string v1, "playcore_unity_version"

    .line 79
    invoke-interface {v5, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    move-result-object v0

    .line 83
    check-cast v0, Ljava/lang/Integer;

    .line 85
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 88
    move-result v0

    .line 89
    invoke-virtual {v4, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 92
    :cond_5b
    new-instance v0, LA2/l;

    .line 94
    iget-object v1, p0, LA2/j;->c:LA2/m;

    .line 96
    iget-object v5, p0, LA2/j;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 98
    invoke-static {v1}, LA2/m;->c(LA2/m;)Ljava/lang/String;

    .line 101
    move-result-object v6

    .line 102
    invoke-direct {v0, v1, v5, v6}, LA2/l;-><init>(LA2/m;Lcom/google/android/gms/tasks/TaskCompletionSource;Ljava/lang/String;)V

    .line 105
    invoke-interface {v2, v3, v4, v0}, LB2/d;->A(Ljava/lang/String;Landroid/os/Bundle;LB2/e;)V
    :try_end_6b
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_6b} :catch_44

    .line 108
    return-void

    .line 109
    :goto_6c
    iget-object v1, p0, LA2/j;->c:LA2/m;

    .line 111
    invoke-static {}, LA2/m;->b()LB2/f;

    .line 114
    move-result-object v2

    .line 115
    invoke-static {v1}, LA2/m;->c(LA2/m;)Ljava/lang/String;

    .line 118
    move-result-object v1

    .line 119
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 122
    move-result-object v1

    .line 123
    const-string v3, "error requesting in-app review for %s"

    .line 125
    invoke-virtual {v2, v0, v3, v1}, LB2/f;->b(Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)I

    .line 128
    iget-object v1, p0, LA2/j;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 130
    new-instance v2, Ljava/lang/RuntimeException;

    .line 132
    invoke-direct {v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 135
    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    .line 138
    return-void
.end method
