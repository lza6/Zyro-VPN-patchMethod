.class public interface abstract LA2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/app/Activity;LA2/b;)Lcom/google/android/gms/tasks/Task;
.end method

.method public abstract b()Lcom/google/android/gms/tasks/Task;
.end method
