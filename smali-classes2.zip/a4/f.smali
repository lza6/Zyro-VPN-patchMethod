.class public final La4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/t;


# instance fields
.field public final a:Ljava/util/concurrent/atomic/AtomicReference;

.field public final b:LQ3/t;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/atomic/AtomicReference;LQ3/t;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La4/f;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    iput-object p2, p0, La4/f;->b:LQ3/t;

    .line 8
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4/f;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-static {v0, p1}, LX3/b;->c(Ljava/util/concurrent/atomic/AtomicReference;LT3/b;)Z

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4/f;->b:LQ3/t;

    .line 3
    invoke-interface {v0, p1}, LQ3/t;->onError(Ljava/lang/Throwable;)V

    .line 6
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4/f;->b:LQ3/t;

    .line 3
    invoke-interface {v0, p1}, LQ3/t;->onSuccess(Ljava/lang/Object;)V

    .line 6
    return-void
.end method
