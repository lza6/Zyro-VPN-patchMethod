.class public final La4/e;
.super Ljava/util/concurrent/atomic/AtomicReference;
.source "SourceFile"

# interfaces
.implements LQ3/c;
.implements LT3/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, LX3/b;->g(Ljava/util/concurrent/atomic/AtomicReference;LT3/b;)Z

    .line 4
    return-void
.end method

.method public d()Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, LX3/b;->a:LX3/b;

    .line 7
    if-ne v0, v1, :cond_a

    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    :goto_b
    return v0
.end method

.method public dispose()V
    .registers 1

    .line 1
    invoke-static {p0}, LX3/b;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    .line 4
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    sget-object v0, LX3/b;->a:LX3/b;

    .line 3
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    sget-object v0, LX3/b;->a:LX3/b;

    .line 3
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 6
    new-instance v0, LU3/d;

    .line 8
    invoke-direct {v0, p1}, LU3/d;-><init>(Ljava/lang/Throwable;)V

    .line 11
    invoke-static {v0}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 14
    return-void
.end method
