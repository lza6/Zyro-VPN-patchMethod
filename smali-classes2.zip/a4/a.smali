.class public abstract La4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/q;
.implements LZ3/e;


# instance fields
.field public final a:LQ3/q;

.field public b:LT3/b;

.field public c:LZ3/e;

.field public d:Z

.field public e:I


# direct methods
.method public constructor <init>(LQ3/q;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, La4/a;->a:LQ3/q;

    .line 6
    return-void
.end method


# virtual methods
.method public final a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4/a;->b:LT3/b;

    .line 3
    invoke-static {v0, p1}, LX3/b;->h(LT3/b;LT3/b;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_20

    .line 9
    iput-object p1, p0, La4/a;->b:LT3/b;

    .line 11
    instance-of v0, p1, LZ3/e;

    .line 13
    if-eqz v0, :cond_12

    .line 15
    check-cast p1, LZ3/e;

    .line 17
    iput-object p1, p0, La4/a;->c:LZ3/e;

    .line 19
    :cond_12
    invoke-virtual {p0}, La4/a;->e()Z

    .line 22
    move-result p1

    .line 23
    if-eqz p1, :cond_20

    .line 25
    iget-object p1, p0, La4/a;->a:LQ3/q;

    .line 27
    invoke-interface {p1, p0}, LQ3/q;->a(LT3/b;)V

    .line 30
    invoke-virtual {p0}, La4/a;->c()V

    .line 33
    :cond_20
    return-void
.end method

.method public c()V
    .registers 1

    .line 1
    return-void
.end method

.method public clear()V
    .registers 2

    .line 1
    iget-object v0, p0, La4/a;->c:LZ3/e;

    .line 3
    invoke-interface {v0}, LZ3/j;->clear()V

    .line 6
    return-void
.end method

.method public d()Z
    .registers 2

    .line 1
    iget-object v0, p0, La4/a;->b:LT3/b;

    .line 3
    invoke-interface {v0}, LT3/b;->d()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public dispose()V
    .registers 2

    .line 1
    iget-object v0, p0, La4/a;->b:LT3/b;

    .line 3
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 6
    return-void
.end method

.method public e()Z
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final f(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 4
    iget-object v0, p0, La4/a;->b:LT3/b;

    .line 6
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 9
    invoke-virtual {p0, p1}, La4/a;->onError(Ljava/lang/Throwable;)V

    .line 12
    return-void
.end method

.method public final h(I)I
    .registers 4

    .line 1
    iget-object v0, p0, La4/a;->c:LZ3/e;

    .line 3
    if-eqz v0, :cond_11

    .line 5
    and-int/lit8 v1, p1, 0x4

    .line 7
    if-nez v1, :cond_11

    .line 9
    invoke-interface {v0, p1}, LZ3/f;->g(I)I

    .line 12
    move-result p1

    .line 13
    if-eqz p1, :cond_10

    .line 15
    iput p1, p0, La4/a;->e:I

    .line 17
    :cond_10
    return p1

    .line 18
    :cond_11
    const/4 p1, 0x0

    .line 19
    return p1
.end method

.method public isEmpty()Z
    .registers 2

    .line 1
    iget-object v0, p0, La4/a;->c:LZ3/e;

    .line 3
    invoke-interface {v0}, LZ3/j;->isEmpty()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final offer(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 3
    const-string v0, "Should not be called!"

    .line 5
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 8
    throw p1
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-boolean v0, p0, La4/a;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, La4/a;->d:Z

    .line 9
    iget-object v0, p0, La4/a;->a:LQ3/q;

    .line 11
    invoke-interface {v0}, LQ3/q;->onComplete()V

    .line 14
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, La4/a;->d:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, La4/a;->d:Z

    .line 12
    iget-object v0, p0, La4/a;->a:LQ3/q;

    .line 14
    invoke-interface {v0, p1}, LQ3/q;->onError(Ljava/lang/Throwable;)V

    .line 17
    return-void
.end method
