.class public final Lb4/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/c;

.field public final synthetic b:Lb4/f;


# direct methods
.method public constructor <init>(Lb4/f;LQ3/c;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lb4/f$a;->b:Lb4/f;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, Lb4/f$a;->a:LQ3/c;

    .line 8
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/f$a;->a:LQ3/c;

    .line 3
    invoke-interface {v0, p1}, LQ3/c;->a(LT3/b;)V

    .line 6
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lb4/f$a;->a:LQ3/c;

    .line 3
    invoke-interface {v0}, LQ3/c;->onComplete()V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lb4/f$a;->b:Lb4/f;

    .line 3
    iget-object v0, v0, Lb4/f;->b:LW3/g;

    .line 5
    invoke-interface {v0, p1}, LW3/g;->test(Ljava/lang/Object;)Z

    .line 8
    move-result v0
    :try_end_8
    .catchall {:try_start_0 .. :try_end_8} :catchall_16

    .line 9
    if-eqz v0, :cond_10

    .line 11
    iget-object p1, p0, Lb4/f$a;->a:LQ3/c;

    .line 13
    invoke-interface {p1}, LQ3/c;->onComplete()V

    .line 16
    goto :goto_15

    .line 17
    :cond_10
    iget-object v0, p0, Lb4/f$a;->a:LQ3/c;

    .line 19
    invoke-interface {v0, p1}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 22
    :goto_15
    return-void

    .line 23
    :catchall_16
    move-exception v0

    .line 24
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 27
    iget-object v1, p0, Lb4/f$a;->a:LQ3/c;

    .line 29
    new-instance v2, LU3/a;

    .line 31
    filled-new-array {p1, v0}, [Ljava/lang/Throwable;

    .line 34
    move-result-object p1

    .line 35
    invoke-direct {v2, p1}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 38
    invoke-interface {v1, v2}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 41
    return-void
.end method
