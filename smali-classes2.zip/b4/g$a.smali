.class public final Lb4/g$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/c;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb4/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/c;

.field public b:LT3/b;

.field public final synthetic c:Lb4/g;


# direct methods
.method public constructor <init>(Lb4/g;LQ3/c;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lb4/g$a;->c:Lb4/g;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, Lb4/g$a;->a:LQ3/c;

    .line 8
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    :try_start_0
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 3
    iget-object v0, v0, Lb4/g;->b:LW3/d;

    .line 5
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_17

    .line 8
    iget-object v0, p0, Lb4/g$a;->b:LT3/b;

    .line 10
    invoke-static {v0, p1}, LX3/b;->h(LT3/b;LT3/b;)Z

    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_16

    .line 16
    iput-object p1, p0, Lb4/g$a;->b:LT3/b;

    .line 18
    iget-object p1, p0, Lb4/g$a;->a:LQ3/c;

    .line 20
    invoke-interface {p1, p0}, LQ3/c;->a(LT3/b;)V

    .line 23
    :cond_16
    return-void

    .line 24
    :catchall_17
    move-exception v0

    .line 25
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 28
    invoke-interface {p1}, LT3/b;->dispose()V

    .line 31
    sget-object p1, LX3/b;->a:LX3/b;

    .line 33
    iput-object p1, p0, Lb4/g$a;->b:LT3/b;

    .line 35
    iget-object p1, p0, Lb4/g$a;->a:LQ3/c;

    .line 37
    invoke-static {v0, p1}, LX3/c;->e(Ljava/lang/Throwable;LQ3/c;)V

    .line 40
    return-void
.end method

.method public b()V
    .registers 2

    .line 1
    :try_start_0
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 3
    iget-object v0, v0, Lb4/g;->f:LW3/a;

    .line 5
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_8

    .line 8
    goto :goto_f

    .line 9
    :catchall_8
    move-exception v0

    .line 10
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 13
    invoke-static {v0}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 16
    :goto_f
    return-void
.end method

.method public d()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lb4/g$a;->b:LT3/b;

    .line 3
    invoke-interface {v0}, LT3/b;->d()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public dispose()V
    .registers 2

    .line 1
    :try_start_0
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 3
    iget-object v0, v0, Lb4/g;->g:LW3/a;

    .line 5
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_8

    .line 8
    goto :goto_f

    .line 9
    :catchall_8
    move-exception v0

    .line 10
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 13
    invoke-static {v0}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 16
    :goto_f
    iget-object v0, p0, Lb4/g$a;->b:LT3/b;

    .line 18
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 21
    return-void
.end method

.method public onComplete()V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/g$a;->b:LT3/b;

    .line 3
    sget-object v1, LX3/b;->a:LX3/b;

    .line 5
    if-ne v0, v1, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    :try_start_7
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 10
    iget-object v0, v0, Lb4/g;->d:LW3/a;

    .line 12
    invoke-interface {v0}, LW3/a;->run()V

    .line 15
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 17
    iget-object v0, v0, Lb4/g;->e:LW3/a;

    .line 19
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_15
    .catchall {:try_start_7 .. :try_end_15} :catchall_1e

    .line 22
    iget-object v0, p0, Lb4/g$a;->a:LQ3/c;

    .line 24
    invoke-interface {v0}, LQ3/c;->onComplete()V

    .line 27
    invoke-virtual {p0}, Lb4/g$a;->b()V

    .line 30
    return-void

    .line 31
    :catchall_1e
    move-exception v0

    .line 32
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 35
    iget-object v1, p0, Lb4/g$a;->a:LQ3/c;

    .line 37
    invoke-interface {v1, v0}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 40
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/g$a;->b:LT3/b;

    .line 3
    sget-object v1, LX3/b;->a:LX3/b;

    .line 5
    if-ne v0, v1, :cond_a

    .line 7
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 10
    return-void

    .line 11
    :cond_a
    :try_start_a
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 13
    iget-object v0, v0, Lb4/g;->c:LW3/d;

    .line 15
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V

    .line 18
    iget-object v0, p0, Lb4/g$a;->c:Lb4/g;

    .line 20
    iget-object v0, v0, Lb4/g;->e:LW3/a;

    .line 22
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_18
    .catchall {:try_start_a .. :try_end_18} :catchall_19

    .line 25
    goto :goto_27

    .line 26
    :catchall_19
    move-exception v0

    .line 27
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 30
    new-instance v1, LU3/a;

    .line 32
    filled-new-array {p1, v0}, [Ljava/lang/Throwable;

    .line 35
    move-result-object p1

    .line 36
    invoke-direct {v1, p1}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 39
    move-object p1, v1

    .line 40
    :goto_27
    iget-object v0, p0, Lb4/g$a;->a:LQ3/c;

    .line 42
    invoke-interface {v0, p1}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 45
    invoke-virtual {p0}, Lb4/g$a;->b()V

    .line 48
    return-void
.end method
