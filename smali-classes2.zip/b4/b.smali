.class public final Lb4/b;
.super LQ3/b;
.source "SourceFile"


# static fields
.field public static final a:LQ3/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lb4/b;

    .line 3
    invoke-direct {v0}, Lb4/b;-><init>()V

    .line 6
    sput-object v0, Lb4/b;->a:LQ3/b;

    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 2

    .line 1
    invoke-static {p1}, LX3/c;->a(LQ3/c;)V

    .line 4
    return-void
.end method
