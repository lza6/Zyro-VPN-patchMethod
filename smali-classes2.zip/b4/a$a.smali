.class public final Lb4/a$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;
.source "SourceFile"

# interfaces
.implements LQ3/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb4/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/c;

.field public final b:[LQ3/d;

.field public c:I

.field public final d:LX3/e;


# direct methods
.method public constructor <init>(LQ3/c;[LQ3/d;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/a$a;->a:LQ3/c;

    .line 6
    iput-object p2, p0, Lb4/a$a;->b:[LQ3/d;

    .line 8
    new-instance p1, LX3/e;

    .line 10
    invoke-direct {p1}, LX3/e;-><init>()V

    .line 13
    iput-object p1, p0, Lb4/a$a;->d:LX3/e;

    .line 15
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/a$a;->d:LX3/e;

    .line 3
    invoke-virtual {v0, p1}, LX3/e;->a(LT3/b;)Z

    .line 6
    return-void
.end method

.method public b()V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/a$a;->d:LX3/e;

    .line 3
    invoke-virtual {v0}, LX3/e;->d()Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_10

    .line 16
    return-void

    .line 17
    :cond_10
    iget-object v0, p0, Lb4/a$a;->b:[LQ3/d;

    .line 19
    :cond_12
    iget-object v1, p0, Lb4/a$a;->d:LX3/e;

    .line 21
    invoke-virtual {v1}, LX3/e;->d()Z

    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_1b

    .line 27
    return-void

    .line 28
    :cond_1b
    iget v1, p0, Lb4/a$a;->c:I

    .line 30
    add-int/lit8 v2, v1, 0x1

    .line 32
    iput v2, p0, Lb4/a$a;->c:I

    .line 34
    array-length v2, v0

    .line 35
    if-ne v1, v2, :cond_2a

    .line 37
    iget-object v0, p0, Lb4/a$a;->a:LQ3/c;

    .line 39
    invoke-interface {v0}, LQ3/c;->onComplete()V

    .line 42
    return-void

    .line 43
    :cond_2a
    aget-object v1, v0, v1

    .line 45
    invoke-interface {v1, p0}, LQ3/d;->b(LQ3/c;)V

    .line 48
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 51
    move-result v1

    .line 52
    if-nez v1, :cond_12

    .line 54
    return-void
.end method

.method public onComplete()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lb4/a$a;->b()V

    .line 4
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/a$a;->a:LQ3/c;

    .line 3
    invoke-interface {v0, p1}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 6
    return-void
.end method
