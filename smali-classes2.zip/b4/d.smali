.class public final Lb4/d;
.super LQ3/b;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/concurrent/Callable;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/d;->a:Ljava/util/concurrent/Callable;

    .line 6
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 4

    .line 1
    invoke-static {}, LT3/c;->b()LT3/b;

    .line 4
    move-result-object v0

    .line 5
    invoke-interface {p1, v0}, LQ3/c;->a(LT3/b;)V

    .line 8
    :try_start_7
    iget-object v1, p0, Lb4/d;->a:Ljava/util/concurrent/Callable;

    .line 10
    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;
    :try_end_c
    .catchall {:try_start_7 .. :try_end_c} :catchall_16

    .line 13
    invoke-interface {v0}, LT3/b;->d()Z

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_15

    .line 19
    invoke-interface {p1}, LQ3/c;->onComplete()V

    .line 22
    :cond_15
    return-void

    .line 23
    :catchall_16
    move-exception v1

    .line 24
    invoke-static {v1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 27
    invoke-interface {v0}, LT3/b;->d()Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_23

    .line 33
    invoke-interface {p1, v1}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 36
    :cond_23
    return-void
.end method
