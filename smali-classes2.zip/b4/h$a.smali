.class public final Lb4/h$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb4/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb4/h$a$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/c;

.field public final b:LX3/e;

.field public final synthetic c:Lb4/h;


# direct methods
.method public constructor <init>(Lb4/h;LQ3/c;LX3/e;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lb4/h$a;->c:Lb4/h;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, Lb4/h$a;->a:LQ3/c;

    .line 8
    iput-object p3, p0, Lb4/h$a;->b:LX3/e;

    .line 10
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h$a;->b:LX3/e;

    .line 3
    invoke-virtual {v0, p1}, LX3/e;->b(LT3/b;)Z

    .line 6
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lb4/h$a;->a:LQ3/c;

    .line 3
    invoke-interface {v0}, LQ3/c;->onComplete()V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lb4/h$a;->c:Lb4/h;

    .line 3
    iget-object v0, v0, Lb4/h;->b:LW3/e;

    .line 5
    invoke-interface {v0, p1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LQ3/d;
    :try_end_a
    .catchall {:try_start_0 .. :try_end_a} :catchall_25

    .line 11
    if-nez v0, :cond_1c

    .line 13
    new-instance v0, Ljava/lang/NullPointerException;

    .line 15
    const-string v1, "The CompletableConsumable returned is null"

    .line 17
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 20
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 23
    iget-object p1, p0, Lb4/h$a;->a:LQ3/c;

    .line 25
    invoke-interface {p1, v0}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 28
    return-void

    .line 29
    :cond_1c
    new-instance p1, Lb4/h$a$a;

    .line 31
    invoke-direct {p1, p0}, Lb4/h$a$a;-><init>(Lb4/h$a;)V

    .line 34
    invoke-interface {v0, p1}, LQ3/d;->b(LQ3/c;)V

    .line 37
    return-void

    .line 38
    :catchall_25
    move-exception v0

    .line 39
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 42
    iget-object v1, p0, Lb4/h$a;->a:LQ3/c;

    .line 44
    new-instance v2, LU3/a;

    .line 46
    filled-new-array {v0, p1}, [Ljava/lang/Throwable;

    .line 49
    move-result-object p1

    .line 50
    invoke-direct {v2, p1}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 53
    invoke-interface {v1, v2}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 56
    return-void
.end method
