.class public final Lb4/h;
.super LQ3/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb4/h$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/d;

.field public final b:LW3/e;


# direct methods
.method public constructor <init>(LQ3/d;LW3/e;)V
    .registers 3

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/h;->a:LQ3/d;

    .line 6
    iput-object p2, p0, Lb4/h;->b:LW3/e;

    .line 8
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 5

    .line 1
    new-instance v0, LX3/e;

    .line 3
    invoke-direct {v0}, LX3/e;-><init>()V

    .line 6
    invoke-interface {p1, v0}, LQ3/c;->a(LT3/b;)V

    .line 9
    iget-object v1, p0, Lb4/h;->a:LQ3/d;

    .line 11
    new-instance v2, Lb4/h$a;

    .line 13
    invoke-direct {v2, p0, p1, v0}, Lb4/h$a;-><init>(Lb4/h;LQ3/c;LX3/e;)V

    .line 16
    invoke-interface {v1, v2}, LQ3/d;->b(LQ3/c;)V

    .line 19
    return-void
.end method
