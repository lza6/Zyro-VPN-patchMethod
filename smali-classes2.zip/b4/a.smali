.class public final Lb4/a;
.super LQ3/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb4/a$a;
    }
.end annotation


# instance fields
.field public final a:[LQ3/d;


# direct methods
.method public constructor <init>([LQ3/d;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/a;->a:[LQ3/d;

    .line 6
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 4

    .line 1
    new-instance v0, Lb4/a$a;

    .line 3
    iget-object v1, p0, Lb4/a;->a:[LQ3/d;

    .line 5
    invoke-direct {v0, p1, v1}, Lb4/a$a;-><init>(LQ3/c;[LQ3/d;)V

    .line 8
    iget-object v1, v0, Lb4/a$a;->d:LX3/e;

    .line 10
    invoke-interface {p1, v1}, LQ3/c;->a(LT3/b;)V

    .line 13
    invoke-virtual {v0}, Lb4/a$a;->b()V

    .line 16
    return-void
.end method
