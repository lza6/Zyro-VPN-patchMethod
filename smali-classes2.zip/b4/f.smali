.class public final Lb4/f;
.super LQ3/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb4/f$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/d;

.field public final b:LW3/g;


# direct methods
.method public constructor <init>(LQ3/d;LW3/g;)V
    .registers 3

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/f;->a:LQ3/d;

    .line 6
    iput-object p2, p0, Lb4/f;->b:LW3/g;

    .line 8
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/f;->a:LQ3/d;

    .line 3
    new-instance v1, Lb4/f$a;

    .line 5
    invoke-direct {v1, p0, p1}, Lb4/f$a;-><init>(Lb4/f;LQ3/c;)V

    .line 8
    invoke-interface {v0, v1}, LQ3/d;->b(LQ3/c;)V

    .line 11
    return-void
.end method
