.class public final Lb4/g;
.super LQ3/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lb4/g$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/d;

.field public final b:LW3/d;

.field public final c:LW3/d;

.field public final d:LW3/a;

.field public final e:LW3/a;

.field public final f:LW3/a;

.field public final g:LW3/a;


# direct methods
.method public constructor <init>(LQ3/d;LW3/d;LW3/d;LW3/a;LW3/a;LW3/a;LW3/a;)V
    .registers 8

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/g;->a:LQ3/d;

    .line 6
    iput-object p2, p0, Lb4/g;->b:LW3/d;

    .line 8
    iput-object p3, p0, Lb4/g;->c:LW3/d;

    .line 10
    iput-object p4, p0, Lb4/g;->d:LW3/a;

    .line 12
    iput-object p5, p0, Lb4/g;->e:LW3/a;

    .line 14
    iput-object p6, p0, Lb4/g;->f:LW3/a;

    .line 16
    iput-object p7, p0, Lb4/g;->g:LW3/a;

    .line 18
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/g;->a:LQ3/d;

    .line 3
    new-instance v1, Lb4/g$a;

    .line 5
    invoke-direct {v1, p0, p1}, Lb4/g$a;-><init>(Lb4/g;LQ3/c;)V

    .line 8
    invoke-interface {v0, v1}, LQ3/d;->b(LQ3/c;)V

    .line 11
    return-void
.end method
