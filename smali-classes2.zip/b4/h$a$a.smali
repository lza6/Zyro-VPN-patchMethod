.class public final Lb4/h$a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lb4/h$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:Lb4/h$a;


# direct methods
.method public constructor <init>(Lb4/h$a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lb4/h$a$a;->a:Lb4/h$a;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h$a$a;->a:Lb4/h$a;

    .line 3
    iget-object v0, v0, Lb4/h$a;->b:LX3/e;

    .line 5
    invoke-virtual {v0, p1}, LX3/e;->b(LT3/b;)Z

    .line 8
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lb4/h$a$a;->a:Lb4/h$a;

    .line 3
    iget-object v0, v0, Lb4/h$a;->a:LQ3/c;

    .line 5
    invoke-interface {v0}, LQ3/c;->onComplete()V

    .line 8
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h$a$a;->a:Lb4/h$a;

    .line 3
    iget-object v0, v0, Lb4/h$a;->a:LQ3/c;

    .line 5
    invoke-interface {v0, p1}, LQ3/c;->onError(Ljava/lang/Throwable;)V

    .line 8
    return-void
.end method
