.class public final Lb4/e;
.super LQ3/b;
.source "SourceFile"


# instance fields
.field public final a:LQ3/d;


# direct methods
.method public constructor <init>(LQ3/d;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/b;-><init>()V

    .line 4
    iput-object p1, p0, Lb4/e;->a:LQ3/d;

    .line 6
    return-void
.end method


# virtual methods
.method public p(LQ3/c;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/e;->a:LQ3/d;

    .line 3
    invoke-interface {v0, p1}, LQ3/d;->b(LQ3/c;)V

    .line 6
    return-void
.end method
