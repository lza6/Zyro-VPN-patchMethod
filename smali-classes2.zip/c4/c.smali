.class public final Lc4/c;
.super LQ3/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/c$f;,
        Lc4/c$c;,
        Lc4/c$e;,
        Lc4/c$d;,
        Lc4/c$h;,
        Lc4/c$g;,
        Lc4/c$b;
    }
.end annotation


# instance fields
.field public final b:LQ3/h;

.field public final c:LQ3/a;


# direct methods
.method public constructor <init>(LQ3/h;LQ3/a;)V
    .registers 3

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/c;->b:LQ3/h;

    .line 6
    iput-object p2, p0, Lc4/c;->c:LQ3/a;

    .line 8
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 4

    .line 1
    sget-object v0, Lc4/c$a;->a:[I

    .line 3
    iget-object v1, p0, Lc4/c;->c:LQ3/a;

    .line 5
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 8
    move-result v1

    .line 9
    aget v0, v0, v1

    .line 11
    const/4 v1, 0x1

    .line 12
    if-eq v0, v1, :cond_32

    .line 14
    const/4 v1, 0x2

    .line 15
    if-eq v0, v1, :cond_2c

    .line 17
    const/4 v1, 0x3

    .line 18
    if-eq v0, v1, :cond_26

    .line 20
    const/4 v1, 0x4

    .line 21
    if-eq v0, v1, :cond_20

    .line 23
    new-instance v0, Lc4/c$c;

    .line 25
    invoke-static {}, LQ3/f;->b()I

    .line 28
    move-result v1

    .line 29
    invoke-direct {v0, p1, v1}, Lc4/c$c;-><init>(Lz5/b;I)V

    .line 32
    goto :goto_37

    .line 33
    :cond_20
    new-instance v0, Lc4/c$f;

    .line 35
    invoke-direct {v0, p1}, Lc4/c$f;-><init>(Lz5/b;)V

    .line 38
    goto :goto_37

    .line 39
    :cond_26
    new-instance v0, Lc4/c$d;

    .line 41
    invoke-direct {v0, p1}, Lc4/c$d;-><init>(Lz5/b;)V

    .line 44
    goto :goto_37

    .line 45
    :cond_2c
    new-instance v0, Lc4/c$e;

    .line 47
    invoke-direct {v0, p1}, Lc4/c$e;-><init>(Lz5/b;)V

    .line 50
    goto :goto_37

    .line 51
    :cond_32
    new-instance v0, Lc4/c$g;

    .line 53
    invoke-direct {v0, p1}, Lc4/c$g;-><init>(Lz5/b;)V

    .line 56
    :goto_37
    invoke-interface {p1, v0}, Lz5/b;->c(Lz5/c;)V

    .line 59
    :try_start_3a
    iget-object p1, p0, Lc4/c;->b:LQ3/h;

    .line 61
    invoke-interface {p1, v0}, LQ3/h;->subscribe(LQ3/g;)V
    :try_end_3f
    .catchall {:try_start_3a .. :try_end_3f} :catchall_40

    .line 64
    goto :goto_47

    .line 65
    :catchall_40
    move-exception p1

    .line 66
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 69
    invoke-virtual {v0, p1}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 72
    :goto_47
    return-void
.end method
