.class public final Lc4/w$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz5/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/w;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/util/concurrent/atomic/AtomicReference;

.field public final b:I


# direct methods
.method public constructor <init>(Ljava/util/concurrent/atomic/AtomicReference;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/w$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    iput p2, p0, Lc4/w$a;->b:I

    .line 8
    return-void
.end method


# virtual methods
.method public a(Lz5/b;)V
    .registers 7

    .line 1
    new-instance v0, Lc4/w$b;

    .line 3
    invoke-direct {v0, p1}, Lc4/w$b;-><init>(Lz5/b;)V

    .line 6
    invoke-interface {p1, v0}, Lz5/b;->c(Lz5/c;)V

    .line 9
    :cond_8
    :goto_8
    iget-object p1, p0, Lc4/w$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 11
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Lc4/w$c;

    .line 17
    if-eqz p1, :cond_18

    .line 19
    invoke-virtual {p1}, Lc4/w$c;->d()Z

    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_2b

    .line 25
    :cond_18
    new-instance v1, Lc4/w$c;

    .line 27
    iget-object v2, p0, Lc4/w$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 29
    iget v3, p0, Lc4/w$a;->b:I

    .line 31
    invoke-direct {v1, v2, v3}, Lc4/w$c;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    .line 34
    iget-object v2, p0, Lc4/w$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 36
    invoke-static {v2, p1, v1}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    move-result p1

    .line 40
    if-nez p1, :cond_2a

    .line 42
    goto :goto_8

    .line 43
    :cond_2a
    move-object p1, v1

    .line 44
    :cond_2b
    invoke-virtual {p1, v0}, Lc4/w$c;->a(Lc4/w$b;)Z

    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_8

    .line 50
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 53
    move-result-wide v1

    .line 54
    const-wide/high16 v3, -0x8000000000000000L

    .line 56
    cmp-long v1, v1, v3

    .line 58
    if-nez v1, :cond_3f

    .line 60
    invoke-virtual {p1, v0}, Lc4/w$c;->h(Lc4/w$b;)V

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    iput-object p1, v0, Lc4/w$b;->b:Lc4/w$c;

    .line 66
    :goto_41
    invoke-virtual {p1}, Lc4/w$c;->g()V

    .line 69
    return-void
.end method
