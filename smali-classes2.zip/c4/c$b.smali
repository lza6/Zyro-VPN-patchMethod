.class public abstract Lc4/c$b;
.super Ljava/util/concurrent/atomic/AtomicLong;
.source "SourceFile"

# interfaces
.implements LQ3/g;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public final b:LX3/e;


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/c$b;->a:Lz5/b;

    .line 6
    new-instance p1, LX3/e;

    .line 8
    invoke-direct {p1}, LX3/e;-><init>()V

    .line 11
    iput-object p1, p0, Lc4/c$b;->b:LX3/e;

    .line 13
    return-void
.end method


# virtual methods
.method public a()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    :try_start_7
    iget-object v0, p0, Lc4/c$b;->a:Lz5/b;

    .line 10
    invoke-interface {v0}, Lz5/b;->onComplete()V
    :try_end_c
    .catchall {:try_start_7 .. :try_end_c} :catchall_12

    .line 13
    iget-object v0, p0, Lc4/c$b;->b:LX3/e;

    .line 15
    invoke-virtual {v0}, LX3/e;->dispose()V

    .line 18
    return-void

    .line 19
    :catchall_12
    move-exception v0

    .line 20
    iget-object v1, p0, Lc4/c$b;->b:LX3/e;

    .line 22
    invoke-virtual {v1}, LX3/e;->dispose()V

    .line 25
    throw v0
.end method

.method public c(Ljava/lang/Throwable;)Z
    .registers 3

    .line 1
    if-nez p1, :cond_9

    .line 3
    new-instance p1, Ljava/lang/NullPointerException;

    .line 5
    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 7
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 10
    :cond_9
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_11

    .line 16
    const/4 p1, 0x0

    .line 17
    return p1

    .line 18
    :cond_11
    :try_start_11
    iget-object v0, p0, Lc4/c$b;->a:Lz5/b;

    .line 20
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V
    :try_end_16
    .catchall {:try_start_11 .. :try_end_16} :catchall_1d

    .line 23
    iget-object p1, p0, Lc4/c$b;->b:LX3/e;

    .line 25
    invoke-virtual {p1}, LX3/e;->dispose()V

    .line 28
    const/4 p1, 0x1

    .line 29
    return p1

    .line 30
    :catchall_1d
    move-exception p1

    .line 31
    iget-object v0, p0, Lc4/c$b;->b:LX3/e;

    .line 33
    invoke-virtual {v0}, LX3/e;->dispose()V

    .line 36
    throw p1
.end method

.method public final cancel()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/c$b;->b:LX3/e;

    .line 3
    invoke-virtual {v0}, LX3/e;->dispose()V

    .line 6
    invoke-virtual {p0}, Lc4/c$b;->h()V

    .line 9
    return-void
.end method

.method public final d()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/c$b;->b:LX3/e;

    .line 3
    invoke-virtual {v0}, LX3/e;->d()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final e(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, Lc4/c$b;->i(Ljava/lang/Throwable;)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_9

    .line 7
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 10
    :cond_9
    return-void
.end method

.method public final f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_c

    .line 7
    invoke-static {p0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 10
    invoke-virtual {p0}, Lc4/c$b;->g()V

    .line 13
    :cond_c
    return-void
.end method

.method public g()V
    .registers 1

    .line 1
    return-void
.end method

.method public h()V
    .registers 1

    .line 1
    return-void
.end method

.method public i(Ljava/lang/Throwable;)Z
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lc4/c$b;->c(Ljava/lang/Throwable;)Z

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 8
    move-result-object v0

    .line 9
    invoke-super {p0}, Ljava/util/concurrent/atomic/AtomicLong;->toString()Ljava/lang/String;

    .line 12
    move-result-object v1

    .line 13
    filled-new-array {v0, v1}, [Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    const-string v1, "%s{%s}"

    .line 19
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    move-result-object v0

    .line 23
    return-object v0
.end method
