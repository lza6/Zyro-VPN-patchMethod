.class public abstract Lc4/b$b;
.super Ljava/util/concurrent/atomic/AtomicInteger;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements Lc4/b$f;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# instance fields
.field public final a:Lc4/b$e;

.field public final b:LW3/e;

.field public final c:I

.field public final d:I

.field public e:Lz5/c;

.field public f:I

.field public g:LZ3/j;

.field public volatile h:Z

.field public volatile i:Z

.field public final j:Lk4/c;

.field public volatile k:Z

.field public l:I


# direct methods
.method public constructor <init>(LW3/e;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/b$b;->b:LW3/e;

    .line 6
    iput p2, p0, Lc4/b$b;->c:I

    .line 8
    shr-int/lit8 p1, p2, 0x2

    .line 10
    sub-int/2addr p2, p1

    .line 11
    iput p2, p0, Lc4/b$b;->d:I

    .line 13
    new-instance p1, Lc4/b$e;

    .line 15
    invoke-direct {p1, p0}, Lc4/b$e;-><init>(Lc4/b$f;)V

    .line 18
    iput-object p1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 20
    new-instance p1, Lk4/c;

    .line 22
    invoke-direct {p1}, Lk4/c;-><init>()V

    .line 25
    iput-object p1, p0, Lc4/b$b;->j:Lk4/c;

    .line 27
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget v0, p0, Lc4/b$b;->l:I

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eq v0, v1, :cond_1d

    .line 6
    iget-object v0, p0, Lc4/b$b;->g:LZ3/j;

    .line 8
    invoke-interface {v0, p1}, LZ3/j;->offer(Ljava/lang/Object;)Z

    .line 11
    move-result p1

    .line 12
    if-nez p1, :cond_1d

    .line 14
    iget-object p1, p0, Lc4/b$b;->e:Lz5/c;

    .line 16
    invoke-interface {p1}, Lz5/c;->cancel()V

    .line 19
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 21
    const-string v0, "Queue full?!"

    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    invoke-interface {p0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 29
    return-void

    .line 30
    :cond_1d
    invoke-virtual {p0}, Lc4/b$b;->h()V

    .line 33
    return-void
.end method

.method public final c(Lz5/c;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/b$b;->e:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_49

    .line 9
    iput-object p1, p0, Lc4/b$b;->e:Lz5/c;

    .line 11
    instance-of v0, p1, LZ3/g;

    .line 13
    if-eqz v0, :cond_37

    .line 15
    move-object v0, p1

    .line 16
    check-cast v0, LZ3/g;

    .line 18
    const/4 v1, 0x3

    .line 19
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x1

    .line 24
    if-ne v1, v2, :cond_26

    .line 26
    iput v1, p0, Lc4/b$b;->l:I

    .line 28
    iput-object v0, p0, Lc4/b$b;->g:LZ3/j;

    .line 30
    iput-boolean v2, p0, Lc4/b$b;->h:Z

    .line 32
    invoke-virtual {p0}, Lc4/b$b;->i()V

    .line 35
    invoke-virtual {p0}, Lc4/b$b;->h()V

    .line 38
    return-void

    .line 39
    :cond_26
    const/4 v2, 0x2

    .line 40
    if-ne v1, v2, :cond_37

    .line 42
    iput v1, p0, Lc4/b$b;->l:I

    .line 44
    iput-object v0, p0, Lc4/b$b;->g:LZ3/j;

    .line 46
    invoke-virtual {p0}, Lc4/b$b;->i()V

    .line 49
    iget v0, p0, Lc4/b$b;->c:I

    .line 51
    int-to-long v0, v0

    .line 52
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 55
    return-void

    .line 56
    :cond_37
    new-instance v0, Lg4/a;

    .line 58
    iget v1, p0, Lc4/b$b;->c:I

    .line 60
    invoke-direct {v0, v1}, Lg4/a;-><init>(I)V

    .line 63
    iput-object v0, p0, Lc4/b$b;->g:LZ3/j;

    .line 65
    invoke-virtual {p0}, Lc4/b$b;->i()V

    .line 68
    iget v0, p0, Lc4/b$b;->c:I

    .line 70
    int-to-long v0, v0

    .line 71
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 74
    :cond_49
    return-void
.end method

.method public final d()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lc4/b$b;->k:Z

    .line 4
    invoke-virtual {p0}, Lc4/b$b;->h()V

    .line 7
    return-void
.end method

.method public abstract h()V
.end method

.method public abstract i()V
.end method

.method public final onComplete()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lc4/b$b;->h:Z

    .line 4
    invoke-virtual {p0}, Lc4/b$b;->h()V

    .line 7
    return-void
.end method
