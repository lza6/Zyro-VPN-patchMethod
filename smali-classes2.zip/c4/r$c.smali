.class public final Lc4/r$c;
.super Lc4/r$a;
.source "SourceFile"

# interfaces
.implements LQ3/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final n:Lz5/b;


# direct methods
.method public constructor <init>(Lz5/b;LQ3/r$b;ZI)V
    .registers 5

    .line 1
    invoke-direct {p0, p2, p3, p4}, Lc4/r$a;-><init>(LQ3/r$b;ZI)V

    .line 4
    iput-object p1, p0, Lc4/r$c;->n:Lz5/b;

    .line 6
    return-void
.end method


# virtual methods
.method public c(Lz5/c;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/r$a;->f:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_4c

    .line 9
    iput-object p1, p0, Lc4/r$a;->f:Lz5/c;

    .line 11
    instance-of v0, p1, LZ3/g;

    .line 13
    if-eqz v0, :cond_38

    .line 15
    move-object v0, p1

    .line 16
    check-cast v0, LZ3/g;

    .line 18
    const/4 v1, 0x7

    .line 19
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x1

    .line 24
    if-ne v1, v2, :cond_25

    .line 26
    iput v2, p0, Lc4/r$a;->k:I

    .line 28
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 30
    iput-boolean v2, p0, Lc4/r$a;->i:Z

    .line 32
    iget-object p1, p0, Lc4/r$c;->n:Lz5/b;

    .line 34
    invoke-interface {p1, p0}, Lz5/b;->c(Lz5/c;)V

    .line 37
    return-void

    .line 38
    :cond_25
    const/4 v2, 0x2

    .line 39
    if-ne v1, v2, :cond_38

    .line 41
    iput v2, p0, Lc4/r$a;->k:I

    .line 43
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 45
    iget-object v0, p0, Lc4/r$c;->n:Lz5/b;

    .line 47
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 50
    iget v0, p0, Lc4/r$a;->c:I

    .line 52
    int-to-long v0, v0

    .line 53
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 56
    return-void

    .line 57
    :cond_38
    new-instance v0, Lg4/a;

    .line 59
    iget v1, p0, Lc4/r$a;->c:I

    .line 61
    invoke-direct {v0, v1}, Lg4/a;-><init>(I)V

    .line 64
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 66
    iget-object v0, p0, Lc4/r$c;->n:Lz5/b;

    .line 68
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 71
    iget v0, p0, Lc4/r$a;->c:I

    .line 73
    int-to-long v0, v0

    .line 74
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 77
    :cond_4c
    return-void
.end method

.method public h()V
    .registers 13

    .line 1
    iget-object v0, p0, Lc4/r$c;->n:Lz5/b;

    .line 3
    iget-object v1, p0, Lc4/r$a;->g:LZ3/j;

    .line 5
    iget-wide v2, p0, Lc4/r$a;->l:J

    .line 7
    const/4 v4, 0x1

    .line 8
    move v5, v4

    .line 9
    :cond_8
    :goto_8
    iget-object v6, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 11
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 14
    move-result-wide v6

    .line 15
    :cond_e
    :goto_e
    cmp-long v8, v2, v6

    .line 17
    if-eqz v8, :cond_61

    .line 19
    iget-boolean v9, p0, Lc4/r$a;->i:Z

    .line 21
    :try_start_14
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 24
    move-result-object v10
    :try_end_18
    .catchall {:try_start_14 .. :try_end_18} :catchall_4c

    .line 25
    if-nez v10, :cond_1c

    .line 27
    move v11, v4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v11, 0x0

    .line 30
    :goto_1d
    invoke-virtual {p0, v9, v11, v0}, Lc4/r$a;->d(ZZLz5/b;)Z

    .line 33
    move-result v9

    .line 34
    if-eqz v9, :cond_24

    .line 36
    return-void

    .line 37
    :cond_24
    if-eqz v11, :cond_27

    .line 39
    goto :goto_61

    .line 40
    :cond_27
    invoke-interface {v0, v10}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 43
    const-wide/16 v8, 0x1

    .line 45
    add-long/2addr v2, v8

    .line 46
    iget v8, p0, Lc4/r$a;->d:I

    .line 48
    int-to-long v8, v8

    .line 49
    cmp-long v8, v2, v8

    .line 51
    if-nez v8, :cond_e

    .line 53
    const-wide v8, 0x7fffffffffffffffL

    .line 58
    cmp-long v8, v6, v8

    .line 60
    if-eqz v8, :cond_44

    .line 62
    iget-object v6, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 64
    neg-long v7, v2

    .line 65
    invoke-virtual {v6, v7, v8}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 68
    move-result-wide v6

    .line 69
    :cond_44
    iget-object v8, p0, Lc4/r$a;->f:Lz5/c;

    .line 71
    invoke-interface {v8, v2, v3}, Lz5/c;->f(J)V

    .line 74
    const-wide/16 v2, 0x0

    .line 76
    goto :goto_e

    .line 77
    :catchall_4c
    move-exception v2

    .line 78
    invoke-static {v2}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 81
    iget-object v3, p0, Lc4/r$a;->f:Lz5/c;

    .line 83
    invoke-interface {v3}, Lz5/c;->cancel()V

    .line 86
    invoke-interface {v1}, LZ3/j;->clear()V

    .line 89
    invoke-interface {v0, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 92
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 94
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 97
    return-void

    .line 98
    :cond_61
    :goto_61
    if-nez v8, :cond_70

    .line 100
    iget-boolean v6, p0, Lc4/r$a;->i:Z

    .line 102
    invoke-interface {v1}, LZ3/j;->isEmpty()Z

    .line 105
    move-result v7

    .line 106
    invoke-virtual {p0, v6, v7, v0}, Lc4/r$a;->d(ZZLz5/b;)Z

    .line 109
    move-result v6

    .line 110
    if-eqz v6, :cond_70

    .line 112
    return-void

    .line 113
    :cond_70
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 116
    move-result v6

    .line 117
    if-ne v5, v6, :cond_80

    .line 119
    iput-wide v2, p0, Lc4/r$a;->l:J

    .line 121
    neg-int v5, v5

    .line 122
    invoke-virtual {p0, v5}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 125
    move-result v5

    .line 126
    if-nez v5, :cond_8

    .line 128
    return-void

    .line 129
    :cond_80
    move v5, v6

    .line 130
    goto :goto_8
.end method

.method public i()V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    :cond_1
    iget-boolean v1, p0, Lc4/r$a;->h:Z

    .line 4
    if-eqz v1, :cond_6

    .line 6
    return-void

    .line 7
    :cond_6
    iget-boolean v1, p0, Lc4/r$a;->i:Z

    .line 9
    iget-object v2, p0, Lc4/r$c;->n:Lz5/b;

    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-interface {v2, v3}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 15
    if-eqz v1, :cond_25

    .line 17
    iget-object v0, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 19
    if-eqz v0, :cond_1a

    .line 21
    iget-object v1, p0, Lc4/r$c;->n:Lz5/b;

    .line 23
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 26
    goto :goto_1f

    .line 27
    :cond_1a
    iget-object v0, p0, Lc4/r$c;->n:Lz5/b;

    .line 29
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 32
    :goto_1f
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 34
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 37
    return-void

    .line 38
    :cond_25
    neg-int v0, v0

    .line 39
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_1

    .line 45
    return-void
.end method

.method public j()V
    .registers 10

    .line 1
    iget-object v0, p0, Lc4/r$c;->n:Lz5/b;

    .line 3
    iget-object v1, p0, Lc4/r$a;->g:LZ3/j;

    .line 5
    iget-wide v2, p0, Lc4/r$a;->l:J

    .line 7
    const/4 v4, 0x1

    .line 8
    :cond_7
    :goto_7
    iget-object v5, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 10
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 13
    move-result-wide v5

    .line 14
    :goto_d
    cmp-long v7, v2, v5

    .line 16
    if-eqz v7, :cond_3e

    .line 18
    :try_start_11
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 21
    move-result-object v7
    :try_end_15
    .catchall {:try_start_11 .. :try_end_15} :catchall_2c

    .line 22
    iget-boolean v8, p0, Lc4/r$a;->h:Z

    .line 24
    if-eqz v8, :cond_1a

    .line 26
    return-void

    .line 27
    :cond_1a
    if-nez v7, :cond_25

    .line 29
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 32
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 34
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 37
    return-void

    .line 38
    :cond_25
    invoke-interface {v0, v7}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 41
    const-wide/16 v7, 0x1

    .line 43
    add-long/2addr v2, v7

    .line 44
    goto :goto_d

    .line 45
    :catchall_2c
    move-exception v1

    .line 46
    invoke-static {v1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 49
    iget-object v2, p0, Lc4/r$a;->f:Lz5/c;

    .line 51
    invoke-interface {v2}, Lz5/c;->cancel()V

    .line 54
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 57
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 59
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 62
    return-void

    .line 63
    :cond_3e
    iget-boolean v5, p0, Lc4/r$a;->h:Z

    .line 65
    if-eqz v5, :cond_43

    .line 67
    return-void

    .line 68
    :cond_43
    invoke-interface {v1}, LZ3/j;->isEmpty()Z

    .line 71
    move-result v5

    .line 72
    if-eqz v5, :cond_52

    .line 74
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 77
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 79
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 82
    return-void

    .line 83
    :cond_52
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 86
    move-result v5

    .line 87
    if-ne v4, v5, :cond_62

    .line 89
    iput-wide v2, p0, Lc4/r$a;->l:J

    .line 91
    neg-int v4, v4

    .line 92
    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 95
    move-result v4

    .line 96
    if-nez v4, :cond_7

    .line 98
    return-void

    .line 99
    :cond_62
    move v4, v5

    .line 100
    goto :goto_7
.end method

.method public poll()Ljava/lang/Object;
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 3
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_25

    .line 9
    iget v1, p0, Lc4/r$a;->k:I

    .line 11
    const/4 v2, 0x1

    .line 12
    if-eq v1, v2, :cond_25

    .line 14
    iget-wide v1, p0, Lc4/r$a;->l:J

    .line 16
    const-wide/16 v3, 0x1

    .line 18
    add-long/2addr v1, v3

    .line 19
    iget v3, p0, Lc4/r$a;->d:I

    .line 21
    int-to-long v3, v3

    .line 22
    cmp-long v3, v1, v3

    .line 24
    if-nez v3, :cond_23

    .line 26
    const-wide/16 v3, 0x0

    .line 28
    iput-wide v3, p0, Lc4/r$a;->l:J

    .line 30
    iget-object v3, p0, Lc4/r$a;->f:Lz5/c;

    .line 32
    invoke-interface {v3, v1, v2}, Lz5/c;->f(J)V

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    iput-wide v1, p0, Lc4/r$a;->l:J

    .line 38
    :cond_25
    :goto_25
    return-object v0
.end method
