.class public final Lc4/d;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/d$a;,
        Lc4/d$b;
    }
.end annotation


# instance fields
.field public final c:LW3/d;

.field public final d:LW3/d;

.field public final e:LW3/a;

.field public final f:LW3/a;


# direct methods
.method public constructor <init>(LQ3/f;LW3/d;LW3/d;LW3/a;LW3/a;)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/d;->c:LW3/d;

    .line 6
    iput-object p3, p0, Lc4/d;->d:LW3/d;

    .line 8
    iput-object p4, p0, Lc4/d;->e:LW3/a;

    .line 10
    iput-object p5, p0, Lc4/d;->f:LW3/a;

    .line 12
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 10

    .line 1
    instance-of v0, p1, LZ3/a;

    .line 3
    if-eqz v0, :cond_1b

    .line 5
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 7
    new-instance v7, Lc4/d$a;

    .line 9
    move-object v2, p1

    .line 10
    check-cast v2, LZ3/a;

    .line 12
    iget-object v3, p0, Lc4/d;->c:LW3/d;

    .line 14
    iget-object v4, p0, Lc4/d;->d:LW3/d;

    .line 16
    iget-object v5, p0, Lc4/d;->e:LW3/a;

    .line 18
    iget-object v6, p0, Lc4/d;->f:LW3/a;

    .line 20
    move-object v1, v7

    .line 21
    invoke-direct/range {v1 .. v6}, Lc4/d$a;-><init>(LZ3/a;LW3/d;LW3/d;LW3/a;LW3/a;)V

    .line 24
    invoke-virtual {v0, v7}, LQ3/f;->H(LQ3/i;)V

    .line 27
    goto :goto_2f

    .line 28
    :cond_1b
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 30
    new-instance v7, Lc4/d$b;

    .line 32
    iget-object v3, p0, Lc4/d;->c:LW3/d;

    .line 34
    iget-object v4, p0, Lc4/d;->d:LW3/d;

    .line 36
    iget-object v5, p0, Lc4/d;->e:LW3/a;

    .line 38
    iget-object v6, p0, Lc4/d;->f:LW3/a;

    .line 40
    move-object v1, v7

    .line 41
    move-object v2, p1

    .line 42
    invoke-direct/range {v1 .. v6}, Lc4/d$b;-><init>(Lz5/b;LW3/d;LW3/d;LW3/a;LW3/a;)V

    .line 45
    invoke-virtual {v0, v7}, LQ3/f;->H(LQ3/i;)V

    .line 48
    :goto_2f
    return-void
.end method
