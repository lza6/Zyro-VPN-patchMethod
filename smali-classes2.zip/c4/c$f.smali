.class public final Lc4/c$f;
.super Lc4/c$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# instance fields
.field public final c:Ljava/util/concurrent/atomic/AtomicReference;

.field public d:Ljava/lang/Throwable;

.field public volatile e:Z

.field public final f:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/c$b;-><init>(Lz5/b;)V

    .line 4
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 9
    iput-object p1, p0, Lc4/c$f;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 11
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 13
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 16
    iput-object p1, p0, Lc4/c$f;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 18
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/c$f;->e:Z

    .line 3
    if-nez v0, :cond_20

    .line 5
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    goto :goto_20

    .line 12
    :cond_b
    if-nez p1, :cond_18

    .line 14
    new-instance p1, Ljava/lang/NullPointerException;

    .line 16
    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {p0, p1}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 24
    return-void

    .line 25
    :cond_18
    iget-object v0, p0, Lc4/c$f;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 27
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 30
    invoke-virtual {p0}, Lc4/c$f;->j()V

    .line 33
    :cond_20
    :goto_20
    return-void
.end method

.method public g()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lc4/c$f;->j()V

    .line 4
    return-void
.end method

.method public h()V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/c$f;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_e

    .line 9
    iget-object v0, p0, Lc4/c$f;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 15
    :cond_e
    return-void
.end method

.method public i(Ljava/lang/Throwable;)Z
    .registers 4

    .line 1
    iget-boolean v0, p0, Lc4/c$f;->e:Z

    .line 3
    if-nez v0, :cond_20

    .line 5
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    goto :goto_20

    .line 12
    :cond_b
    if-nez p1, :cond_17

    .line 14
    new-instance v0, Ljava/lang/NullPointerException;

    .line 16
    const-string v1, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 18
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {p0, v0}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 24
    :cond_17
    iput-object p1, p0, Lc4/c$f;->d:Ljava/lang/Throwable;

    .line 26
    const/4 p1, 0x1

    .line 27
    iput-boolean p1, p0, Lc4/c$f;->e:Z

    .line 29
    invoke-virtual {p0}, Lc4/c$f;->j()V

    .line 32
    return p1

    .line 33
    :cond_20
    :goto_20
    const/4 p1, 0x0

    .line 34
    return p1
.end method

.method public j()V
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lc4/c$f;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 5
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_b

    .line 11
    return-void

    .line 12
    :cond_b
    iget-object v1, v0, Lc4/c$b;->a:Lz5/b;

    .line 14
    iget-object v2, v0, Lc4/c$f;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 16
    const/4 v3, 0x1

    .line 17
    move v4, v3

    .line 18
    :cond_11
    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 21
    move-result-wide v5

    .line 22
    const-wide/16 v7, 0x0

    .line 24
    move-wide v9, v7

    .line 25
    :goto_18
    cmp-long v11, v9, v5

    .line 27
    const/4 v12, 0x0

    .line 28
    const/4 v13, 0x0

    .line 29
    if-eqz v11, :cond_4f

    .line 31
    invoke-virtual/range {p0 .. p0}, Lc4/c$b;->d()Z

    .line 34
    move-result v14

    .line 35
    if-eqz v14, :cond_28

    .line 37
    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 40
    return-void

    .line 41
    :cond_28
    iget-boolean v14, v0, Lc4/c$f;->e:Z

    .line 43
    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    move-result-object v15

    .line 47
    if-nez v15, :cond_33

    .line 49
    move/from16 v16, v3

    .line 51
    goto :goto_35

    .line 52
    :cond_33
    move/from16 v16, v12

    .line 54
    :goto_35
    if-eqz v14, :cond_45

    .line 56
    if-eqz v16, :cond_45

    .line 58
    iget-object v1, v0, Lc4/c$f;->d:Ljava/lang/Throwable;

    .line 60
    if-eqz v1, :cond_41

    .line 62
    invoke-virtual {v0, v1}, Lc4/c$b;->c(Ljava/lang/Throwable;)Z

    .line 65
    goto :goto_44

    .line 66
    :cond_41
    invoke-virtual/range {p0 .. p0}, Lc4/c$b;->a()V

    .line 69
    :goto_44
    return-void

    .line 70
    :cond_45
    if-eqz v16, :cond_48

    .line 72
    goto :goto_4f

    .line 73
    :cond_48
    invoke-interface {v1, v15}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 76
    const-wide/16 v11, 0x1

    .line 78
    add-long/2addr v9, v11

    .line 79
    goto :goto_18

    .line 80
    :cond_4f
    :goto_4f
    if-nez v11, :cond_74

    .line 82
    invoke-virtual/range {p0 .. p0}, Lc4/c$b;->d()Z

    .line 85
    move-result v5

    .line 86
    if-eqz v5, :cond_5b

    .line 88
    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 91
    return-void

    .line 92
    :cond_5b
    iget-boolean v5, v0, Lc4/c$f;->e:Z

    .line 94
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 97
    move-result-object v6

    .line 98
    if-nez v6, :cond_64

    .line 100
    move v12, v3

    .line 101
    :cond_64
    if-eqz v5, :cond_74

    .line 103
    if-eqz v12, :cond_74

    .line 105
    iget-object v1, v0, Lc4/c$f;->d:Ljava/lang/Throwable;

    .line 107
    if-eqz v1, :cond_70

    .line 109
    invoke-virtual {v0, v1}, Lc4/c$b;->c(Ljava/lang/Throwable;)Z

    .line 112
    goto :goto_73

    .line 113
    :cond_70
    invoke-virtual/range {p0 .. p0}, Lc4/c$b;->a()V

    .line 116
    :goto_73
    return-void

    .line 117
    :cond_74
    cmp-long v5, v9, v7

    .line 119
    if-eqz v5, :cond_7b

    .line 121
    invoke-static {v0, v9, v10}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 124
    :cond_7b
    iget-object v5, v0, Lc4/c$f;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 126
    neg-int v4, v4

    .line 127
    invoke-virtual {v5, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 130
    move-result v4

    .line 131
    if-nez v4, :cond_11

    .line 133
    return-void
.end method
