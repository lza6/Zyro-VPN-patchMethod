.class public final Lc4/s;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/s$a;
    }
.end annotation


# instance fields
.field public final c:I

.field public final d:Z

.field public final e:Z

.field public final f:LW3/a;


# direct methods
.method public constructor <init>(LQ3/f;IZZLW3/a;)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput p2, p0, Lc4/s;->c:I

    .line 6
    iput-boolean p3, p0, Lc4/s;->d:Z

    .line 8
    iput-boolean p4, p0, Lc4/s;->e:Z

    .line 10
    iput-object p5, p0, Lc4/s;->f:LW3/a;

    .line 12
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    new-instance v7, Lc4/s$a;

    .line 5
    iget v3, p0, Lc4/s;->c:I

    .line 7
    iget-boolean v4, p0, Lc4/s;->d:Z

    .line 9
    iget-boolean v5, p0, Lc4/s;->e:Z

    .line 11
    iget-object v6, p0, Lc4/s;->f:LW3/a;

    .line 13
    move-object v1, v7

    .line 14
    move-object v2, p1

    .line 15
    invoke-direct/range {v1 .. v6}, Lc4/s$a;-><init>(Lz5/b;IZZLW3/a;)V

    .line 18
    invoke-virtual {v0, v7}, LQ3/f;->H(LQ3/i;)V

    .line 21
    return-void
.end method
