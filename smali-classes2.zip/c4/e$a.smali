.class public final Lc4/e$a;
.super Lj4/c;
.source "SourceFile"

# interfaces
.implements LQ3/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final c:J

.field public final d:Ljava/lang/Object;

.field public final e:Z

.field public f:Lz5/c;

.field public g:J

.field public h:Z


# direct methods
.method public constructor <init>(Lz5/b;JLjava/lang/Object;Z)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Lj4/c;-><init>(Lz5/b;)V

    .line 4
    iput-wide p2, p0, Lc4/e$a;->c:J

    .line 6
    iput-object p4, p0, Lc4/e$a;->d:Ljava/lang/Object;

    .line 8
    iput-boolean p5, p0, Lc4/e$a;->e:Z

    .line 10
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lc4/e$a;->h:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget-wide v0, p0, Lc4/e$a;->g:J

    .line 8
    iget-wide v2, p0, Lc4/e$a;->c:J

    .line 10
    cmp-long v2, v0, v2

    .line 12
    if-nez v2, :cond_19

    .line 14
    const/4 v0, 0x1

    .line 15
    iput-boolean v0, p0, Lc4/e$a;->h:Z

    .line 17
    iget-object v0, p0, Lc4/e$a;->f:Lz5/c;

    .line 19
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 22
    invoke-virtual {p0, p1}, Lj4/c;->d(Ljava/lang/Object;)V

    .line 25
    return-void

    .line 26
    :cond_19
    const-wide/16 v2, 0x1

    .line 28
    add-long/2addr v0, v2

    .line 29
    iput-wide v0, p0, Lc4/e$a;->g:J

    .line 31
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/e$a;->f:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_17

    .line 9
    iput-object p1, p0, Lc4/e$a;->f:Lz5/c;

    .line 11
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 13
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 16
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 24
    :cond_17
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    invoke-super {p0}, Lj4/c;->cancel()V

    .line 4
    iget-object v0, p0, Lc4/e$a;->f:Lz5/c;

    .line 6
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 9
    return-void
.end method

.method public onComplete()V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/e$a;->h:Z

    .line 3
    if-nez v0, :cond_23

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lc4/e$a;->h:Z

    .line 8
    iget-object v0, p0, Lc4/e$a;->d:Ljava/lang/Object;

    .line 10
    if-nez v0, :cond_20

    .line 12
    iget-boolean v0, p0, Lc4/e$a;->e:Z

    .line 14
    if-eqz v0, :cond_1a

    .line 16
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 18
    new-instance v1, Ljava/util/NoSuchElementException;

    .line 20
    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    .line 23
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 26
    goto :goto_23

    .line 27
    :cond_1a
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 29
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 32
    goto :goto_23

    .line 33
    :cond_20
    invoke-virtual {p0, v0}, Lj4/c;->d(Ljava/lang/Object;)V

    .line 36
    :cond_23
    :goto_23
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/e$a;->h:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Lc4/e$a;->h:Z

    .line 12
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 14
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 17
    return-void
.end method
