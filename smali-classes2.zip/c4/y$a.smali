.class public final Lc4/y$a;
.super Lj4/c;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public c:Lz5/c;


# direct methods
.method public constructor <init>(Lz5/b;Ljava/util/Collection;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lj4/c;-><init>(Lz5/b;)V

    .line 4
    iput-object p2, p0, Lj4/c;->b:Ljava/lang/Object;

    .line 6
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj4/c;->b:Ljava/lang/Object;

    .line 3
    check-cast v0, Ljava/util/Collection;

    .line 5
    if-eqz v0, :cond_9

    .line 7
    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 10
    :cond_9
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/y$a;->c:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_17

    .line 9
    iput-object p1, p0, Lc4/y$a;->c:Lz5/c;

    .line 11
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 13
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 16
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 24
    :cond_17
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    invoke-super {p0}, Lj4/c;->cancel()V

    .line 4
    iget-object v0, p0, Lc4/y$a;->c:Lz5/c;

    .line 6
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 9
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lj4/c;->b:Ljava/lang/Object;

    .line 3
    invoke-virtual {p0, v0}, Lj4/c;->d(Ljava/lang/Object;)V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lj4/c;->b:Ljava/lang/Object;

    .line 4
    iget-object v0, p0, Lj4/c;->a:Lz5/b;

    .line 6
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 9
    return-void
.end method
