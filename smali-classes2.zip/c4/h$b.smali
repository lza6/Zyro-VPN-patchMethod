.class public final Lc4/h$b;
.super Li4/b;
.source "SourceFile"

# interfaces
.implements LZ3/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final f:LW3/g;


# direct methods
.method public constructor <init>(Lz5/b;LW3/g;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Li4/b;-><init>(Lz5/b;)V

    .line 4
    iput-object p2, p0, Lc4/h$b;->f:LW3/g;

    .line 6
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    invoke-virtual {p0, p1}, Lc4/h$b;->e(Ljava/lang/Object;)Z

    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_d

    .line 7
    iget-object p1, p0, Li4/b;->b:Lz5/c;

    .line 9
    const-wide/16 v0, 0x1

    .line 11
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 14
    :cond_d
    return-void
.end method

.method public e(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    iget-boolean v0, p0, Li4/b;->d:Z

    .line 3
    if-eqz v0, :cond_6

    .line 5
    const/4 p1, 0x0

    .line 6
    return p1

    .line 7
    :cond_6
    iget v0, p0, Li4/b;->e:I

    .line 9
    const/4 v1, 0x1

    .line 10
    if-eqz v0, :cond_12

    .line 12
    iget-object p1, p0, Li4/b;->a:Lz5/b;

    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-interface {p1, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 18
    return v1

    .line 19
    :cond_12
    :try_start_12
    iget-object v0, p0, Lc4/h$b;->f:LW3/g;

    .line 21
    invoke-interface {v0, p1}, LW3/g;->test(Ljava/lang/Object;)Z

    .line 24
    move-result v0
    :try_end_18
    .catchall {:try_start_12 .. :try_end_18} :catchall_20

    .line 25
    if-eqz v0, :cond_1f

    .line 27
    iget-object v1, p0, Li4/b;->a:Lz5/b;

    .line 29
    invoke-interface {v1, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 32
    :cond_1f
    return v0

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    invoke-virtual {p0, p1}, Li4/b;->h(Ljava/lang/Throwable;)V

    .line 37
    return v1
.end method

.method public g(I)I
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Li4/b;->i(I)I

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public poll()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Li4/b;->c:LZ3/g;

    .line 3
    iget-object v1, p0, Lc4/h$b;->f:LW3/g;

    .line 5
    :cond_4
    :goto_4
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 8
    move-result-object v2

    .line 9
    if-nez v2, :cond_c

    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0

    .line 13
    :cond_c
    invoke-interface {v1, v2}, LW3/g;->test(Ljava/lang/Object;)Z

    .line 16
    move-result v3

    .line 17
    if-eqz v3, :cond_13

    .line 19
    return-object v2

    .line 20
    :cond_13
    iget v2, p0, Li4/b;->e:I

    .line 22
    const/4 v3, 0x2

    .line 23
    if-ne v2, v3, :cond_4

    .line 25
    const-wide/16 v2, 0x1

    .line 27
    invoke-interface {v0, v2, v3}, Lz5/c;->f(J)V

    .line 30
    goto :goto_4
.end method
