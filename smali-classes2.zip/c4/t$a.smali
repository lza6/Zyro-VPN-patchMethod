.class public final Lc4/t$a;
.super Ljava/util/concurrent/atomic/AtomicLong;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public final b:LW3/d;

.field public c:Lz5/c;

.field public d:Z


# direct methods
.method public constructor <init>(Lz5/b;LW3/d;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/t$a;->a:Lz5/b;

    .line 6
    iput-object p2, p0, Lc4/t$a;->b:LW3/d;

    .line 8
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lc4/t$a;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 9
    move-result-wide v0

    .line 10
    const-wide/16 v2, 0x0

    .line 12
    cmp-long v0, v0, v2

    .line 14
    if-eqz v0, :cond_1a

    .line 16
    iget-object v0, p0, Lc4/t$a;->a:Lz5/b;

    .line 18
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 21
    const-wide/16 v0, 0x1

    .line 23
    invoke-static {p0, v0, v1}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 26
    goto :goto_2a

    .line 27
    :cond_1a
    :try_start_1a
    iget-object v0, p0, Lc4/t$a;->b:LW3/d;

    .line 29
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_1f
    .catchall {:try_start_1a .. :try_end_1f} :catchall_20

    .line 32
    goto :goto_2a

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 37
    invoke-virtual {p0}, Lc4/t$a;->cancel()V

    .line 40
    invoke-virtual {p0, p1}, Lc4/t$a;->onError(Ljava/lang/Throwable;)V

    .line 43
    :goto_2a
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/t$a;->c:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_17

    .line 9
    iput-object p1, p0, Lc4/t$a;->c:Lz5/c;

    .line 11
    iget-object v0, p0, Lc4/t$a;->a:Lz5/b;

    .line 13
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 16
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 24
    :cond_17
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/t$a;->c:Lz5/c;

    .line 3
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 6
    return-void
.end method

.method public f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_9

    .line 7
    invoke-static {p0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 10
    :cond_9
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/t$a;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lc4/t$a;->d:Z

    .line 9
    iget-object v0, p0, Lc4/t$a;->a:Lz5/b;

    .line 11
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 14
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/t$a;->d:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Lc4/t$a;->d:Z

    .line 12
    iget-object v0, p0, Lc4/t$a;->a:Lz5/b;

    .line 14
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 17
    return-void
.end method
