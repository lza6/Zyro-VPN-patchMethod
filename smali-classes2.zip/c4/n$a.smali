.class public Lc4/n$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/q;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public b:LT3/b;


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/n$a;->a:Lz5/b;

    .line 6
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lc4/n$a;->b:LT3/b;

    .line 3
    iget-object p1, p0, Lc4/n$a;->a:Lz5/b;

    .line 5
    invoke-interface {p1, p0}, Lz5/b;->c(Lz5/c;)V

    .line 8
    return-void
.end method

.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/n$a;->a:Lz5/b;

    .line 3
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 6
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/n$a;->b:LT3/b;

    .line 3
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 6
    return-void
.end method

.method public f(J)V
    .registers 3

    .line 1
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/n$a;->a:Lz5/b;

    .line 3
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/n$a;->a:Lz5/b;

    .line 3
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 6
    return-void
.end method
