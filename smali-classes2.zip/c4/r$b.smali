.class public final Lc4/r$b;
.super Lc4/r$a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final n:LZ3/a;

.field public o:J


# direct methods
.method public constructor <init>(LZ3/a;LQ3/r$b;ZI)V
    .registers 5

    .line 1
    invoke-direct {p0, p2, p3, p4}, Lc4/r$a;-><init>(LQ3/r$b;ZI)V

    .line 4
    iput-object p1, p0, Lc4/r$b;->n:LZ3/a;

    .line 6
    return-void
.end method


# virtual methods
.method public c(Lz5/c;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/r$a;->f:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_4c

    .line 9
    iput-object p1, p0, Lc4/r$a;->f:Lz5/c;

    .line 11
    instance-of v0, p1, LZ3/g;

    .line 13
    if-eqz v0, :cond_38

    .line 15
    move-object v0, p1

    .line 16
    check-cast v0, LZ3/g;

    .line 18
    const/4 v1, 0x7

    .line 19
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x1

    .line 24
    if-ne v1, v2, :cond_25

    .line 26
    iput v2, p0, Lc4/r$a;->k:I

    .line 28
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 30
    iput-boolean v2, p0, Lc4/r$a;->i:Z

    .line 32
    iget-object p1, p0, Lc4/r$b;->n:LZ3/a;

    .line 34
    invoke-interface {p1, p0}, LQ3/i;->c(Lz5/c;)V

    .line 37
    return-void

    .line 38
    :cond_25
    const/4 v2, 0x2

    .line 39
    if-ne v1, v2, :cond_38

    .line 41
    iput v2, p0, Lc4/r$a;->k:I

    .line 43
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 45
    iget-object v0, p0, Lc4/r$b;->n:LZ3/a;

    .line 47
    invoke-interface {v0, p0}, LQ3/i;->c(Lz5/c;)V

    .line 50
    iget v0, p0, Lc4/r$a;->c:I

    .line 52
    int-to-long v0, v0

    .line 53
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 56
    return-void

    .line 57
    :cond_38
    new-instance v0, Lg4/a;

    .line 59
    iget v1, p0, Lc4/r$a;->c:I

    .line 61
    invoke-direct {v0, v1}, Lg4/a;-><init>(I)V

    .line 64
    iput-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 66
    iget-object v0, p0, Lc4/r$b;->n:LZ3/a;

    .line 68
    invoke-interface {v0, p0}, LQ3/i;->c(Lz5/c;)V

    .line 71
    iget v0, p0, Lc4/r$a;->c:I

    .line 73
    int-to-long v0, v0

    .line 74
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 77
    :cond_4c
    return-void
.end method

.method public h()V
    .registers 15

    .line 1
    iget-object v0, p0, Lc4/r$b;->n:LZ3/a;

    .line 3
    iget-object v1, p0, Lc4/r$a;->g:LZ3/j;

    .line 5
    iget-wide v2, p0, Lc4/r$a;->l:J

    .line 7
    iget-wide v4, p0, Lc4/r$b;->o:J

    .line 9
    const/4 v6, 0x1

    .line 10
    move v7, v6

    .line 11
    :cond_a
    :goto_a
    iget-object v8, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 13
    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 16
    move-result-wide v8

    .line 17
    :cond_10
    :goto_10
    cmp-long v10, v2, v8

    .line 19
    if-eqz v10, :cond_57

    .line 21
    iget-boolean v11, p0, Lc4/r$a;->i:Z

    .line 23
    :try_start_16
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 26
    move-result-object v12
    :try_end_1a
    .catchall {:try_start_16 .. :try_end_1a} :catchall_42

    .line 27
    if-nez v12, :cond_1e

    .line 29
    move v13, v6

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    const/4 v13, 0x0

    .line 32
    :goto_1f
    invoke-virtual {p0, v11, v13, v0}, Lc4/r$a;->d(ZZLz5/b;)Z

    .line 35
    move-result v11

    .line 36
    if-eqz v11, :cond_26

    .line 38
    return-void

    .line 39
    :cond_26
    if-eqz v13, :cond_29

    .line 41
    goto :goto_57

    .line 42
    :cond_29
    invoke-interface {v0, v12}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 45
    move-result v10

    .line 46
    const-wide/16 v11, 0x1

    .line 48
    if-eqz v10, :cond_32

    .line 50
    add-long/2addr v2, v11

    .line 51
    :cond_32
    add-long/2addr v4, v11

    .line 52
    iget v10, p0, Lc4/r$a;->d:I

    .line 54
    int-to-long v10, v10

    .line 55
    cmp-long v10, v4, v10

    .line 57
    if-nez v10, :cond_10

    .line 59
    iget-object v10, p0, Lc4/r$a;->f:Lz5/c;

    .line 61
    invoke-interface {v10, v4, v5}, Lz5/c;->f(J)V

    .line 64
    const-wide/16 v4, 0x0

    .line 66
    goto :goto_10

    .line 67
    :catchall_42
    move-exception v2

    .line 68
    invoke-static {v2}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 71
    iget-object v3, p0, Lc4/r$a;->f:Lz5/c;

    .line 73
    invoke-interface {v3}, Lz5/c;->cancel()V

    .line 76
    invoke-interface {v1}, LZ3/j;->clear()V

    .line 79
    invoke-interface {v0, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 82
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 84
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 87
    return-void

    .line 88
    :cond_57
    :goto_57
    if-nez v10, :cond_66

    .line 90
    iget-boolean v8, p0, Lc4/r$a;->i:Z

    .line 92
    invoke-interface {v1}, LZ3/j;->isEmpty()Z

    .line 95
    move-result v9

    .line 96
    invoke-virtual {p0, v8, v9, v0}, Lc4/r$a;->d(ZZLz5/b;)Z

    .line 99
    move-result v8

    .line 100
    if-eqz v8, :cond_66

    .line 102
    return-void

    .line 103
    :cond_66
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 106
    move-result v8

    .line 107
    if-ne v7, v8, :cond_78

    .line 109
    iput-wide v2, p0, Lc4/r$a;->l:J

    .line 111
    iput-wide v4, p0, Lc4/r$b;->o:J

    .line 113
    neg-int v7, v7

    .line 114
    invoke-virtual {p0, v7}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 117
    move-result v7

    .line 118
    if-nez v7, :cond_a

    .line 120
    return-void

    .line 121
    :cond_78
    move v7, v8

    .line 122
    goto :goto_a
.end method

.method public i()V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    :cond_1
    iget-boolean v1, p0, Lc4/r$a;->h:Z

    .line 4
    if-eqz v1, :cond_6

    .line 6
    return-void

    .line 7
    :cond_6
    iget-boolean v1, p0, Lc4/r$a;->i:Z

    .line 9
    iget-object v2, p0, Lc4/r$b;->n:LZ3/a;

    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-interface {v2, v3}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 15
    if-eqz v1, :cond_25

    .line 17
    iget-object v0, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 19
    if-eqz v0, :cond_1a

    .line 21
    iget-object v1, p0, Lc4/r$b;->n:LZ3/a;

    .line 23
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 26
    goto :goto_1f

    .line 27
    :cond_1a
    iget-object v0, p0, Lc4/r$b;->n:LZ3/a;

    .line 29
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 32
    :goto_1f
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 34
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 37
    return-void

    .line 38
    :cond_25
    neg-int v0, v0

    .line 39
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_1

    .line 45
    return-void
.end method

.method public j()V
    .registers 10

    .line 1
    iget-object v0, p0, Lc4/r$b;->n:LZ3/a;

    .line 3
    iget-object v1, p0, Lc4/r$a;->g:LZ3/j;

    .line 5
    iget-wide v2, p0, Lc4/r$a;->l:J

    .line 7
    const/4 v4, 0x1

    .line 8
    :cond_7
    :goto_7
    iget-object v5, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 10
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 13
    move-result-wide v5

    .line 14
    :cond_d
    :goto_d
    cmp-long v7, v2, v5

    .line 16
    if-eqz v7, :cond_41

    .line 18
    :try_start_11
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 21
    move-result-object v7
    :try_end_15
    .catchall {:try_start_11 .. :try_end_15} :catchall_2f

    .line 22
    iget-boolean v8, p0, Lc4/r$a;->h:Z

    .line 24
    if-eqz v8, :cond_1a

    .line 26
    return-void

    .line 27
    :cond_1a
    if-nez v7, :cond_25

    .line 29
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 32
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 34
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 37
    return-void

    .line 38
    :cond_25
    invoke-interface {v0, v7}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 41
    move-result v7

    .line 42
    if-eqz v7, :cond_d

    .line 44
    const-wide/16 v7, 0x1

    .line 46
    add-long/2addr v2, v7

    .line 47
    goto :goto_d

    .line 48
    :catchall_2f
    move-exception v1

    .line 49
    invoke-static {v1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 52
    iget-object v2, p0, Lc4/r$a;->f:Lz5/c;

    .line 54
    invoke-interface {v2}, Lz5/c;->cancel()V

    .line 57
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 60
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 62
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 65
    return-void

    .line 66
    :cond_41
    iget-boolean v5, p0, Lc4/r$a;->h:Z

    .line 68
    if-eqz v5, :cond_46

    .line 70
    return-void

    .line 71
    :cond_46
    invoke-interface {v1}, LZ3/j;->isEmpty()Z

    .line 74
    move-result v5

    .line 75
    if-eqz v5, :cond_55

    .line 77
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 80
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 82
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 85
    return-void

    .line 86
    :cond_55
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 89
    move-result v5

    .line 90
    if-ne v4, v5, :cond_65

    .line 92
    iput-wide v2, p0, Lc4/r$a;->l:J

    .line 94
    neg-int v4, v4

    .line 95
    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 98
    move-result v4

    .line 99
    if-nez v4, :cond_7

    .line 101
    return-void

    .line 102
    :cond_65
    move v4, v5

    .line 103
    goto :goto_7
.end method

.method public poll()Ljava/lang/Object;
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 3
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_25

    .line 9
    iget v1, p0, Lc4/r$a;->k:I

    .line 11
    const/4 v2, 0x1

    .line 12
    if-eq v1, v2, :cond_25

    .line 14
    iget-wide v1, p0, Lc4/r$b;->o:J

    .line 16
    const-wide/16 v3, 0x1

    .line 18
    add-long/2addr v1, v3

    .line 19
    iget v3, p0, Lc4/r$a;->d:I

    .line 21
    int-to-long v3, v3

    .line 22
    cmp-long v3, v1, v3

    .line 24
    if-nez v3, :cond_23

    .line 26
    const-wide/16 v3, 0x0

    .line 28
    iput-wide v3, p0, Lc4/r$b;->o:J

    .line 30
    iget-object v3, p0, Lc4/r$a;->f:Lz5/c;

    .line 32
    invoke-interface {v3, v1, v2}, Lz5/c;->f(J)V

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    iput-wide v1, p0, Lc4/r$b;->o:J

    .line 38
    :cond_25
    :goto_25
    return-object v0
.end method
