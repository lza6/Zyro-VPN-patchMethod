.class public final Lc4/x$a;
.super LQ3/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final b:Ljava/lang/Object;

.field public final c:LW3/e;


# direct methods
.method public constructor <init>(Ljava/lang/Object;LW3/e;)V
    .registers 3

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/x$a;->b:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, Lc4/x$a;->c:LW3/e;

    .line 8
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lc4/x$a;->c:LW3/e;

    .line 3
    iget-object v1, p0, Lc4/x$a;->b:Ljava/lang/Object;

    .line 5
    invoke-interface {v0, v1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    const-string v1, "The mapper returned a null Publisher"

    .line 11
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lz5/a;
    :try_end_10
    .catchall {:try_start_0 .. :try_end_10} :catchall_35

    .line 17
    instance-of v1, v0, Ljava/util/concurrent/Callable;

    .line 19
    if-eqz v1, :cond_31

    .line 21
    :try_start_14
    check-cast v0, Ljava/util/concurrent/Callable;

    .line 23
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 26
    move-result-object v0
    :try_end_1a
    .catchall {:try_start_14 .. :try_end_1a} :catchall_29

    .line 27
    if-nez v0, :cond_20

    .line 29
    invoke-static {p1}, Lj4/d;->a(Lz5/b;)V

    .line 32
    return-void

    .line 33
    :cond_20
    new-instance v1, Lj4/e;

    .line 35
    invoke-direct {v1, p1, v0}, Lj4/e;-><init>(Lz5/b;Ljava/lang/Object;)V

    .line 38
    invoke-interface {p1, v1}, Lz5/b;->c(Lz5/c;)V

    .line 41
    goto :goto_34

    .line 42
    :catchall_29
    move-exception v0

    .line 43
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 46
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 49
    return-void

    .line 50
    :cond_31
    invoke-interface {v0, p1}, Lz5/a;->a(Lz5/b;)V

    .line 53
    :goto_34
    return-void

    .line 54
    :catchall_35
    move-exception v0

    .line 55
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 58
    return-void
.end method
