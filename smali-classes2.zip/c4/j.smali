.class public final Lc4/j;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/j$a;
    }
.end annotation


# instance fields
.field public final c:LW3/e;

.field public final d:Z

.field public final e:I


# direct methods
.method public constructor <init>(LQ3/f;LW3/e;ZI)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/j;->c:LW3/e;

    .line 6
    iput-boolean p3, p0, Lc4/j;->d:Z

    .line 8
    iput p4, p0, Lc4/j;->e:I

    .line 10
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    new-instance v1, Lc4/j$a;

    .line 5
    iget-object v2, p0, Lc4/j;->c:LW3/e;

    .line 7
    iget-boolean v3, p0, Lc4/j;->d:Z

    .line 9
    iget v4, p0, Lc4/j;->e:I

    .line 11
    invoke-direct {v1, p1, v2, v3, v4}, Lc4/j$a;-><init>(Lz5/b;LW3/e;ZI)V

    .line 14
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 17
    return-void
.end method
