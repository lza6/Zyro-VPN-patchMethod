.class public final Lc4/c$e;
.super Lc4/c$h;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/c$h;-><init>(Lz5/b;)V

    .line 4
    return-void
.end method


# virtual methods
.method public j()V
    .registers 3

    .line 1
    new-instance v0, LU3/c;

    .line 3
    const-string v1, "create: could not emit value due to lack of requests"

    .line 5
    invoke-direct {v0, v1}, LU3/c;-><init>(Ljava/lang/String;)V

    .line 8
    invoke-virtual {p0, v0}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 11
    return-void
.end method
