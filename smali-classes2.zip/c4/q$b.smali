.class public final Lc4/q$b;
.super Li4/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final f:LW3/e;


# direct methods
.method public constructor <init>(Lz5/b;LW3/e;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Li4/b;-><init>(Lz5/b;)V

    .line 4
    iput-object p2, p0, Lc4/q$b;->f:LW3/e;

    .line 6
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Li4/b;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget v0, p0, Li4/b;->e:I

    .line 8
    if-eqz v0, :cond_10

    .line 10
    iget-object p1, p0, Li4/b;->a:Lz5/b;

    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-interface {p1, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 16
    return-void

    .line 17
    :cond_10
    :try_start_10
    iget-object v0, p0, Lc4/q$b;->f:LW3/e;

    .line 19
    invoke-interface {v0, p1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    move-result-object p1

    .line 23
    const-string v0, "The mapper function returned a null value."

    .line 25
    invoke-static {p1, v0}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 28
    move-result-object p1
    :try_end_1c
    .catchall {:try_start_10 .. :try_end_1c} :catchall_22

    .line 29
    iget-object v0, p0, Li4/b;->a:Lz5/b;

    .line 31
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 34
    return-void

    .line 35
    :catchall_22
    move-exception p1

    .line 36
    invoke-virtual {p0, p1}, Li4/b;->h(Ljava/lang/Throwable;)V

    .line 39
    return-void
.end method

.method public g(I)I
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Li4/b;->i(I)I

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public poll()Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object v0, p0, Li4/b;->c:LZ3/g;

    .line 3
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_15

    .line 9
    iget-object v1, p0, Lc4/q$b;->f:LW3/e;

    .line 11
    invoke-interface {v1, v0}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    move-result-object v0

    .line 15
    const-string v1, "The mapper function returned a null value."

    .line 17
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 20
    move-result-object v0

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    const/4 v0, 0x0

    .line 23
    :goto_16
    return-object v0
.end method
