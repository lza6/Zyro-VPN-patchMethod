.class public final Lc4/l;
.super LQ3/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/l$a;,
        Lc4/l$b;,
        Lc4/l$c;
    }
.end annotation


# instance fields
.field public final b:[Ljava/lang/Object;


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/l;->b:[Ljava/lang/Object;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 5

    .line 1
    instance-of v0, p1, LZ3/a;

    .line 3
    if-eqz v0, :cond_12

    .line 5
    new-instance v0, Lc4/l$a;

    .line 7
    move-object v1, p1

    .line 8
    check-cast v1, LZ3/a;

    .line 10
    iget-object v2, p0, Lc4/l;->b:[Ljava/lang/Object;

    .line 12
    invoke-direct {v0, v1, v2}, Lc4/l$a;-><init>(LZ3/a;[Ljava/lang/Object;)V

    .line 15
    invoke-interface {p1, v0}, Lz5/b;->c(Lz5/c;)V

    .line 18
    goto :goto_1c

    .line 19
    :cond_12
    new-instance v0, Lc4/l$b;

    .line 21
    iget-object v1, p0, Lc4/l;->b:[Ljava/lang/Object;

    .line 23
    invoke-direct {v0, p1, v1}, Lc4/l$b;-><init>(Lz5/b;[Ljava/lang/Object;)V

    .line 26
    invoke-interface {p1, v0}, Lz5/b;->c(Lz5/c;)V

    .line 29
    :goto_1c
    return-void
.end method
