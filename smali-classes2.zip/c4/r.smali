.class public final Lc4/r;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/r$b;,
        Lc4/r$c;,
        Lc4/r$a;
    }
.end annotation


# instance fields
.field public final c:LQ3/r;

.field public final d:Z

.field public final e:I


# direct methods
.method public constructor <init>(LQ3/f;LQ3/r;ZI)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/r;->c:LQ3/r;

    .line 6
    iput-boolean p3, p0, Lc4/r;->d:Z

    .line 8
    iput p4, p0, Lc4/r;->e:I

    .line 10
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lc4/r;->c:LQ3/r;

    .line 3
    invoke-virtual {v0}, LQ3/r;->a()LQ3/r$b;

    .line 6
    move-result-object v0

    .line 7
    instance-of v1, p1, LZ3/a;

    .line 9
    if-eqz v1, :cond_1b

    .line 11
    iget-object v1, p0, Lc4/a;->b:LQ3/f;

    .line 13
    new-instance v2, Lc4/r$b;

    .line 15
    check-cast p1, LZ3/a;

    .line 17
    iget-boolean v3, p0, Lc4/r;->d:Z

    .line 19
    iget v4, p0, Lc4/r;->e:I

    .line 21
    invoke-direct {v2, p1, v0, v3, v4}, Lc4/r$b;-><init>(LZ3/a;LQ3/r$b;ZI)V

    .line 24
    invoke-virtual {v1, v2}, LQ3/f;->H(LQ3/i;)V

    .line 27
    goto :goto_29

    .line 28
    :cond_1b
    iget-object v1, p0, Lc4/a;->b:LQ3/f;

    .line 30
    new-instance v2, Lc4/r$c;

    .line 32
    iget-boolean v3, p0, Lc4/r;->d:Z

    .line 34
    iget v4, p0, Lc4/r;->e:I

    .line 36
    invoke-direct {v2, p1, v0, v3, v4}, Lc4/r$c;-><init>(Lz5/b;LQ3/r$b;ZI)V

    .line 39
    invoke-virtual {v1, v2}, LQ3/f;->H(LQ3/i;)V

    .line 42
    :goto_29
    return-void
.end method
