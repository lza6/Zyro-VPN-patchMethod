.class public final Lc4/n;
.super LQ3/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/n$a;
    }
.end annotation


# instance fields
.field public final b:LQ3/o;


# direct methods
.method public constructor <init>(LQ3/o;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/n;->b:LQ3/o;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/n;->b:LQ3/o;

    .line 3
    new-instance v1, Lc4/n$a;

    .line 5
    invoke-direct {v1, p1}, Lc4/n$a;-><init>(Lz5/b;)V

    .line 8
    invoke-virtual {v0, v1}, LQ3/o;->c(LQ3/q;)V

    .line 11
    return-void
.end method
