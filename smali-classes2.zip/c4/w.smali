.class public final Lc4/w;
.super LV3/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/w$a;,
        Lc4/w$b;,
        Lc4/w$c;
    }
.end annotation


# instance fields
.field public final b:LQ3/f;

.field public final c:Ljava/util/concurrent/atomic/AtomicReference;

.field public final d:I

.field public final e:Lz5/a;


# direct methods
.method public constructor <init>(Lz5/a;LQ3/f;Ljava/util/concurrent/atomic/AtomicReference;I)V
    .registers 5

    .line 1
    invoke-direct {p0}, LV3/a;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/w;->e:Lz5/a;

    .line 6
    iput-object p2, p0, Lc4/w;->b:LQ3/f;

    .line 8
    iput-object p3, p0, Lc4/w;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    iput p4, p0, Lc4/w;->d:I

    .line 12
    return-void
.end method

.method public static M(LQ3/f;I)LV3/a;
    .registers 5

    .line 1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 6
    new-instance v1, Lc4/w$a;

    .line 8
    invoke-direct {v1, v0, p1}, Lc4/w$a;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    .line 11
    new-instance v2, Lc4/w;

    .line 13
    invoke-direct {v2, v1, p0, v0, p1}, Lc4/w;-><init>(Lz5/a;LQ3/f;Ljava/util/concurrent/atomic/AtomicReference;I)V

    .line 16
    invoke-static {v2}, Ll4/a;->o(LV3/a;)LV3/a;

    .line 19
    move-result-object p0

    .line 20
    return-object p0
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/w;->e:Lz5/a;

    .line 3
    invoke-interface {v0, p1}, Lz5/a;->a(Lz5/b;)V

    .line 6
    return-void
.end method

.method public L(LW3/d;)V
    .registers 6

    .line 1
    :goto_0
    iget-object v0, p0, Lc4/w;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lc4/w$c;

    .line 9
    if-eqz v0, :cond_10

    .line 11
    invoke-virtual {v0}, Lc4/w$c;->d()Z

    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_23

    .line 17
    :cond_10
    new-instance v1, Lc4/w$c;

    .line 19
    iget-object v2, p0, Lc4/w;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    iget v3, p0, Lc4/w;->d:I

    .line 23
    invoke-direct {v1, v2, v3}, Lc4/w$c;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    .line 26
    iget-object v2, p0, Lc4/w;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 28
    invoke-static {v2, v0, v1}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_22

    .line 34
    goto :goto_0

    .line 35
    :cond_22
    move-object v0, v1

    .line 36
    :cond_23
    iget-object v1, v0, Lc4/w$c;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 38
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 41
    move-result v1

    .line 42
    const/4 v2, 0x0

    .line 43
    if-nez v1, :cond_36

    .line 45
    iget-object v1, v0, Lc4/w$c;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 47
    const/4 v3, 0x1

    .line 48
    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 51
    move-result v1

    .line 52
    if-eqz v1, :cond_36

    .line 54
    move v2, v3

    .line 55
    :cond_36
    :try_start_36
    invoke-interface {p1, v0}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_39
    .catchall {:try_start_36 .. :try_end_39} :catchall_41

    .line 58
    if-eqz v2, :cond_40

    .line 60
    iget-object p1, p0, Lc4/w;->b:LQ3/f;

    .line 62
    invoke-virtual {p1, v0}, LQ3/f;->H(LQ3/i;)V

    .line 65
    :cond_40
    return-void

    .line 66
    :catchall_41
    move-exception p1

    .line 67
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 70
    invoke-static {p1}, Lk4/g;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    .line 73
    move-result-object p1

    .line 74
    throw p1
.end method
