.class public final Lc4/z$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/t;

.field public b:Lz5/c;

.field public c:Ljava/util/Collection;


# direct methods
.method public constructor <init>(LQ3/t;Ljava/util/Collection;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/z$a;->a:LQ3/t;

    .line 6
    iput-object p2, p0, Lc4/z$a;->c:Ljava/util/Collection;

    .line 8
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/z$a;->c:Ljava/util/Collection;

    .line 3
    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 6
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_17

    .line 9
    iput-object p1, p0, Lc4/z$a;->b:Lz5/c;

    .line 11
    iget-object v0, p0, Lc4/z$a;->a:LQ3/t;

    .line 13
    invoke-interface {v0, p0}, LQ3/t;->a(LT3/b;)V

    .line 16
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 24
    :cond_17
    return-void
.end method

.method public d()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 3
    sget-object v1, Lj4/g;->a:Lj4/g;

    .line 5
    if-ne v0, v1, :cond_8

    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    return v0
.end method

.method public dispose()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 3
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 6
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 8
    iput-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 10
    return-void
.end method

.method public onComplete()V
    .registers 3

    .line 1
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 3
    iput-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 5
    iget-object v0, p0, Lc4/z$a;->a:LQ3/t;

    .line 7
    iget-object v1, p0, Lc4/z$a;->c:Ljava/util/Collection;

    .line 9
    invoke-interface {v0, v1}, LQ3/t;->onSuccess(Ljava/lang/Object;)V

    .line 12
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lc4/z$a;->c:Ljava/util/Collection;

    .line 4
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 6
    iput-object v0, p0, Lc4/z$a;->b:Lz5/c;

    .line 8
    iget-object v0, p0, Lc4/z$a;->a:LQ3/t;

    .line 10
    invoke-interface {v0, p1}, LQ3/t;->onError(Ljava/lang/Throwable;)V

    .line 13
    return-void
.end method
