.class public final Lc4/f;
.super LQ3/j;
.source "SourceFile"

# interfaces
.implements LZ3/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/f$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/f;

.field public final b:J


# direct methods
.method public constructor <init>(LQ3/f;J)V
    .registers 4

    .line 1
    invoke-direct {p0}, LQ3/j;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/f;->a:LQ3/f;

    .line 6
    iput-wide p2, p0, Lc4/f;->b:J

    .line 8
    return-void
.end method


# virtual methods
.method public d()LQ3/f;
    .registers 8

    .line 1
    new-instance v6, Lc4/e;

    .line 3
    iget-object v1, p0, Lc4/f;->a:LQ3/f;

    .line 5
    iget-wide v2, p0, Lc4/f;->b:J

    .line 7
    const/4 v4, 0x0

    .line 8
    const/4 v5, 0x0

    .line 9
    move-object v0, v6

    .line 10
    invoke-direct/range {v0 .. v5}, Lc4/e;-><init>(LQ3/f;JLjava/lang/Object;Z)V

    .line 13
    invoke-static {v6}, Ll4/a;->k(LQ3/f;)LQ3/f;

    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public u(LQ3/l;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/f;->a:LQ3/f;

    .line 3
    new-instance v1, Lc4/f$a;

    .line 5
    iget-wide v2, p0, Lc4/f;->b:J

    .line 7
    invoke-direct {v1, p1, v2, v3}, Lc4/f$a;-><init>(LQ3/l;J)V

    .line 10
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 13
    return-void
.end method
