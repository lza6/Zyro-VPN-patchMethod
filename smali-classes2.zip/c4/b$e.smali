.class public final Lc4/b$e;
.super Lj4/f;
.source "SourceFile"

# interfaces
.implements LQ3/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field public final h:Lc4/b$f;

.field public i:J


# direct methods
.method public constructor <init>(Lc4/b$f;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lj4/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/b$e;->h:Lc4/b$f;

    .line 6
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-wide v0, p0, Lc4/b$e;->i:J

    .line 3
    const-wide/16 v2, 0x1

    .line 5
    add-long/2addr v0, v2

    .line 6
    iput-wide v0, p0, Lc4/b$e;->i:J

    .line 8
    iget-object v0, p0, Lc4/b$e;->h:Lc4/b$f;

    .line 10
    invoke-interface {v0, p1}, Lc4/b$f;->a(Ljava/lang/Object;)V

    .line 13
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lj4/f;->i(Lz5/c;)V

    .line 4
    return-void
.end method

.method public onComplete()V
    .registers 6

    .line 1
    iget-wide v0, p0, Lc4/b$e;->i:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-eqz v4, :cond_d

    .line 9
    iput-wide v2, p0, Lc4/b$e;->i:J

    .line 11
    invoke-virtual {p0, v0, v1}, Lj4/f;->h(J)V

    .line 14
    :cond_d
    iget-object v0, p0, Lc4/b$e;->h:Lc4/b$f;

    .line 16
    invoke-interface {v0}, Lc4/b$f;->d()V

    .line 19
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 7

    .line 1
    iget-wide v0, p0, Lc4/b$e;->i:J

    .line 3
    const-wide/16 v2, 0x0

    .line 5
    cmp-long v4, v0, v2

    .line 7
    if-eqz v4, :cond_d

    .line 9
    iput-wide v2, p0, Lc4/b$e;->i:J

    .line 11
    invoke-virtual {p0, v0, v1}, Lj4/f;->h(J)V

    .line 14
    :cond_d
    iget-object v0, p0, Lc4/b$e;->h:Lc4/b$f;

    .line 16
    invoke-interface {v0, p1}, Lc4/b$f;->g(Ljava/lang/Throwable;)V

    .line 19
    return-void
.end method
