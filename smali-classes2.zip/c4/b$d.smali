.class public final Lc4/b$d;
.super Lc4/b$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field public final m:Lz5/b;

.field public final n:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public constructor <init>(Lz5/b;LW3/e;I)V
    .registers 4

    .line 1
    invoke-direct {p0, p2, p3}, Lc4/b$b;-><init>(LW3/e;I)V

    .line 4
    iput-object p1, p0, Lc4/b$d;->m:Lz5/b;

    .line 6
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 8
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 11
    iput-object p1, p0, Lc4/b$d;->n:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 13
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_25

    .line 7
    const/4 v0, 0x0

    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_25

    .line 15
    iget-object v2, p0, Lc4/b$d;->m:Lz5/b;

    .line 17
    invoke-interface {v2, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 20
    invoke-virtual {p0, v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 23
    move-result p1

    .line 24
    if-eqz p1, :cond_1a

    .line 26
    return-void

    .line 27
    :cond_1a
    iget-object p1, p0, Lc4/b$d;->m:Lz5/b;

    .line 29
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 31
    invoke-virtual {v0}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 34
    move-result-object v0

    .line 35
    invoke-interface {p1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 38
    :cond_25
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/b$b;->i:Z

    .line 3
    if-nez v0, :cond_11

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lc4/b$b;->i:Z

    .line 8
    iget-object v0, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 10
    invoke-virtual {v0}, Lj4/f;->cancel()V

    .line 13
    iget-object v0, p0, Lc4/b$b;->e:Lz5/c;

    .line 15
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 18
    :cond_11
    return-void
.end method

.method public f(J)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 3
    invoke-virtual {v0, p1, p2}, Lj4/f;->f(J)V

    .line 6
    return-void
.end method

.method public g(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 3
    invoke-virtual {v0, p1}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1f

    .line 9
    iget-object p1, p0, Lc4/b$b;->e:Lz5/c;

    .line 11
    invoke-interface {p1}, Lz5/c;->cancel()V

    .line 14
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 17
    move-result p1

    .line 18
    if-nez p1, :cond_22

    .line 20
    iget-object p1, p0, Lc4/b$d;->m:Lz5/b;

    .line 22
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 24
    invoke-virtual {v0}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 27
    move-result-object v0

    .line 28
    invoke-interface {p1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 31
    goto :goto_22

    .line 32
    :cond_1f
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 35
    :cond_22
    :goto_22
    return-void
.end method

.method public h()V
    .registers 8

    .line 1
    iget-object v0, p0, Lc4/b$d;->n:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_f3

    .line 9
    :cond_8
    :goto_8
    iget-boolean v0, p0, Lc4/b$b;->i:Z

    .line 11
    if-eqz v0, :cond_d

    .line 13
    return-void

    .line 14
    :cond_d
    iget-boolean v0, p0, Lc4/b$b;->k:Z

    .line 16
    if-nez v0, :cond_eb

    .line 18
    iget-boolean v0, p0, Lc4/b$b;->h:Z

    .line 20
    :try_start_13
    iget-object v1, p0, Lc4/b$b;->g:LZ3/j;

    .line 22
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 25
    move-result-object v1
    :try_end_19
    .catchall {:try_start_13 .. :try_end_19} :catchall_d1

    .line 26
    const/4 v2, 0x0

    .line 27
    const/4 v3, 0x1

    .line 28
    if-nez v1, :cond_1f

    .line 30
    move v4, v3

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v4, v2

    .line 33
    :goto_20
    if-eqz v0, :cond_2a

    .line 35
    if-eqz v4, :cond_2a

    .line 37
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 39
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 42
    return-void

    .line 43
    :cond_2a
    if-nez v4, :cond_eb

    .line 45
    :try_start_2c
    iget-object v0, p0, Lc4/b$b;->b:LW3/e;

    .line 47
    invoke-interface {v0, v1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    move-result-object v0

    .line 51
    const-string v1, "The mapper returned a null Publisher"

    .line 53
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Lz5/a;
    :try_end_3a
    .catchall {:try_start_2c .. :try_end_3a} :catchall_b7

    .line 59
    iget v1, p0, Lc4/b$b;->l:I

    .line 61
    if-eq v1, v3, :cond_50

    .line 63
    iget v1, p0, Lc4/b$b;->f:I

    .line 65
    add-int/2addr v1, v3

    .line 66
    iget v4, p0, Lc4/b$b;->d:I

    .line 68
    if-ne v1, v4, :cond_4e

    .line 70
    iput v2, p0, Lc4/b$b;->f:I

    .line 72
    iget-object v4, p0, Lc4/b$b;->e:Lz5/c;

    .line 74
    int-to-long v5, v1

    .line 75
    invoke-interface {v4, v5, v6}, Lz5/c;->f(J)V

    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    iput v1, p0, Lc4/b$b;->f:I

    .line 81
    :cond_50
    :goto_50
    instance-of v1, v0, Ljava/util/concurrent/Callable;

    .line 83
    if-eqz v1, :cond_af

    .line 85
    check-cast v0, Ljava/util/concurrent/Callable;

    .line 87
    :try_start_56
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 90
    move-result-object v0
    :try_end_5a
    .catchall {:try_start_56 .. :try_end_5a} :catchall_95

    .line 91
    if-nez v0, :cond_5d

    .line 93
    goto :goto_8

    .line 94
    :cond_5d
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 96
    invoke-virtual {v1}, Lj4/f;->g()Z

    .line 99
    move-result v1

    .line 100
    if-eqz v1, :cond_88

    .line 102
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 105
    move-result v1

    .line 106
    if-nez v1, :cond_8

    .line 108
    invoke-virtual {p0, v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_8

    .line 114
    iget-object v1, p0, Lc4/b$d;->m:Lz5/b;

    .line 116
    invoke-interface {v1, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 119
    invoke-virtual {p0, v3, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 122
    move-result v0

    .line 123
    if-nez v0, :cond_8

    .line 125
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 127
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 129
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 132
    move-result-object v1

    .line 133
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 136
    return-void

    .line 137
    :cond_88
    iput-boolean v3, p0, Lc4/b$b;->k:Z

    .line 139
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 141
    new-instance v2, Lc4/b$g;

    .line 143
    invoke-direct {v2, v0, v1}, Lc4/b$g;-><init>(Ljava/lang/Object;Lz5/b;)V

    .line 146
    invoke-virtual {v1, v2}, Lj4/f;->i(Lz5/c;)V

    .line 149
    goto :goto_eb

    .line 150
    :catchall_95
    move-exception v0

    .line 151
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 154
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 156
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 159
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 161
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 164
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 166
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 168
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 171
    move-result-object v1

    .line 172
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 175
    return-void

    .line 176
    :cond_af
    iput-boolean v3, p0, Lc4/b$b;->k:Z

    .line 178
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 180
    invoke-interface {v0, v1}, Lz5/a;->a(Lz5/b;)V

    .line 183
    goto :goto_eb

    .line 184
    :catchall_b7
    move-exception v0

    .line 185
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 188
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 190
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 193
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 195
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 198
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 200
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 202
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 205
    move-result-object v1

    .line 206
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 209
    return-void

    .line 210
    :catchall_d1
    move-exception v0

    .line 211
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 214
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 216
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 219
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 221
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 224
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 226
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 228
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 231
    move-result-object v1

    .line 232
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 235
    return-void

    .line 236
    :cond_eb
    :goto_eb
    iget-object v0, p0, Lc4/b$d;->n:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 238
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 241
    move-result v0

    .line 242
    if-nez v0, :cond_8

    .line 244
    :cond_f3
    return-void
.end method

.method public i()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/b$d;->m:Lz5/b;

    .line 3
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 3
    invoke-virtual {v0, p1}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1f

    .line 9
    iget-object p1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 11
    invoke-virtual {p1}, Lj4/f;->cancel()V

    .line 14
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 17
    move-result p1

    .line 18
    if-nez p1, :cond_22

    .line 20
    iget-object p1, p0, Lc4/b$d;->m:Lz5/b;

    .line 22
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 24
    invoke-virtual {v0}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 27
    move-result-object v0

    .line 28
    invoke-interface {p1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 31
    goto :goto_22

    .line 32
    :cond_1f
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 35
    :cond_22
    :goto_22
    return-void
.end method
