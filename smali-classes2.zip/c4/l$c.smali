.class public abstract Lc4/l$c;
.super Lj4/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "c"
.end annotation


# instance fields
.field public final a:[Ljava/lang/Object;

.field public b:I

.field public volatile c:Z


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lj4/b;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 6
    return-void
.end method


# virtual methods
.method public abstract a()V
.end method

.method public abstract b(J)V
.end method

.method public final cancel()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lc4/l$c;->c:Z

    .line 4
    return-void
.end method

.method public final clear()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 3
    array-length v0, v0

    .line 4
    iput v0, p0, Lc4/l$c;->b:I

    .line 6
    return-void
.end method

.method public final f(J)V
    .registers 7

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_20

    .line 7
    invoke-static {p0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 10
    move-result-wide v0

    .line 11
    const-wide/16 v2, 0x0

    .line 13
    cmp-long v0, v0, v2

    .line 15
    if-nez v0, :cond_20

    .line 17
    const-wide v0, 0x7fffffffffffffffL

    .line 22
    cmp-long v0, p1, v0

    .line 24
    if-nez v0, :cond_1d

    .line 26
    invoke-virtual {p0}, Lc4/l$c;->a()V

    .line 29
    goto :goto_20

    .line 30
    :cond_1d
    invoke-virtual {p0, p1, p2}, Lc4/l$c;->b(J)V

    .line 33
    :cond_20
    :goto_20
    return-void
.end method

.method public final g(I)I
    .registers 2

    .line 1
    and-int/lit8 p1, p1, 0x1

    .line 3
    return p1
.end method

.method public final isEmpty()Z
    .registers 3

    .line 1
    iget v0, p0, Lc4/l$c;->b:I

    .line 3
    iget-object v1, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 5
    array-length v1, v1

    .line 6
    if-ne v0, v1, :cond_9

    .line 8
    const/4 v0, 0x1

    .line 9
    goto :goto_a

    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    :goto_a
    return v0
.end method

.method public final poll()Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lc4/l$c;->b:I

    .line 3
    iget-object v1, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 5
    array-length v2, v1

    .line 6
    if-ne v0, v2, :cond_9

    .line 8
    const/4 v0, 0x0

    .line 9
    return-object v0

    .line 10
    :cond_9
    add-int/lit8 v2, v0, 0x1

    .line 12
    iput v2, p0, Lc4/l$c;->b:I

    .line 14
    aget-object v0, v1, v0

    .line 16
    const-string v1, "array element is null"

    .line 18
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method
