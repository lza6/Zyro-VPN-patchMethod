.class public final Lc4/k;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/k$a;
    }
.end annotation


# instance fields
.field public final c:LW3/e;

.field public final d:I


# direct methods
.method public constructor <init>(LQ3/f;LW3/e;I)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/k;->c:LW3/e;

    .line 6
    iput p3, p0, Lc4/k;->d:I

    .line 8
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    instance-of v1, v0, Ljava/util/concurrent/Callable;

    .line 5
    if-eqz v1, :cond_32

    .line 7
    :try_start_6
    check-cast v0, Ljava/util/concurrent/Callable;

    .line 9
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 12
    move-result-object v0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_2a

    .line 13
    if-nez v0, :cond_12

    .line 15
    invoke-static {p1}, Lj4/d;->a(Lz5/b;)V

    .line 18
    return-void

    .line 19
    :cond_12
    :try_start_12
    iget-object v1, p0, Lc4/k;->c:LW3/e;

    .line 21
    invoke-interface {v1, v0}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Ljava/lang/Iterable;

    .line 27
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 30
    move-result-object v0
    :try_end_1e
    .catchall {:try_start_12 .. :try_end_1e} :catchall_22

    .line 31
    invoke-static {p1, v0}, Lc4/m;->K(Lz5/b;Ljava/util/Iterator;)V

    .line 34
    return-void

    .line 35
    :catchall_22
    move-exception v0

    .line 36
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 39
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 42
    return-void

    .line 43
    :catchall_2a
    move-exception v0

    .line 44
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 47
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 50
    return-void

    .line 51
    :cond_32
    new-instance v1, Lc4/k$a;

    .line 53
    iget-object v2, p0, Lc4/k;->c:LW3/e;

    .line 55
    iget v3, p0, Lc4/k;->d:I

    .line 57
    invoke-direct {v1, p1, v2, v3}, Lc4/k$a;-><init>(Lz5/b;LW3/e;I)V

    .line 60
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 63
    return-void
.end method
