.class public final enum Lc4/o;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements LW3/d;


# static fields
.field public static final enum a:Lc4/o;

.field public static final synthetic b:[Lc4/o;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lc4/o;

    .line 3
    const-string v1, "INSTANCE"

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Lc4/o;-><init>(Ljava/lang/String;I)V

    .line 9
    sput-object v0, Lc4/o;->a:Lc4/o;

    .line 11
    filled-new-array {v0}, [Lc4/o;

    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lc4/o;->b:[Lc4/o;

    .line 17
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 4
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lc4/o;
    .registers 2

    .line 1
    const-class v0, Lc4/o;

    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lc4/o;

    .line 9
    return-object p0
.end method

.method public static values()[Lc4/o;
    .registers 1

    .line 1
    sget-object v0, Lc4/o;->b:[Lc4/o;

    .line 3
    invoke-virtual {v0}, [Lc4/o;->clone()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lc4/o;

    .line 9
    return-object v0
.end method


# virtual methods
.method public a(Lz5/c;)V
    .registers 4

    .line 1
    const-wide v0, 0x7fffffffffffffffL

    .line 6
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 9
    return-void
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Lz5/c;

    .line 3
    invoke-virtual {p0, p1}, Lc4/o;->a(Lz5/c;)V

    .line 6
    return-void
.end method
