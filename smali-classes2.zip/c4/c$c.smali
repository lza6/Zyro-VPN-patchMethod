.class public final Lc4/c$c;
.super Lc4/c$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final c:Lg4/b;

.field public d:Ljava/lang/Throwable;

.field public volatile e:Z

.field public final f:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public constructor <init>(Lz5/b;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lc4/c$b;-><init>(Lz5/b;)V

    .line 4
    new-instance p1, Lg4/b;

    .line 6
    invoke-direct {p1, p2}, Lg4/b;-><init>(I)V

    .line 9
    iput-object p1, p0, Lc4/c$c;->c:Lg4/b;

    .line 11
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 13
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 16
    iput-object p1, p0, Lc4/c$c;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 18
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/c$c;->e:Z

    .line 3
    if-nez v0, :cond_20

    .line 5
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    goto :goto_20

    .line 12
    :cond_b
    if-nez p1, :cond_18

    .line 14
    new-instance p1, Ljava/lang/NullPointerException;

    .line 16
    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 21
    invoke-virtual {p0, p1}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 24
    return-void

    .line 25
    :cond_18
    iget-object v0, p0, Lc4/c$c;->c:Lg4/b;

    .line 27
    invoke-virtual {v0, p1}, Lg4/b;->offer(Ljava/lang/Object;)Z

    .line 30
    invoke-virtual {p0}, Lc4/c$c;->j()V

    .line 33
    :cond_20
    :goto_20
    return-void
.end method

.method public g()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lc4/c$c;->j()V

    .line 4
    return-void
.end method

.method public h()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/c$c;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_d

    .line 9
    iget-object v0, p0, Lc4/c$c;->c:Lg4/b;

    .line 11
    invoke-virtual {v0}, Lg4/b;->clear()V

    .line 14
    :cond_d
    return-void
.end method

.method public i(Ljava/lang/Throwable;)Z
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/c$c;->e:Z

    .line 3
    if-nez v0, :cond_1d

    .line 5
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    goto :goto_1d

    .line 12
    :cond_b
    if-nez p1, :cond_14

    .line 14
    new-instance p1, Ljava/lang/NullPointerException;

    .line 16
    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 18
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 21
    :cond_14
    iput-object p1, p0, Lc4/c$c;->d:Ljava/lang/Throwable;

    .line 23
    const/4 p1, 0x1

    .line 24
    iput-boolean p1, p0, Lc4/c$c;->e:Z

    .line 26
    invoke-virtual {p0}, Lc4/c$c;->j()V

    .line 29
    return p1

    .line 30
    :cond_1d
    :goto_1d
    const/4 p1, 0x0

    .line 31
    return p1
.end method

.method public j()V
    .registers 15

    .line 1
    iget-object v0, p0, Lc4/c$c;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    iget-object v0, p0, Lc4/c$b;->a:Lz5/b;

    .line 12
    iget-object v1, p0, Lc4/c$c;->c:Lg4/b;

    .line 14
    const/4 v2, 0x1

    .line 15
    move v3, v2

    .line 16
    :cond_f
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 19
    move-result-wide v4

    .line 20
    const-wide/16 v6, 0x0

    .line 22
    move-wide v8, v6

    .line 23
    :goto_16
    cmp-long v10, v8, v4

    .line 25
    if-eqz v10, :cond_49

    .line 27
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 30
    move-result v11

    .line 31
    if-eqz v11, :cond_24

    .line 33
    invoke-virtual {v1}, Lg4/b;->clear()V

    .line 36
    return-void

    .line 37
    :cond_24
    iget-boolean v11, p0, Lc4/c$c;->e:Z

    .line 39
    invoke-virtual {v1}, Lg4/b;->poll()Ljava/lang/Object;

    .line 42
    move-result-object v12

    .line 43
    if-nez v12, :cond_2e

    .line 45
    move v13, v2

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    const/4 v13, 0x0

    .line 48
    :goto_2f
    if-eqz v11, :cond_3f

    .line 50
    if-eqz v13, :cond_3f

    .line 52
    iget-object v0, p0, Lc4/c$c;->d:Ljava/lang/Throwable;

    .line 54
    if-eqz v0, :cond_3b

    .line 56
    invoke-virtual {p0, v0}, Lc4/c$b;->c(Ljava/lang/Throwable;)Z

    .line 59
    goto :goto_3e

    .line 60
    :cond_3b
    invoke-virtual {p0}, Lc4/c$b;->a()V

    .line 63
    :goto_3e
    return-void

    .line 64
    :cond_3f
    if-eqz v13, :cond_42

    .line 66
    goto :goto_49

    .line 67
    :cond_42
    invoke-interface {v0, v12}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 70
    const-wide/16 v10, 0x1

    .line 72
    add-long/2addr v8, v10

    .line 73
    goto :goto_16

    .line 74
    :cond_49
    :goto_49
    if-nez v10, :cond_6b

    .line 76
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 79
    move-result v4

    .line 80
    if-eqz v4, :cond_55

    .line 82
    invoke-virtual {v1}, Lg4/b;->clear()V

    .line 85
    return-void

    .line 86
    :cond_55
    iget-boolean v4, p0, Lc4/c$c;->e:Z

    .line 88
    invoke-virtual {v1}, Lg4/b;->isEmpty()Z

    .line 91
    move-result v5

    .line 92
    if-eqz v4, :cond_6b

    .line 94
    if-eqz v5, :cond_6b

    .line 96
    iget-object v0, p0, Lc4/c$c;->d:Ljava/lang/Throwable;

    .line 98
    if-eqz v0, :cond_67

    .line 100
    invoke-virtual {p0, v0}, Lc4/c$b;->c(Ljava/lang/Throwable;)Z

    .line 103
    goto :goto_6a

    .line 104
    :cond_67
    invoke-virtual {p0}, Lc4/c$b;->a()V

    .line 107
    :goto_6a
    return-void

    .line 108
    :cond_6b
    cmp-long v4, v8, v6

    .line 110
    if-eqz v4, :cond_72

    .line 112
    invoke-static {p0, v8, v9}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 115
    :cond_72
    iget-object v4, p0, Lc4/c$c;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 117
    neg-int v3, v3

    .line 118
    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 121
    move-result v3

    .line 122
    if-nez v3, :cond_f

    .line 124
    return-void
.end method
