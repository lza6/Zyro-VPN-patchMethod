.class public final Lc4/t;
.super Lc4/a;
.source "SourceFile"

# interfaces
.implements LW3/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/t$a;
    }
.end annotation


# instance fields
.field public final c:LW3/d;


# direct methods
.method public constructor <init>(LQ3/f;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p0, p0, Lc4/t;->c:LW3/d;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    new-instance v1, Lc4/t$a;

    .line 5
    iget-object v2, p0, Lc4/t;->c:LW3/d;

    .line 7
    invoke-direct {v1, p1, v2}, Lc4/t$a;-><init>(Lz5/b;LW3/d;)V

    .line 10
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 13
    return-void
.end method

.method public accept(Ljava/lang/Object;)V
    .registers 2

    .line 1
    return-void
.end method
