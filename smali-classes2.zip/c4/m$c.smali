.class public final Lc4/m$c;
.super Lc4/m$a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final d:Lz5/b;


# direct methods
.method public constructor <init>(Lz5/b;Ljava/util/Iterator;)V
    .registers 3

    .line 1
    invoke-direct {p0, p2}, Lc4/m$a;-><init>(Ljava/util/Iterator;)V

    .line 4
    iput-object p1, p0, Lc4/m$c;->d:Lz5/b;

    .line 6
    return-void
.end method


# virtual methods
.method public a()V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    iget-object v1, p0, Lc4/m$c;->d:Lz5/b;

    .line 5
    :cond_4
    iget-boolean v2, p0, Lc4/m$a;->b:Z

    .line 7
    if-eqz v2, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    :try_start_9
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    move-result-object v2
    :try_end_d
    .catchall {:try_start_9 .. :try_end_d} :catchall_3d

    .line 14
    iget-boolean v3, p0, Lc4/m$a;->b:Z

    .line 16
    if-eqz v3, :cond_12

    .line 18
    return-void

    .line 19
    :cond_12
    if-nez v2, :cond_1f

    .line 21
    new-instance v0, Ljava/lang/NullPointerException;

    .line 23
    const-string v2, "Iterator.next() returned a null value"

    .line 25
    invoke-direct {v0, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 28
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 31
    return-void

    .line 32
    :cond_1f
    invoke-interface {v1, v2}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 35
    iget-boolean v2, p0, Lc4/m$a;->b:Z

    .line 37
    if-eqz v2, :cond_27

    .line 39
    return-void

    .line 40
    :cond_27
    :try_start_27
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    move-result v2
    :try_end_2b
    .catchall {:try_start_27 .. :try_end_2b} :catchall_35

    .line 44
    if-nez v2, :cond_4

    .line 46
    iget-boolean v0, p0, Lc4/m$a;->b:Z

    .line 48
    if-nez v0, :cond_34

    .line 50
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 53
    :cond_34
    return-void

    .line 54
    :catchall_35
    move-exception v0

    .line 55
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 58
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 61
    return-void

    .line 62
    :catchall_3d
    move-exception v0

    .line 63
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 66
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 69
    return-void
.end method

.method public b(J)V
    .registers 11

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    iget-object v1, p0, Lc4/m$c;->d:Lz5/b;

    .line 5
    const-wide/16 v2, 0x0

    .line 7
    :cond_6
    move-wide v4, v2

    .line 8
    :cond_7
    :goto_7
    cmp-long v6, v4, p1

    .line 10
    if-eqz v6, :cond_50

    .line 12
    iget-boolean v6, p0, Lc4/m$a;->b:Z

    .line 14
    if-eqz v6, :cond_10

    .line 16
    return-void

    .line 17
    :cond_10
    :try_start_10
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    move-result-object v6
    :try_end_14
    .catchall {:try_start_10 .. :try_end_14} :catchall_48

    .line 21
    iget-boolean v7, p0, Lc4/m$a;->b:Z

    .line 23
    if-eqz v7, :cond_19

    .line 25
    return-void

    .line 26
    :cond_19
    if-nez v6, :cond_26

    .line 28
    new-instance p1, Ljava/lang/NullPointerException;

    .line 30
    const-string p2, "Iterator.next() returned a null value"

    .line 32
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 35
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 38
    return-void

    .line 39
    :cond_26
    invoke-interface {v1, v6}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 42
    iget-boolean v6, p0, Lc4/m$a;->b:Z

    .line 44
    if-eqz v6, :cond_2e

    .line 46
    return-void

    .line 47
    :cond_2e
    :try_start_2e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    move-result v6
    :try_end_32
    .catchall {:try_start_2e .. :try_end_32} :catchall_40

    .line 51
    if-nez v6, :cond_3c

    .line 53
    iget-boolean p1, p0, Lc4/m$a;->b:Z

    .line 55
    if-nez p1, :cond_3b

    .line 57
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 60
    :cond_3b
    return-void

    .line 61
    :cond_3c
    const-wide/16 v6, 0x1

    .line 63
    add-long/2addr v4, v6

    .line 64
    goto :goto_7

    .line 65
    :catchall_40
    move-exception p1

    .line 66
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 69
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 72
    return-void

    .line 73
    :catchall_48
    move-exception p1

    .line 74
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 77
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 80
    return-void

    .line 81
    :cond_50
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 84
    move-result-wide p1

    .line 85
    cmp-long v6, v4, p1

    .line 87
    if-nez v6, :cond_7

    .line 89
    neg-long p1, v4

    .line 90
    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 93
    move-result-wide p1

    .line 94
    cmp-long v4, p1, v2

    .line 96
    if-nez v4, :cond_6

    .line 98
    return-void
.end method
