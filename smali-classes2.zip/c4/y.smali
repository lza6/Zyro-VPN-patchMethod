.class public final Lc4/y;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/y$a;
    }
.end annotation


# instance fields
.field public final c:Ljava/util/concurrent/Callable;


# direct methods
.method public constructor <init>(LQ3/f;Ljava/util/concurrent/Callable;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/y;->c:Ljava/util/concurrent/Callable;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lc4/y;->c:Ljava/util/concurrent/Callable;

    .line 3
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    const-string v1, "The collectionSupplier returned a null collection. Null values are generally not allowed in 2.x operators and sources."

    .line 9
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Ljava/util/Collection;
    :try_end_e
    .catchall {:try_start_0 .. :try_end_e} :catchall_19

    .line 15
    iget-object v1, p0, Lc4/a;->b:LQ3/f;

    .line 17
    new-instance v2, Lc4/y$a;

    .line 19
    invoke-direct {v2, p1, v0}, Lc4/y$a;-><init>(Lz5/b;Ljava/util/Collection;)V

    .line 22
    invoke-virtual {v1, v2}, LQ3/f;->H(LQ3/i;)V

    .line 25
    return-void

    .line 26
    :catchall_19
    move-exception v0

    .line 27
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 30
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 33
    return-void
.end method
