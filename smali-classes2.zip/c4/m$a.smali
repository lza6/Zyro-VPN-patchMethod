.class public abstract Lc4/m$a;
.super Lj4/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/util/Iterator;

.field public volatile b:Z

.field public c:Z


# direct methods
.method public constructor <init>(Ljava/util/Iterator;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lj4/b;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 6
    return-void
.end method


# virtual methods
.method public abstract a()V
.end method

.method public abstract b(J)V
.end method

.method public final cancel()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lc4/m$a;->b:Z

    .line 4
    return-void
.end method

.method public final clear()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 4
    return-void
.end method

.method public final f(J)V
    .registers 7

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_20

    .line 7
    invoke-static {p0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 10
    move-result-wide v0

    .line 11
    const-wide/16 v2, 0x0

    .line 13
    cmp-long v0, v0, v2

    .line 15
    if-nez v0, :cond_20

    .line 17
    const-wide v0, 0x7fffffffffffffffL

    .line 22
    cmp-long v0, p1, v0

    .line 24
    if-nez v0, :cond_1d

    .line 26
    invoke-virtual {p0}, Lc4/m$a;->a()V

    .line 29
    goto :goto_20

    .line 30
    :cond_1d
    invoke-virtual {p0, p1, p2}, Lc4/m$a;->b(J)V

    .line 33
    :cond_20
    :goto_20
    return-void
.end method

.method public final g(I)I
    .registers 2

    .line 1
    and-int/lit8 p1, p1, 0x1

    .line 3
    return p1
.end method

.method public final isEmpty()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    if-eqz v0, :cond_d

    .line 5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_b

    .line 11
    goto :goto_d

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    :goto_d
    const/4 v0, 0x1

    .line 15
    :goto_e
    return v0
.end method

.method public final poll()Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_6

    .line 6
    return-object v1

    .line 7
    :cond_6
    iget-boolean v2, p0, Lc4/m$a;->c:Z

    .line 9
    if-nez v2, :cond_e

    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Lc4/m$a;->c:Z

    .line 14
    goto :goto_15

    .line 15
    :cond_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_15

    .line 21
    return-object v1

    .line 22
    :cond_15
    :goto_15
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 24
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    move-result-object v0

    .line 28
    const-string v1, "Iterator.next() returned a null value"

    .line 30
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 33
    move-result-object v0

    .line 34
    return-object v0
.end method
