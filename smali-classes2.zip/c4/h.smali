.class public final Lc4/h;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/h$a;,
        Lc4/h$b;
    }
.end annotation


# instance fields
.field public final c:LW3/g;


# direct methods
.method public constructor <init>(LQ3/f;LW3/g;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/h;->c:LW3/g;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 5

    .line 1
    instance-of v0, p1, LZ3/a;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 7
    new-instance v1, Lc4/h$a;

    .line 9
    check-cast p1, LZ3/a;

    .line 11
    iget-object v2, p0, Lc4/h;->c:LW3/g;

    .line 13
    invoke-direct {v1, p1, v2}, Lc4/h$a;-><init>(LZ3/a;LW3/g;)V

    .line 16
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 19
    goto :goto_1f

    .line 20
    :cond_13
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 22
    new-instance v1, Lc4/h$b;

    .line 24
    iget-object v2, p0, Lc4/h;->c:LW3/g;

    .line 26
    invoke-direct {v1, p1, v2}, Lc4/h$b;-><init>(Lz5/b;LW3/g;)V

    .line 29
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 32
    :goto_1f
    return-void
.end method
