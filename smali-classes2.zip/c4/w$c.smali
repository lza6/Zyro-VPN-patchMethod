.class public final Lc4/w$c;
.super Ljava/util/concurrent/atomic/AtomicInteger;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/w;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# static fields
.field public static final i:[Lc4/w$b;

.field public static final j:[Lc4/w$b;


# instance fields
.field public final a:Ljava/util/concurrent/atomic/AtomicReference;

.field public final b:I

.field public final c:Ljava/util/concurrent/atomic/AtomicReference;

.field public final d:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final e:Ljava/util/concurrent/atomic/AtomicReference;

.field public volatile f:Ljava/lang/Object;

.field public g:I

.field public volatile h:LZ3/j;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v1, v0, [Lc4/w$b;

    .line 4
    sput-object v1, Lc4/w$c;->i:[Lc4/w$b;

    .line 6
    new-array v0, v0, [Lc4/w$b;

    .line 8
    sput-object v0, Lc4/w$c;->j:[Lc4/w$b;

    .line 10
    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/atomic/AtomicReference;I)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 9
    iput-object v0, p0, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 11
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    sget-object v1, Lc4/w$c;->i:[Lc4/w$b;

    .line 15
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 18
    iput-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 20
    iput-object p1, p0, Lc4/w$c;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 22
    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 24
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    .line 27
    iput-object p1, p0, Lc4/w$c;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 29
    iput p2, p0, Lc4/w$c;->b:I

    .line 31
    return-void
.end method


# virtual methods
.method public a(Lc4/w$b;)Z
    .registers 6

    .line 1
    :cond_0
    iget-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lc4/w$b;

    .line 9
    sget-object v1, Lc4/w$c;->j:[Lc4/w$b;

    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_e

    .line 14
    return v2

    .line 15
    :cond_e
    array-length v1, v0

    .line 16
    add-int/lit8 v3, v1, 0x1

    .line 18
    new-array v3, v3, [Lc4/w$b;

    .line 20
    invoke-static {v0, v2, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 23
    aput-object p1, v3, v1

    .line 25
    iget-object v1, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 27
    invoke-static {v1, v0, v3}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 33
    const/4 p1, 0x1

    .line 34
    return p1
.end method

.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget v0, p0, Lc4/w$c;->g:I

    .line 3
    if-nez v0, :cond_17

    .line 5
    iget-object v0, p0, Lc4/w$c;->h:LZ3/j;

    .line 7
    invoke-interface {v0, p1}, LZ3/j;->offer(Ljava/lang/Object;)Z

    .line 10
    move-result p1

    .line 11
    if-nez p1, :cond_17

    .line 13
    new-instance p1, LU3/c;

    .line 15
    const-string v0, "Prefetch queue is full?!"

    .line 17
    invoke-direct {p1, v0}, LU3/c;-><init>(Ljava/lang/String;)V

    .line 20
    invoke-virtual {p0, p1}, Lc4/w$c;->onError(Ljava/lang/Throwable;)V

    .line 23
    return-void

    .line 24
    :cond_17
    invoke-virtual {p0}, Lc4/w$c;->g()V

    .line 27
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->g(Ljava/util/concurrent/atomic/AtomicReference;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_42

    .line 9
    instance-of v0, p1, LZ3/g;

    .line 11
    if-eqz v0, :cond_33

    .line 13
    move-object v0, p1

    .line 14
    check-cast v0, LZ3/g;

    .line 16
    const/4 v1, 0x3

    .line 17
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 20
    move-result v1

    .line 21
    const/4 v2, 0x1

    .line 22
    if-ne v1, v2, :cond_25

    .line 24
    iput v1, p0, Lc4/w$c;->g:I

    .line 26
    iput-object v0, p0, Lc4/w$c;->h:LZ3/j;

    .line 28
    invoke-static {}, Lk4/i;->b()Ljava/lang/Object;

    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lc4/w$c;->f:Ljava/lang/Object;

    .line 34
    invoke-virtual {p0}, Lc4/w$c;->g()V

    .line 37
    return-void

    .line 38
    :cond_25
    const/4 v2, 0x2

    .line 39
    if-ne v1, v2, :cond_33

    .line 41
    iput v1, p0, Lc4/w$c;->g:I

    .line 43
    iput-object v0, p0, Lc4/w$c;->h:LZ3/j;

    .line 45
    iget v0, p0, Lc4/w$c;->b:I

    .line 47
    int-to-long v0, v0

    .line 48
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 51
    return-void

    .line 52
    :cond_33
    new-instance v0, Lg4/a;

    .line 54
    iget v1, p0, Lc4/w$c;->b:I

    .line 56
    invoke-direct {v0, v1}, Lg4/a;-><init>(I)V

    .line 59
    iput-object v0, p0, Lc4/w$c;->h:LZ3/j;

    .line 61
    iget v0, p0, Lc4/w$c;->b:I

    .line 63
    int-to-long v0, v0

    .line 64
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 67
    :cond_42
    return-void
.end method

.method public d()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Lc4/w$c;->j:[Lc4/w$b;

    .line 9
    if-ne v0, v1, :cond_c

    .line 11
    const/4 v0, 0x1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 v0, 0x0

    .line 14
    :goto_d
    return v0
.end method

.method public dispose()V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Lc4/w$c;->j:[Lc4/w$b;

    .line 9
    if-eq v0, v1, :cond_1f

    .line 11
    iget-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object v0

    .line 17
    check-cast v0, [Lc4/w$b;

    .line 19
    if-eq v0, v1, :cond_1f

    .line 21
    iget-object v0, p0, Lc4/w$c;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 23
    const/4 v1, 0x0

    .line 24
    invoke-static {v0, p0, v1}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    iget-object v0, p0, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 29
    invoke-static {v0}, Lj4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    .line 32
    :cond_1f
    return-void
.end method

.method public f(Ljava/lang/Object;Z)Z
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_51

    .line 4
    invoke-static {p1}, Lk4/i;->f(Ljava/lang/Object;)Z

    .line 7
    move-result v1

    .line 8
    const/4 v2, 0x0

    .line 9
    const/4 v3, 0x1

    .line 10
    if-eqz v1, :cond_2a

    .line 12
    if-eqz p2, :cond_51

    .line 14
    iget-object p1, p0, Lc4/w$c;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 16
    invoke-static {p1, p0, v2}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 19
    iget-object p1, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    sget-object p2, Lc4/w$c;->j:[Lc4/w$b;

    .line 23
    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    move-result-object p1

    .line 27
    check-cast p1, [Lc4/w$b;

    .line 29
    array-length p2, p1

    .line 30
    :goto_1d
    if-ge v0, p2, :cond_29

    .line 32
    aget-object v1, p1, v0

    .line 34
    iget-object v1, v1, Lc4/w$b;->a:Lz5/b;

    .line 36
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 39
    add-int/lit8 v0, v0, 0x1

    .line 41
    goto :goto_1d

    .line 42
    :cond_29
    return v3

    .line 43
    :cond_2a
    invoke-static {p1}, Lk4/i;->d(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 46
    move-result-object p1

    .line 47
    iget-object p2, p0, Lc4/w$c;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 49
    invoke-static {p2, p0, v2}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    iget-object p2, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 54
    sget-object v1, Lc4/w$c;->j:[Lc4/w$b;

    .line 56
    invoke-virtual {p2, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    move-result-object p2

    .line 60
    check-cast p2, [Lc4/w$b;

    .line 62
    array-length v1, p2

    .line 63
    if-eqz v1, :cond_4d

    .line 65
    array-length v1, p2

    .line 66
    :goto_41
    if-ge v0, v1, :cond_50

    .line 68
    aget-object v2, p2, v0

    .line 70
    iget-object v2, v2, Lc4/w$b;->a:Lz5/b;

    .line 72
    invoke-interface {v2, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 75
    add-int/lit8 v0, v0, 0x1

    .line 77
    goto :goto_41

    .line 78
    :cond_4d
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 81
    :cond_50
    return v3

    .line 82
    :cond_51
    return v0
.end method

.method public g()V
    .registers 26

    .line 1
    move-object/from16 v1, p0

    .line 3
    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    iget-object v2, v1, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 12
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 15
    move-result-object v0

    .line 16
    check-cast v0, [Lc4/w$b;

    .line 18
    const/4 v3, 0x1

    .line 19
    move-object v4, v0

    .line 20
    move v5, v3

    .line 21
    :cond_14
    :goto_14
    iget-object v0, v1, Lc4/w$c;->f:Ljava/lang/Object;

    .line 23
    iget-object v6, v1, Lc4/w$c;->h:LZ3/j;

    .line 25
    if-eqz v6, :cond_23

    .line 27
    invoke-interface {v6}, LZ3/j;->isEmpty()Z

    .line 30
    move-result v8

    .line 31
    if-eqz v8, :cond_21

    .line 33
    goto :goto_23

    .line 34
    :cond_21
    const/4 v8, 0x0

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    :goto_23
    move v8, v3

    .line 37
    :goto_24
    invoke-virtual {v1, v0, v8}, Lc4/w$c;->f(Ljava/lang/Object;Z)Z

    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2b

    .line 43
    return-void

    .line 44
    :cond_2b
    if-nez v8, :cond_146

    .line 46
    array-length v0, v4

    .line 47
    array-length v9, v4

    .line 48
    const/4 v12, 0x0

    .line 49
    const/4 v13, 0x0

    .line 50
    const-wide v14, 0x7fffffffffffffffL

    .line 55
    :goto_36
    const-wide/high16 v16, -0x8000000000000000L

    .line 57
    if-ge v12, v9, :cond_52

    .line 59
    aget-object v7, v4, v12

    .line 61
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 64
    move-result-wide v18

    .line 65
    cmp-long v16, v18, v16

    .line 67
    if-eqz v16, :cond_4d

    .line 69
    iget-wide v10, v7, Lc4/w$b;->c:J

    .line 71
    sub-long v10, v18, v10

    .line 73
    invoke-static {v14, v15, v10, v11}, Ljava/lang/Math;->min(JJ)J

    .line 76
    move-result-wide v14

    .line 77
    goto :goto_4f

    .line 78
    :cond_4d
    add-int/lit8 v13, v13, 0x1

    .line 80
    :goto_4f
    add-int/lit8 v12, v12, 0x1

    .line 82
    goto :goto_36

    .line 83
    :cond_52
    const-wide/16 v9, 0x1

    .line 85
    if-ne v0, v13, :cond_90

    .line 87
    iget-object v0, v1, Lc4/w$c;->f:Ljava/lang/Object;

    .line 89
    :try_start_58
    invoke-interface {v6}, LZ3/j;->poll()Ljava/lang/Object;

    .line 92
    move-result-object v7
    :try_end_5c
    .catchall {:try_start_58 .. :try_end_5c} :catchall_5d

    .line 93
    goto :goto_74

    .line 94
    :catchall_5d
    move-exception v0

    .line 95
    move-object v6, v0

    .line 96
    invoke-static {v6}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 99
    iget-object v0, v1, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 101
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 104
    move-result-object v0

    .line 105
    check-cast v0, Lz5/c;

    .line 107
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 110
    invoke-static {v6}, Lk4/i;->c(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 113
    move-result-object v0

    .line 114
    iput-object v0, v1, Lc4/w$c;->f:Ljava/lang/Object;

    .line 116
    const/4 v7, 0x0

    .line 117
    :goto_74
    if-nez v7, :cond_78

    .line 119
    move v7, v3

    .line 120
    goto :goto_79

    .line 121
    :cond_78
    const/4 v7, 0x0

    .line 122
    :goto_79
    invoke-virtual {v1, v0, v7}, Lc4/w$c;->f(Ljava/lang/Object;Z)Z

    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_80

    .line 128
    return-void

    .line 129
    :cond_80
    iget v0, v1, Lc4/w$c;->g:I

    .line 131
    if-eq v0, v3, :cond_14

    .line 133
    iget-object v0, v1, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 135
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 138
    move-result-object v0

    .line 139
    check-cast v0, Lz5/c;

    .line 141
    invoke-interface {v0, v9, v10}, Lz5/c;->f(J)V

    .line 144
    goto :goto_14

    .line 145
    :cond_90
    const/4 v11, 0x0

    .line 146
    :goto_91
    int-to-long v12, v11

    .line 147
    cmp-long v0, v12, v14

    .line 149
    if-gez v0, :cond_128

    .line 151
    iget-object v0, v1, Lc4/w$c;->f:Ljava/lang/Object;

    .line 153
    :try_start_98
    invoke-interface {v6}, LZ3/j;->poll()Ljava/lang/Object;

    .line 156
    move-result-object v8
    :try_end_9c
    .catchall {:try_start_98 .. :try_end_9c} :catchall_9d

    .line 157
    goto :goto_b4

    .line 158
    :catchall_9d
    move-exception v0

    .line 159
    move-object v8, v0

    .line 160
    invoke-static {v8}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 163
    iget-object v0, v1, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 165
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Lz5/c;

    .line 171
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 174
    invoke-static {v8}, Lk4/i;->c(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 177
    move-result-object v0

    .line 178
    iput-object v0, v1, Lc4/w$c;->f:Ljava/lang/Object;

    .line 180
    const/4 v8, 0x0

    .line 181
    :goto_b4
    if-nez v8, :cond_b8

    .line 183
    move v7, v3

    .line 184
    goto :goto_b9

    .line 185
    :cond_b8
    const/4 v7, 0x0

    .line 186
    :goto_b9
    invoke-virtual {v1, v0, v7}, Lc4/w$c;->f(Ljava/lang/Object;Z)Z

    .line 189
    move-result v0

    .line 190
    if-eqz v0, :cond_c0

    .line 192
    return-void

    .line 193
    :cond_c0
    if-eqz v7, :cond_c5

    .line 195
    move v8, v7

    .line 196
    goto/16 :goto_128

    .line 198
    :cond_c5
    invoke-static {v8}, Lk4/i;->e(Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    move-result-object v0

    .line 202
    array-length v8, v4

    .line 203
    const/4 v12, 0x0

    .line 204
    const/4 v13, 0x0

    .line 205
    :goto_cc
    if-ge v12, v8, :cond_107

    .line 207
    aget-object v3, v4, v12

    .line 209
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 212
    move-result-wide v22

    .line 213
    cmp-long v24, v22, v16

    .line 215
    if-eqz v24, :cond_f5

    .line 217
    const-wide v20, 0x7fffffffffffffffL

    .line 222
    cmp-long v22, v22, v20

    .line 224
    if-eqz v22, :cond_eb

    .line 226
    move-object/from16 v22, v6

    .line 228
    move/from16 v23, v7

    .line 230
    iget-wide v6, v3, Lc4/w$b;->c:J

    .line 232
    add-long/2addr v6, v9

    .line 233
    iput-wide v6, v3, Lc4/w$b;->c:J

    .line 235
    goto :goto_ef

    .line 236
    :cond_eb
    move-object/from16 v22, v6

    .line 238
    move/from16 v23, v7

    .line 240
    :goto_ef
    iget-object v3, v3, Lc4/w$b;->a:Lz5/b;

    .line 242
    invoke-interface {v3, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 245
    goto :goto_ff

    .line 246
    :cond_f5
    move-object/from16 v22, v6

    .line 248
    move/from16 v23, v7

    .line 250
    const-wide v20, 0x7fffffffffffffffL

    .line 255
    const/4 v13, 0x1

    .line 256
    :goto_ff
    add-int/lit8 v12, v12, 0x1

    .line 258
    move-object/from16 v6, v22

    .line 260
    move/from16 v7, v23

    .line 262
    const/4 v3, 0x1

    .line 263
    goto :goto_cc

    .line 264
    :cond_107
    move-object/from16 v22, v6

    .line 266
    move/from16 v23, v7

    .line 268
    const-wide v20, 0x7fffffffffffffffL

    .line 273
    add-int/lit8 v11, v11, 0x1

    .line 275
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 278
    move-result-object v0

    .line 279
    check-cast v0, [Lc4/w$b;

    .line 281
    if-nez v13, :cond_124

    .line 283
    if-eq v0, v4, :cond_11d

    .line 285
    goto :goto_124

    .line 286
    :cond_11d
    move-object/from16 v6, v22

    .line 288
    move/from16 v8, v23

    .line 290
    const/4 v3, 0x1

    .line 291
    goto/16 :goto_91

    .line 293
    :cond_124
    :goto_124
    move-object v4, v0

    .line 294
    const/4 v3, 0x1

    .line 295
    goto/16 :goto_14

    .line 297
    :cond_128
    :goto_128
    if-lez v11, :cond_13b

    .line 299
    iget v0, v1, Lc4/w$c;->g:I

    .line 301
    const/4 v3, 0x1

    .line 302
    if-eq v0, v3, :cond_13c

    .line 304
    iget-object v0, v1, Lc4/w$c;->e:Ljava/util/concurrent/atomic/AtomicReference;

    .line 306
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 309
    move-result-object v0

    .line 310
    check-cast v0, Lz5/c;

    .line 312
    invoke-interface {v0, v12, v13}, Lz5/c;->f(J)V

    .line 315
    goto :goto_13c

    .line 316
    :cond_13b
    const/4 v3, 0x1

    .line 317
    :cond_13c
    :goto_13c
    const-wide/16 v6, 0x0

    .line 319
    cmp-long v0, v14, v6

    .line 321
    if-eqz v0, :cond_146

    .line 323
    if-nez v8, :cond_146

    .line 325
    goto/16 :goto_14

    .line 327
    :cond_146
    neg-int v0, v5

    .line 328
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 331
    move-result v5

    .line 332
    if-nez v5, :cond_14e

    .line 334
    return-void

    .line 335
    :cond_14e
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 338
    move-result-object v0

    .line 339
    move-object v4, v0

    .line 340
    check-cast v4, [Lc4/w$b;

    .line 342
    goto/16 :goto_14
.end method

.method public h(Lc4/w$b;)V
    .registers 8

    .line 1
    :cond_0
    iget-object v0, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lc4/w$b;

    .line 9
    array-length v1, v0

    .line 10
    if-nez v1, :cond_c

    .line 12
    goto :goto_3d

    .line 13
    :cond_c
    const/4 v2, 0x0

    .line 14
    move v3, v2

    .line 15
    :goto_e
    if-ge v3, v1, :cond_1c

    .line 17
    aget-object v4, v0, v3

    .line 19
    invoke-virtual {v4, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 22
    move-result v4

    .line 23
    if-eqz v4, :cond_19

    .line 25
    goto :goto_1d

    .line 26
    :cond_19
    add-int/lit8 v3, v3, 0x1

    .line 28
    goto :goto_e

    .line 29
    :cond_1c
    const/4 v3, -0x1

    .line 30
    :goto_1d
    if-gez v3, :cond_20

    .line 32
    return-void

    .line 33
    :cond_20
    const/4 v4, 0x1

    .line 34
    if-ne v1, v4, :cond_26

    .line 36
    sget-object v1, Lc4/w$c;->i:[Lc4/w$b;

    .line 38
    goto :goto_35

    .line 39
    :cond_26
    add-int/lit8 v5, v1, -0x1

    .line 41
    new-array v5, v5, [Lc4/w$b;

    .line 43
    invoke-static {v0, v2, v5, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 46
    add-int/lit8 v2, v3, 0x1

    .line 48
    sub-int/2addr v1, v3

    .line 49
    sub-int/2addr v1, v4

    .line 50
    invoke-static {v0, v2, v5, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 53
    move-object v1, v5

    .line 54
    :goto_35
    iget-object v2, p0, Lc4/w$c;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 56
    invoke-static {v2, v0, v1}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_0

    .line 62
    :goto_3d
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/w$c;->f:Ljava/lang/Object;

    .line 3
    if-nez v0, :cond_d

    .line 5
    invoke-static {}, Lk4/i;->b()Ljava/lang/Object;

    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lc4/w$c;->f:Ljava/lang/Object;

    .line 11
    invoke-virtual {p0}, Lc4/w$c;->g()V

    .line 14
    :cond_d
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/w$c;->f:Ljava/lang/Object;

    .line 3
    if-nez v0, :cond_e

    .line 5
    invoke-static {p1}, Lk4/i;->c(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, Lc4/w$c;->f:Ljava/lang/Object;

    .line 11
    invoke-virtual {p0}, Lc4/w$c;->g()V

    .line 14
    goto :goto_11

    .line 15
    :cond_e
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 18
    :goto_11
    return-void
.end method
