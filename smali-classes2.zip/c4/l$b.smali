.class public final Lc4/l$b;
.super Lc4/l$c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final d:Lz5/b;


# direct methods
.method public constructor <init>(Lz5/b;[Ljava/lang/Object;)V
    .registers 3

    .line 1
    invoke-direct {p0, p2}, Lc4/l$c;-><init>([Ljava/lang/Object;)V

    .line 4
    iput-object p1, p0, Lc4/l$b;->d:Lz5/b;

    .line 6
    return-void
.end method


# virtual methods
.method public a()V
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 3
    array-length v1, v0

    .line 4
    iget-object v2, p0, Lc4/l$b;->d:Lz5/b;

    .line 6
    iget v3, p0, Lc4/l$c;->b:I

    .line 8
    :goto_7
    if-eq v3, v1, :cond_23

    .line 10
    iget-boolean v4, p0, Lc4/l$c;->c:Z

    .line 12
    if-eqz v4, :cond_e

    .line 14
    return-void

    .line 15
    :cond_e
    aget-object v4, v0, v3

    .line 17
    if-nez v4, :cond_1d

    .line 19
    new-instance v0, Ljava/lang/NullPointerException;

    .line 21
    const-string v1, "array element is null"

    .line 23
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 26
    invoke-interface {v2, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 29
    return-void

    .line 30
    :cond_1d
    invoke-interface {v2, v4}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 33
    add-int/lit8 v3, v3, 0x1

    .line 35
    goto :goto_7

    .line 36
    :cond_23
    iget-boolean v0, p0, Lc4/l$c;->c:Z

    .line 38
    if-eqz v0, :cond_28

    .line 40
    return-void

    .line 41
    :cond_28
    invoke-interface {v2}, Lz5/b;->onComplete()V

    .line 44
    return-void
.end method

.method public b(J)V
    .registers 13

    .line 1
    iget-object v0, p0, Lc4/l$c;->a:[Ljava/lang/Object;

    .line 3
    array-length v1, v0

    .line 4
    iget v2, p0, Lc4/l$c;->b:I

    .line 6
    iget-object v3, p0, Lc4/l$b;->d:Lz5/b;

    .line 8
    const-wide/16 v4, 0x0

    .line 10
    :cond_9
    move-wide v6, v4

    .line 11
    :cond_a
    :goto_a
    cmp-long v8, v6, p1

    .line 13
    if-eqz v8, :cond_2d

    .line 15
    if-eq v2, v1, :cond_2d

    .line 17
    iget-boolean v8, p0, Lc4/l$c;->c:Z

    .line 19
    if-eqz v8, :cond_15

    .line 21
    return-void

    .line 22
    :cond_15
    aget-object v8, v0, v2

    .line 24
    if-nez v8, :cond_24

    .line 26
    new-instance p1, Ljava/lang/NullPointerException;

    .line 28
    const-string p2, "array element is null"

    .line 30
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 33
    invoke-interface {v3, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 36
    return-void

    .line 37
    :cond_24
    invoke-interface {v3, v8}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 40
    const-wide/16 v8, 0x1

    .line 42
    add-long/2addr v6, v8

    .line 43
    add-int/lit8 v2, v2, 0x1

    .line 45
    goto :goto_a

    .line 46
    :cond_2d
    if-ne v2, v1, :cond_37

    .line 48
    iget-boolean p1, p0, Lc4/l$c;->c:Z

    .line 50
    if-nez p1, :cond_36

    .line 52
    invoke-interface {v3}, Lz5/b;->onComplete()V

    .line 55
    :cond_36
    return-void

    .line 56
    :cond_37
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 59
    move-result-wide p1

    .line 60
    cmp-long v8, v6, p1

    .line 62
    if-nez v8, :cond_a

    .line 64
    iput v2, p0, Lc4/l$c;->b:I

    .line 66
    neg-long p1, v6

    .line 67
    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 70
    move-result-wide p1

    .line 71
    cmp-long v6, p1, v4

    .line 73
    if-nez v6, :cond_9

    .line 75
    return-void
.end method
