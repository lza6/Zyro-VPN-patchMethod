.class public final Lc4/b$g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public final b:Ljava/lang/Object;

.field public c:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lz5/b;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/b$g;->b:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, Lc4/b$g;->a:Lz5/b;

    .line 8
    return-void
.end method


# virtual methods
.method public cancel()V
    .registers 1

    .line 1
    return-void
.end method

.method public f(J)V
    .registers 5

    .line 1
    const-wide/16 v0, 0x0

    .line 3
    cmp-long p1, p1, v0

    .line 5
    if-lez p1, :cond_17

    .line 7
    iget-boolean p1, p0, Lc4/b$g;->c:Z

    .line 9
    if-nez p1, :cond_17

    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, p0, Lc4/b$g;->c:Z

    .line 14
    iget-object p1, p0, Lc4/b$g;->a:Lz5/b;

    .line 16
    iget-object p2, p0, Lc4/b$g;->b:Ljava/lang/Object;

    .line 18
    invoke-interface {p1, p2}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 21
    invoke-interface {p1}, Lz5/b;->onComplete()V

    .line 24
    :cond_17
    return-void
.end method
