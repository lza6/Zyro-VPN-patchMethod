.class public final Lc4/j$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/j$a$a;
    }
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public final b:Z

.field public final c:I

.field public final d:Ljava/util/concurrent/atomic/AtomicLong;

.field public final e:LT3/a;

.field public final f:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final g:Lk4/c;

.field public final h:LW3/e;

.field public final i:Ljava/util/concurrent/atomic/AtomicReference;

.field public j:Lz5/c;

.field public volatile k:Z


# direct methods
.method public constructor <init>(Lz5/b;LW3/e;ZI)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/j$a;->a:Lz5/b;

    .line 6
    iput-object p2, p0, Lc4/j$a;->h:LW3/e;

    .line 8
    iput-boolean p3, p0, Lc4/j$a;->b:Z

    .line 10
    iput p4, p0, Lc4/j$a;->c:I

    .line 12
    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 14
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 17
    iput-object p1, p0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 19
    new-instance p1, LT3/a;

    .line 21
    invoke-direct {p1}, LT3/a;-><init>()V

    .line 24
    iput-object p1, p0, Lc4/j$a;->e:LT3/a;

    .line 26
    new-instance p1, Lk4/c;

    .line 28
    invoke-direct {p1}, Lk4/c;-><init>()V

    .line 31
    iput-object p1, p0, Lc4/j$a;->g:Lk4/c;

    .line 33
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 35
    const/4 p2, 0x1

    .line 36
    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 39
    iput-object p1, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 41
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 43
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 46
    iput-object p1, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 48
    return-void
.end method


# virtual methods
.method public a()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lg4/b;

    .line 9
    if-eqz v0, :cond_d

    .line 11
    invoke-virtual {v0}, Lg4/b;->clear()V

    .line 14
    :cond_d
    return-void
.end method

.method public b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lc4/j$a;->h:LW3/e;

    .line 3
    invoke-interface {v0, p1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    move-result-object p1

    .line 7
    const-string v0, "The mapper returned a null MaybeSource"

    .line 9
    invoke-static {p1, v0}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    move-result-object p1

    .line 13
    check-cast p1, LQ3/n;
    :try_end_e
    .catchall {:try_start_0 .. :try_end_e} :catchall_28

    .line 15
    iget-object v0, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 17
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 20
    new-instance v0, Lc4/j$a$a;

    .line 22
    invoke-direct {v0, p0}, Lc4/j$a$a;-><init>(Lc4/j$a;)V

    .line 25
    iget-boolean v1, p0, Lc4/j$a;->k:Z

    .line 27
    if-nez v1, :cond_27

    .line 29
    iget-object v1, p0, Lc4/j$a;->e:LT3/a;

    .line 31
    invoke-virtual {v1, v0}, LT3/a;->b(LT3/b;)Z

    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_27

    .line 37
    invoke-interface {p1, v0}, LQ3/n;->a(LQ3/l;)V

    .line 40
    :cond_27
    return-void

    .line 41
    :catchall_28
    move-exception p1

    .line 42
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 45
    iget-object v0, p0, Lc4/j$a;->j:Lz5/c;

    .line 47
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 50
    invoke-virtual {p0, p1}, Lc4/j$a;->onError(Ljava/lang/Throwable;)V

    .line 53
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/j$a;->j:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_23

    .line 9
    iput-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 11
    iget-object v0, p0, Lc4/j$a;->a:Lz5/b;

    .line 13
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 16
    iget v0, p0, Lc4/j$a;->c:I

    .line 18
    const v1, 0x7fffffff

    .line 21
    if-ne v0, v1, :cond_1f

    .line 23
    const-wide v0, 0x7fffffffffffffffL

    .line 28
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 31
    goto :goto_23

    .line 32
    :cond_1f
    int-to-long v0, v0

    .line 33
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 36
    :cond_23
    :goto_23
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lc4/j$a;->k:Z

    .line 4
    iget-object v0, p0, Lc4/j$a;->j:Lz5/c;

    .line 6
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 9
    iget-object v0, p0, Lc4/j$a;->e:LT3/a;

    .line 11
    invoke-virtual {v0}, LT3/a;->dispose()V

    .line 14
    return-void
.end method

.method public d()V
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_9

    .line 7
    invoke-virtual {p0}, Lc4/j$a;->g()V

    .line 10
    :cond_9
    return-void
.end method

.method public f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_e

    .line 7
    iget-object v0, p0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 9
    invoke-static {v0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 12
    invoke-virtual {p0}, Lc4/j$a;->d()V

    .line 15
    :cond_e
    return-void
.end method

.method public g()V
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lc4/j$a;->a:Lz5/b;

    .line 5
    iget-object v2, v0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 7
    iget-object v3, v0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 9
    const/4 v4, 0x1

    .line 10
    move v5, v4

    .line 11
    :cond_a
    iget-object v6, v0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 13
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 16
    move-result-wide v6

    .line 17
    const-wide/16 v8, 0x0

    .line 19
    move-wide v10, v8

    .line 20
    :goto_13
    cmp-long v12, v10, v6

    .line 22
    const/4 v13, 0x0

    .line 23
    if-eqz v12, :cond_77

    .line 25
    iget-boolean v14, v0, Lc4/j$a;->k:Z

    .line 27
    if-eqz v14, :cond_20

    .line 29
    invoke-virtual/range {p0 .. p0}, Lc4/j$a;->a()V

    .line 32
    return-void

    .line 33
    :cond_20
    iget-boolean v14, v0, Lc4/j$a;->b:Z

    .line 35
    if-nez v14, :cond_3b

    .line 37
    iget-object v14, v0, Lc4/j$a;->g:Lk4/c;

    .line 39
    invoke-virtual {v14}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 42
    move-result-object v14

    .line 43
    check-cast v14, Ljava/lang/Throwable;

    .line 45
    if-eqz v14, :cond_3b

    .line 47
    iget-object v2, v0, Lc4/j$a;->g:Lk4/c;

    .line 49
    invoke-virtual {v2}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 52
    move-result-object v2

    .line 53
    invoke-virtual/range {p0 .. p0}, Lc4/j$a;->a()V

    .line 56
    invoke-interface {v1, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 59
    return-void

    .line 60
    :cond_3b
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 63
    move-result v14

    .line 64
    if-nez v14, :cond_43

    .line 66
    move v14, v4

    .line 67
    goto :goto_44

    .line 68
    :cond_43
    move v14, v13

    .line 69
    :goto_44
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 72
    move-result-object v15

    .line 73
    check-cast v15, Lg4/b;

    .line 75
    if-eqz v15, :cond_51

    .line 77
    invoke-virtual {v15}, Lg4/b;->poll()Ljava/lang/Object;

    .line 80
    move-result-object v15

    .line 81
    goto :goto_52

    .line 82
    :cond_51
    const/4 v15, 0x0

    .line 83
    :goto_52
    if-nez v15, :cond_57

    .line 85
    move/from16 v16, v4

    .line 87
    goto :goto_59

    .line 88
    :cond_57
    move/from16 v16, v13

    .line 90
    :goto_59
    if-eqz v14, :cond_6d

    .line 92
    if-eqz v16, :cond_6d

    .line 94
    iget-object v2, v0, Lc4/j$a;->g:Lk4/c;

    .line 96
    invoke-virtual {v2}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 99
    move-result-object v2

    .line 100
    if-eqz v2, :cond_69

    .line 102
    invoke-interface {v1, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 109
    :goto_6c
    return-void

    .line 110
    :cond_6d
    if-eqz v16, :cond_70

    .line 112
    goto :goto_77

    .line 113
    :cond_70
    invoke-interface {v1, v15}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 116
    const-wide/16 v12, 0x1

    .line 118
    add-long/2addr v10, v12

    .line 119
    goto :goto_13

    .line 120
    :cond_77
    :goto_77
    if-nez v12, :cond_c8

    .line 122
    iget-boolean v6, v0, Lc4/j$a;->k:Z

    .line 124
    if-eqz v6, :cond_81

    .line 126
    invoke-virtual/range {p0 .. p0}, Lc4/j$a;->a()V

    .line 129
    return-void

    .line 130
    :cond_81
    iget-boolean v6, v0, Lc4/j$a;->b:Z

    .line 132
    if-nez v6, :cond_9c

    .line 134
    iget-object v6, v0, Lc4/j$a;->g:Lk4/c;

    .line 136
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 139
    move-result-object v6

    .line 140
    check-cast v6, Ljava/lang/Throwable;

    .line 142
    if-eqz v6, :cond_9c

    .line 144
    iget-object v2, v0, Lc4/j$a;->g:Lk4/c;

    .line 146
    invoke-virtual {v2}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 149
    move-result-object v2

    .line 150
    invoke-virtual/range {p0 .. p0}, Lc4/j$a;->a()V

    .line 153
    invoke-interface {v1, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 156
    return-void

    .line 157
    :cond_9c
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 160
    move-result v6

    .line 161
    if-nez v6, :cond_a4

    .line 163
    move v6, v4

    .line 164
    goto :goto_a5

    .line 165
    :cond_a4
    move v6, v13

    .line 166
    :goto_a5
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 169
    move-result-object v7

    .line 170
    check-cast v7, Lg4/b;

    .line 172
    if-eqz v7, :cond_b3

    .line 174
    invoke-virtual {v7}, Lg4/b;->isEmpty()Z

    .line 177
    move-result v7

    .line 178
    if-eqz v7, :cond_b4

    .line 180
    :cond_b3
    move v13, v4

    .line 181
    :cond_b4
    if-eqz v6, :cond_c8

    .line 183
    if-eqz v13, :cond_c8

    .line 185
    iget-object v2, v0, Lc4/j$a;->g:Lk4/c;

    .line 187
    invoke-virtual {v2}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 190
    move-result-object v2

    .line 191
    if-eqz v2, :cond_c4

    .line 193
    invoke-interface {v1, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 196
    goto :goto_c7

    .line 197
    :cond_c4
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 200
    :goto_c7
    return-void

    .line 201
    :cond_c8
    cmp-long v6, v10, v8

    .line 203
    if-eqz v6, :cond_dd

    .line 205
    iget-object v6, v0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 207
    invoke-static {v6, v10, v11}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 210
    iget v6, v0, Lc4/j$a;->c:I

    .line 212
    const v7, 0x7fffffff

    .line 215
    if-eq v6, v7, :cond_dd

    .line 217
    iget-object v6, v0, Lc4/j$a;->j:Lz5/c;

    .line 219
    invoke-interface {v6, v10, v11}, Lz5/c;->f(J)V

    .line 222
    :cond_dd
    neg-int v5, v5

    .line 223
    invoke-virtual {v0, v5}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 226
    move-result v5

    .line 227
    if-nez v5, :cond_a

    .line 229
    return-void
.end method

.method public h()Lg4/b;
    .registers 4

    .line 1
    :cond_0
    iget-object v0, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lg4/b;

    .line 9
    if-eqz v0, :cond_b

    .line 11
    return-object v0

    .line 12
    :cond_b
    new-instance v0, Lg4/b;

    .line 14
    invoke-static {}, LQ3/f;->b()I

    .line 17
    move-result v1

    .line 18
    invoke-direct {v0, v1}, Lg4/b;-><init>(I)V

    .line 21
    iget-object v1, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-static {v1, v2, v0}, Landroidx/lifecycle/n;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_0

    .line 30
    return-object v0
.end method

.method public i(Lc4/j$a$a;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lc4/j$a;->e:LT3/a;

    .line 3
    invoke-virtual {v0, p1}, LT3/a;->c(LT3/b;)Z

    .line 6
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 9
    move-result p1

    .line 10
    const-wide/16 v0, 0x1

    .line 12
    const v2, 0x7fffffff

    .line 15
    if-nez p1, :cond_5b

    .line 17
    const/4 p1, 0x0

    .line 18
    const/4 v3, 0x1

    .line 19
    invoke-virtual {p0, p1, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 22
    move-result v4

    .line 23
    if-eqz v4, :cond_5b

    .line 25
    iget-object v4, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 27
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 30
    move-result v4

    .line 31
    if-nez v4, :cond_21

    .line 33
    move p1, v3

    .line 34
    :cond_21
    iget-object v3, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 36
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 39
    move-result-object v3

    .line 40
    check-cast v3, Lg4/b;

    .line 42
    if-eqz p1, :cond_47

    .line 44
    if-eqz v3, :cond_33

    .line 46
    invoke-virtual {v3}, Lg4/b;->isEmpty()Z

    .line 49
    move-result p1

    .line 50
    if-eqz p1, :cond_47

    .line 52
    :cond_33
    iget-object p1, p0, Lc4/j$a;->g:Lk4/c;

    .line 54
    invoke-virtual {p1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 57
    move-result-object p1

    .line 58
    if-eqz p1, :cond_41

    .line 60
    iget-object v0, p0, Lc4/j$a;->a:Lz5/b;

    .line 62
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 65
    goto :goto_46

    .line 66
    :cond_41
    iget-object p1, p0, Lc4/j$a;->a:Lz5/b;

    .line 68
    invoke-interface {p1}, Lz5/b;->onComplete()V

    .line 71
    :goto_46
    return-void

    .line 72
    :cond_47
    iget p1, p0, Lc4/j$a;->c:I

    .line 74
    if-eq p1, v2, :cond_50

    .line 76
    iget-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 78
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 81
    :cond_50
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 84
    move-result p1

    .line 85
    if-nez p1, :cond_57

    .line 87
    return-void

    .line 88
    :cond_57
    invoke-virtual {p0}, Lc4/j$a;->g()V

    .line 91
    goto :goto_6c

    .line 92
    :cond_5b
    iget-object p1, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 94
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 97
    iget p1, p0, Lc4/j$a;->c:I

    .line 99
    if-eq p1, v2, :cond_69

    .line 101
    iget-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 103
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 106
    :cond_69
    invoke-virtual {p0}, Lc4/j$a;->d()V

    .line 109
    :goto_6c
    return-void
.end method

.method public j(Lc4/j$a$a;Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/j$a;->e:LT3/a;

    .line 3
    invoke-virtual {v0, p1}, LT3/a;->c(LT3/b;)Z

    .line 6
    iget-object p1, p0, Lc4/j$a;->g:Lk4/c;

    .line 8
    invoke-virtual {p1, p2}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 11
    move-result p1

    .line 12
    if-eqz p1, :cond_33

    .line 14
    iget-boolean p1, p0, Lc4/j$a;->b:Z

    .line 16
    if-nez p1, :cond_1c

    .line 18
    iget-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 20
    invoke-interface {p1}, Lz5/c;->cancel()V

    .line 23
    iget-object p1, p0, Lc4/j$a;->e:LT3/a;

    .line 25
    invoke-virtual {p1}, LT3/a;->dispose()V

    .line 28
    goto :goto_2a

    .line 29
    :cond_1c
    iget p1, p0, Lc4/j$a;->c:I

    .line 31
    const p2, 0x7fffffff

    .line 34
    if-eq p1, p2, :cond_2a

    .line 36
    iget-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 38
    const-wide/16 v0, 0x1

    .line 40
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 43
    :cond_2a
    :goto_2a
    iget-object p1, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 45
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 48
    invoke-virtual {p0}, Lc4/j$a;->d()V

    .line 51
    goto :goto_36

    .line 52
    :cond_33
    invoke-static {p2}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 55
    :goto_36
    return-void
.end method

.method public k(Lc4/j$a$a;Ljava/lang/Object;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lc4/j$a;->e:LT3/a;

    .line 3
    invoke-virtual {v0, p1}, LT3/a;->c(LT3/b;)Z

    .line 6
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 9
    move-result p1

    .line 10
    if-nez p1, :cond_7a

    .line 12
    const/4 p1, 0x0

    .line 13
    const/4 v0, 0x1

    .line 14
    invoke-virtual {p0, p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_7a

    .line 20
    iget-object v1, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 22
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 25
    move-result v1

    .line 26
    if-nez v1, :cond_1c

    .line 28
    move p1, v0

    .line 29
    :cond_1c
    iget-object v0, p0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 31
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 34
    move-result-wide v0

    .line 35
    const-wide/16 v2, 0x0

    .line 37
    cmp-long v0, v0, v2

    .line 39
    if-eqz v0, :cond_67

    .line 41
    iget-object v0, p0, Lc4/j$a;->a:Lz5/b;

    .line 43
    invoke-interface {v0, p2}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 46
    iget-object p2, p0, Lc4/j$a;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 48
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 51
    move-result-object p2

    .line 52
    check-cast p2, Lg4/b;

    .line 54
    if-eqz p1, :cond_53

    .line 56
    if-eqz p2, :cond_3f

    .line 58
    invoke-virtual {p2}, Lg4/b;->isEmpty()Z

    .line 61
    move-result p1

    .line 62
    if-eqz p1, :cond_53

    .line 64
    :cond_3f
    iget-object p1, p0, Lc4/j$a;->g:Lk4/c;

    .line 66
    invoke-virtual {p1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 69
    move-result-object p1

    .line 70
    if-eqz p1, :cond_4d

    .line 72
    iget-object p2, p0, Lc4/j$a;->a:Lz5/b;

    .line 74
    invoke-interface {p2, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 77
    goto :goto_52

    .line 78
    :cond_4d
    iget-object p1, p0, Lc4/j$a;->a:Lz5/b;

    .line 80
    invoke-interface {p1}, Lz5/b;->onComplete()V

    .line 83
    :goto_52
    return-void

    .line 84
    :cond_53
    iget-object p1, p0, Lc4/j$a;->d:Ljava/util/concurrent/atomic/AtomicLong;

    .line 86
    const-wide/16 v0, 0x1

    .line 88
    invoke-static {p1, v0, v1}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 91
    iget p1, p0, Lc4/j$a;->c:I

    .line 93
    const p2, 0x7fffffff

    .line 96
    if-eq p1, p2, :cond_70

    .line 98
    iget-object p1, p0, Lc4/j$a;->j:Lz5/c;

    .line 100
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 103
    goto :goto_70

    .line 104
    :cond_67
    invoke-virtual {p0}, Lc4/j$a;->h()Lg4/b;

    .line 107
    move-result-object p1

    .line 108
    monitor-enter p1

    .line 109
    :try_start_6c
    invoke-virtual {p1, p2}, Lg4/b;->offer(Ljava/lang/Object;)Z

    .line 112
    monitor-exit p1
    :try_end_70
    .catchall {:try_start_6c .. :try_end_70} :catchall_77

    .line 113
    :cond_70
    :goto_70
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 116
    move-result p1

    .line 117
    if-nez p1, :cond_8f

    .line 119
    return-void

    .line 120
    :catchall_77
    move-exception p2

    .line 121
    :try_start_78
    monitor-exit p1
    :try_end_79
    .catchall {:try_start_78 .. :try_end_79} :catchall_77

    .line 122
    throw p2

    .line 123
    :cond_7a
    invoke-virtual {p0}, Lc4/j$a;->h()Lg4/b;

    .line 126
    move-result-object p1

    .line 127
    monitor-enter p1

    .line 128
    :try_start_7f
    invoke-virtual {p1, p2}, Lg4/b;->offer(Ljava/lang/Object;)Z

    .line 131
    monitor-exit p1
    :try_end_83
    .catchall {:try_start_7f .. :try_end_83} :catchall_93

    .line 132
    iget-object p1, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 134
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 137
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 140
    move-result p1

    .line 141
    if-eqz p1, :cond_8f

    .line 143
    return-void

    .line 144
    :cond_8f
    invoke-virtual {p0}, Lc4/j$a;->g()V

    .line 147
    return-void

    .line 148
    :catchall_93
    move-exception p2

    .line 149
    :try_start_94
    monitor-exit p1
    :try_end_95
    .catchall {:try_start_94 .. :try_end_95} :catchall_93

    .line 150
    throw p2
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 6
    invoke-virtual {p0}, Lc4/j$a;->d()V

    .line 9
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/j$a;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 6
    iget-object v0, p0, Lc4/j$a;->g:Lk4/c;

    .line 8
    invoke-virtual {v0, p1}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1a

    .line 14
    iget-boolean p1, p0, Lc4/j$a;->b:Z

    .line 16
    if-nez p1, :cond_16

    .line 18
    iget-object p1, p0, Lc4/j$a;->e:LT3/a;

    .line 20
    invoke-virtual {p1}, LT3/a;->dispose()V

    .line 23
    :cond_16
    invoke-virtual {p0}, Lc4/j$a;->d()V

    .line 26
    goto :goto_1d

    .line 27
    :cond_1a
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 30
    :goto_1d
    return-void
.end method
