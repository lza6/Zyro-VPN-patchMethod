.class public final Lc4/c$g;
.super Lc4/c$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "g"
.end annotation


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/c$b;-><init>(Lz5/b;)V

    .line 4
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    if-eqz p1, :cond_23

    .line 10
    iget-object v0, p0, Lc4/c$b;->a:Lz5/b;

    .line 12
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 15
    :cond_e
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 18
    move-result-wide v0

    .line 19
    const-wide/16 v2, 0x0

    .line 21
    cmp-long p1, v0, v2

    .line 23
    if-eqz p1, :cond_22

    .line 25
    const-wide/16 v2, 0x1

    .line 27
    sub-long v2, v0, v2

    .line 29
    invoke-virtual {p0, v0, v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_e

    .line 35
    :cond_22
    return-void

    .line 36
    :cond_23
    new-instance p1, Ljava/lang/NullPointerException;

    .line 38
    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 40
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 43
    invoke-virtual {p0, p1}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 46
    return-void
.end method
