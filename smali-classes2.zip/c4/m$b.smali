.class public final Lc4/m$b;
.super Lc4/m$a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final d:LZ3/a;


# direct methods
.method public constructor <init>(LZ3/a;Ljava/util/Iterator;)V
    .registers 3

    .line 1
    invoke-direct {p0, p2}, Lc4/m$a;-><init>(Ljava/util/Iterator;)V

    .line 4
    iput-object p1, p0, Lc4/m$b;->d:LZ3/a;

    .line 6
    return-void
.end method


# virtual methods
.method public a()V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    iget-object v1, p0, Lc4/m$b;->d:LZ3/a;

    .line 5
    :cond_4
    iget-boolean v2, p0, Lc4/m$a;->b:Z

    .line 7
    if-eqz v2, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    :try_start_9
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 13
    move-result-object v2
    :try_end_d
    .catchall {:try_start_9 .. :try_end_d} :catchall_3d

    .line 14
    iget-boolean v3, p0, Lc4/m$a;->b:Z

    .line 16
    if-eqz v3, :cond_12

    .line 18
    return-void

    .line 19
    :cond_12
    if-nez v2, :cond_1f

    .line 21
    new-instance v0, Ljava/lang/NullPointerException;

    .line 23
    const-string v2, "Iterator.next() returned a null value"

    .line 25
    invoke-direct {v0, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 28
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 31
    return-void

    .line 32
    :cond_1f
    invoke-interface {v1, v2}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 35
    iget-boolean v2, p0, Lc4/m$a;->b:Z

    .line 37
    if-eqz v2, :cond_27

    .line 39
    return-void

    .line 40
    :cond_27
    :try_start_27
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    move-result v2
    :try_end_2b
    .catchall {:try_start_27 .. :try_end_2b} :catchall_35

    .line 44
    if-nez v2, :cond_4

    .line 46
    iget-boolean v0, p0, Lc4/m$a;->b:Z

    .line 48
    if-nez v0, :cond_34

    .line 50
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 53
    :cond_34
    return-void

    .line 54
    :catchall_35
    move-exception v0

    .line 55
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 58
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 61
    return-void

    .line 62
    :catchall_3d
    move-exception v0

    .line 63
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 66
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 69
    return-void
.end method

.method public b(J)V
    .registers 11

    .line 1
    iget-object v0, p0, Lc4/m$a;->a:Ljava/util/Iterator;

    .line 3
    iget-object v1, p0, Lc4/m$b;->d:LZ3/a;

    .line 5
    const-wide/16 v2, 0x0

    .line 7
    :cond_6
    move-wide v4, v2

    .line 8
    :cond_7
    :goto_7
    cmp-long v6, v4, p1

    .line 10
    if-eqz v6, :cond_53

    .line 12
    iget-boolean v6, p0, Lc4/m$a;->b:Z

    .line 14
    if-eqz v6, :cond_10

    .line 16
    return-void

    .line 17
    :cond_10
    :try_start_10
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    move-result-object v6
    :try_end_14
    .catchall {:try_start_10 .. :try_end_14} :catchall_4b

    .line 21
    iget-boolean v7, p0, Lc4/m$a;->b:Z

    .line 23
    if-eqz v7, :cond_19

    .line 25
    return-void

    .line 26
    :cond_19
    if-nez v6, :cond_26

    .line 28
    new-instance p1, Ljava/lang/NullPointerException;

    .line 30
    const-string p2, "Iterator.next() returned a null value"

    .line 32
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 35
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 38
    return-void

    .line 39
    :cond_26
    invoke-interface {v1, v6}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 42
    move-result v6

    .line 43
    iget-boolean v7, p0, Lc4/m$a;->b:Z

    .line 45
    if-eqz v7, :cond_2f

    .line 47
    return-void

    .line 48
    :cond_2f
    :try_start_2f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    move-result v7
    :try_end_33
    .catchall {:try_start_2f .. :try_end_33} :catchall_43

    .line 52
    if-nez v7, :cond_3d

    .line 54
    iget-boolean p1, p0, Lc4/m$a;->b:Z

    .line 56
    if-nez p1, :cond_3c

    .line 58
    invoke-interface {v1}, Lz5/b;->onComplete()V

    .line 61
    :cond_3c
    return-void

    .line 62
    :cond_3d
    if-eqz v6, :cond_7

    .line 64
    const-wide/16 v6, 0x1

    .line 66
    add-long/2addr v4, v6

    .line 67
    goto :goto_7

    .line 68
    :catchall_43
    move-exception p1

    .line 69
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 72
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 75
    return-void

    .line 76
    :catchall_4b
    move-exception p1

    .line 77
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 80
    invoke-interface {v1, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 83
    return-void

    .line 84
    :cond_53
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 87
    move-result-wide p1

    .line 88
    cmp-long v6, v4, p1

    .line 90
    if-nez v6, :cond_7

    .line 92
    neg-long p1, v4

    .line 93
    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 96
    move-result-wide p1

    .line 97
    cmp-long v4, p1, v2

    .line 99
    if-nez v4, :cond_6

    .line 101
    return-void
.end method
