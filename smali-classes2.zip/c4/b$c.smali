.class public final Lc4/b$c;
.super Lc4/b$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field public final m:Lz5/b;

.field public final n:Z


# direct methods
.method public constructor <init>(Lz5/b;LW3/e;IZ)V
    .registers 5

    .line 1
    invoke-direct {p0, p2, p3}, Lc4/b$b;-><init>(LW3/e;I)V

    .line 4
    iput-object p1, p0, Lc4/b$c;->m:Lz5/b;

    .line 6
    iput-boolean p4, p0, Lc4/b$c;->n:Z

    .line 8
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 3
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 6
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/b$b;->i:Z

    .line 3
    if-nez v0, :cond_11

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lc4/b$b;->i:Z

    .line 8
    iget-object v0, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 10
    invoke-virtual {v0}, Lj4/f;->cancel()V

    .line 13
    iget-object v0, p0, Lc4/b$b;->e:Lz5/c;

    .line 15
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 18
    :cond_11
    return-void
.end method

.method public f(J)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 3
    invoke-virtual {v0, p1, p2}, Lj4/f;->f(J)V

    .line 6
    return-void
.end method

.method public g(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 3
    invoke-virtual {v0, p1}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1b

    .line 9
    iget-boolean p1, p0, Lc4/b$c;->n:Z

    .line 11
    if-nez p1, :cond_14

    .line 13
    iget-object p1, p0, Lc4/b$b;->e:Lz5/c;

    .line 15
    invoke-interface {p1}, Lz5/c;->cancel()V

    .line 18
    const/4 p1, 0x1

    .line 19
    iput-boolean p1, p0, Lc4/b$b;->h:Z

    .line 21
    :cond_14
    const/4 p1, 0x0

    .line 22
    iput-boolean p1, p0, Lc4/b$b;->k:Z

    .line 24
    invoke-virtual {p0}, Lc4/b$c;->h()V

    .line 27
    goto :goto_1e

    .line 28
    :cond_1b
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 31
    :goto_1e
    return-void
.end method

.method public h()V
    .registers 7

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_fd

    .line 7
    :cond_6
    :goto_6
    iget-boolean v0, p0, Lc4/b$b;->i:Z

    .line 9
    if-eqz v0, :cond_b

    .line 11
    return-void

    .line 12
    :cond_b
    iget-boolean v0, p0, Lc4/b$b;->k:Z

    .line 14
    if-nez v0, :cond_f7

    .line 16
    iget-boolean v0, p0, Lc4/b$b;->h:Z

    .line 18
    if-eqz v0, :cond_2d

    .line 20
    iget-boolean v1, p0, Lc4/b$c;->n:Z

    .line 22
    if-nez v1, :cond_2d

    .line 24
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 26
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Ljava/lang/Throwable;

    .line 32
    if-eqz v1, :cond_2d

    .line 34
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 36
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 38
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 41
    move-result-object v1

    .line 42
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 45
    return-void

    .line 46
    :cond_2d
    :try_start_2d
    iget-object v1, p0, Lc4/b$b;->g:LZ3/j;

    .line 48
    invoke-interface {v1}, LZ3/j;->poll()Ljava/lang/Object;

    .line 51
    move-result-object v1
    :try_end_33
    .catchall {:try_start_2d .. :try_end_33} :catchall_dd

    .line 52
    const/4 v2, 0x0

    .line 53
    const/4 v3, 0x1

    .line 54
    if-nez v1, :cond_39

    .line 56
    move v4, v3

    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    move v4, v2

    .line 59
    :goto_3a
    if-eqz v0, :cond_52

    .line 61
    if-eqz v4, :cond_52

    .line 63
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 65
    invoke-virtual {v0}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 68
    move-result-object v0

    .line 69
    if-eqz v0, :cond_4c

    .line 71
    iget-object v1, p0, Lc4/b$c;->m:Lz5/b;

    .line 73
    invoke-interface {v1, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 76
    goto :goto_51

    .line 77
    :cond_4c
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 79
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 82
    :goto_51
    return-void

    .line 83
    :cond_52
    if-nez v4, :cond_f7

    .line 85
    :try_start_54
    iget-object v0, p0, Lc4/b$b;->b:LW3/e;

    .line 87
    invoke-interface {v0, v1}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    move-result-object v0

    .line 91
    const-string v1, "The mapper returned a null Publisher"

    .line 93
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 96
    move-result-object v0

    .line 97
    check-cast v0, Lz5/a;
    :try_end_62
    .catchall {:try_start_54 .. :try_end_62} :catchall_c3

    .line 99
    iget v1, p0, Lc4/b$b;->l:I

    .line 101
    if-eq v1, v3, :cond_78

    .line 103
    iget v1, p0, Lc4/b$b;->f:I

    .line 105
    add-int/2addr v1, v3

    .line 106
    iget v4, p0, Lc4/b$b;->d:I

    .line 108
    if-ne v1, v4, :cond_76

    .line 110
    iput v2, p0, Lc4/b$b;->f:I

    .line 112
    iget-object v2, p0, Lc4/b$b;->e:Lz5/c;

    .line 114
    int-to-long v4, v1

    .line 115
    invoke-interface {v2, v4, v5}, Lz5/c;->f(J)V

    .line 118
    goto :goto_78

    .line 119
    :cond_76
    iput v1, p0, Lc4/b$b;->f:I

    .line 121
    :cond_78
    :goto_78
    instance-of v1, v0, Ljava/util/concurrent/Callable;

    .line 123
    if-eqz v1, :cond_bb

    .line 125
    check-cast v0, Ljava/util/concurrent/Callable;

    .line 127
    :try_start_7e
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 130
    move-result-object v0
    :try_end_82
    .catchall {:try_start_7e .. :try_end_82} :catchall_a1

    .line 131
    if-nez v0, :cond_85

    .line 133
    goto :goto_6

    .line 134
    :cond_85
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 136
    invoke-virtual {v1}, Lj4/f;->g()Z

    .line 139
    move-result v1

    .line 140
    if-eqz v1, :cond_94

    .line 142
    iget-object v1, p0, Lc4/b$c;->m:Lz5/b;

    .line 144
    invoke-interface {v1, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 147
    goto/16 :goto_6

    .line 149
    :cond_94
    iput-boolean v3, p0, Lc4/b$b;->k:Z

    .line 151
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 153
    new-instance v2, Lc4/b$g;

    .line 155
    invoke-direct {v2, v0, v1}, Lc4/b$g;-><init>(Ljava/lang/Object;Lz5/b;)V

    .line 158
    invoke-virtual {v1, v2}, Lj4/f;->i(Lz5/c;)V

    .line 161
    goto :goto_f7

    .line 162
    :catchall_a1
    move-exception v0

    .line 163
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 166
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 168
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 171
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 173
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 176
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 178
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 180
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 183
    move-result-object v1

    .line 184
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 187
    return-void

    .line 188
    :cond_bb
    iput-boolean v3, p0, Lc4/b$b;->k:Z

    .line 190
    iget-object v1, p0, Lc4/b$b;->a:Lc4/b$e;

    .line 192
    invoke-interface {v0, v1}, Lz5/a;->a(Lz5/b;)V

    .line 195
    goto :goto_f7

    .line 196
    :catchall_c3
    move-exception v0

    .line 197
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 200
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 202
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 205
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 207
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 210
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 212
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 214
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 217
    move-result-object v1

    .line 218
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 221
    return-void

    .line 222
    :catchall_dd
    move-exception v0

    .line 223
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 226
    iget-object v1, p0, Lc4/b$b;->e:Lz5/c;

    .line 228
    invoke-interface {v1}, Lz5/c;->cancel()V

    .line 231
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 233
    invoke-virtual {v1, v0}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 236
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 238
    iget-object v1, p0, Lc4/b$b;->j:Lk4/c;

    .line 240
    invoke-virtual {v1}, Lk4/c;->b()Ljava/lang/Throwable;

    .line 243
    move-result-object v1

    .line 244
    invoke-interface {v0, v1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 247
    return-void

    .line 248
    :cond_f7
    :goto_f7
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 251
    move-result v0

    .line 252
    if-nez v0, :cond_6

    .line 254
    :cond_fd
    return-void
.end method

.method public i()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/b$c;->m:Lz5/b;

    .line 3
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/b$b;->j:Lk4/c;

    .line 3
    invoke-virtual {v0, p1}, Lk4/c;->a(Ljava/lang/Throwable;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_f

    .line 9
    const/4 p1, 0x1

    .line 10
    iput-boolean p1, p0, Lc4/b$b;->h:Z

    .line 12
    invoke-virtual {p0}, Lc4/b$c;->h()V

    .line 15
    goto :goto_12

    .line 16
    :cond_f
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 19
    :goto_12
    return-void
.end method
