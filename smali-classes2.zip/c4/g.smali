.class public final Lc4/g;
.super LQ3/f;
.source "SourceFile"

# interfaces
.implements LZ3/h;


# static fields
.field public static final b:LQ3/f;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lc4/g;

    .line 3
    invoke-direct {v0}, Lc4/g;-><init>()V

    .line 6
    sput-object v0, Lc4/g;->b:LQ3/f;

    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lj4/d;->a(Lz5/b;)V

    .line 4
    return-void
.end method

.method public call()Ljava/lang/Object;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method
