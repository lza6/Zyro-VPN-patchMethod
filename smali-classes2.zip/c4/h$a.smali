.class public final Lc4/h$a;
.super Li4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final f:LW3/g;


# direct methods
.method public constructor <init>(LZ3/a;LW3/g;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Li4/a;-><init>(LZ3/a;)V

    .line 4
    iput-object p2, p0, Lc4/h$a;->f:LW3/g;

    .line 6
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    invoke-virtual {p0, p1}, Lc4/h$a;->e(Ljava/lang/Object;)Z

    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_d

    .line 7
    iget-object p1, p0, Li4/a;->b:Lz5/c;

    .line 9
    const-wide/16 v0, 0x1

    .line 11
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 14
    :cond_d
    return-void
.end method

.method public e(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    iget-boolean v0, p0, Li4/a;->d:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 6
    return v1

    .line 7
    :cond_6
    iget v0, p0, Li4/a;->e:I

    .line 9
    if-eqz v0, :cond_12

    .line 11
    iget-object p1, p0, Li4/a;->a:LZ3/a;

    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-interface {p1, v0}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 17
    move-result p1

    .line 18
    return p1

    .line 19
    :cond_12
    const/4 v0, 0x1

    .line 20
    :try_start_13
    iget-object v2, p0, Lc4/h$a;->f:LW3/g;

    .line 22
    invoke-interface {v2, p1}, LW3/g;->test(Ljava/lang/Object;)Z

    .line 25
    move-result v2
    :try_end_19
    .catchall {:try_start_13 .. :try_end_19} :catchall_25

    .line 26
    if-eqz v2, :cond_24

    .line 28
    iget-object v2, p0, Li4/a;->a:LZ3/a;

    .line 30
    invoke-interface {v2, p1}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 33
    move-result p1

    .line 34
    if-eqz p1, :cond_24

    .line 36
    move v1, v0

    .line 37
    :cond_24
    return v1

    .line 38
    :catchall_25
    move-exception p1

    .line 39
    invoke-virtual {p0, p1}, Li4/a;->h(Ljava/lang/Throwable;)V

    .line 42
    return v0
.end method

.method public g(I)I
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Li4/a;->i(I)I

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public poll()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Li4/a;->c:LZ3/g;

    .line 3
    iget-object v1, p0, Lc4/h$a;->f:LW3/g;

    .line 5
    :cond_4
    :goto_4
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 8
    move-result-object v2

    .line 9
    if-nez v2, :cond_c

    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0

    .line 13
    :cond_c
    invoke-interface {v1, v2}, LW3/g;->test(Ljava/lang/Object;)Z

    .line 16
    move-result v3

    .line 17
    if-eqz v3, :cond_13

    .line 19
    return-object v2

    .line 20
    :cond_13
    iget v2, p0, Li4/a;->e:I

    .line 22
    const/4 v3, 0x2

    .line 23
    if-ne v2, v3, :cond_4

    .line 25
    const-wide/16 v2, 0x1

    .line 27
    invoke-interface {v0, v2, v3}, Lz5/c;->f(J)V

    .line 30
    goto :goto_4
.end method
