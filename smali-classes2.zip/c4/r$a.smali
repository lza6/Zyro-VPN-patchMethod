.class public abstract Lc4/r$a;
.super Lj4/a;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/r$b;

.field public final b:Z

.field public final c:I

.field public final d:I

.field public final e:Ljava/util/concurrent/atomic/AtomicLong;

.field public f:Lz5/c;

.field public g:LZ3/j;

.field public volatile h:Z

.field public volatile i:Z

.field public j:Ljava/lang/Throwable;

.field public k:I

.field public l:J

.field public m:Z


# direct methods
.method public constructor <init>(LQ3/r$b;ZI)V
    .registers 4

    .line 1
    invoke-direct {p0}, Lj4/a;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 6
    iput-boolean p2, p0, Lc4/r$a;->b:Z

    .line 8
    iput p3, p0, Lc4/r$a;->c:I

    .line 10
    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 12
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 15
    iput-object p1, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 17
    shr-int/lit8 p1, p3, 0x2

    .line 19
    sub-int/2addr p3, p1

    .line 20
    iput p3, p0, Lc4/r$a;->d:I

    .line 22
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->i:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget v0, p0, Lc4/r$a;->k:I

    .line 8
    const/4 v1, 0x2

    .line 9
    if-ne v0, v1, :cond_e

    .line 11
    invoke-virtual {p0}, Lc4/r$a;->k()V

    .line 14
    return-void

    .line 15
    :cond_e
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 17
    invoke-interface {v0, p1}, LZ3/j;->offer(Ljava/lang/Object;)Z

    .line 20
    move-result p1

    .line 21
    if-nez p1, :cond_27

    .line 23
    iget-object p1, p0, Lc4/r$a;->f:Lz5/c;

    .line 25
    invoke-interface {p1}, Lz5/c;->cancel()V

    .line 28
    new-instance p1, LU3/c;

    .line 30
    const-string v0, "Queue is full?!"

    .line 32
    invoke-direct {p1, v0}, LU3/c;-><init>(Ljava/lang/String;)V

    .line 35
    iput-object p1, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 37
    const/4 p1, 0x1

    .line 38
    iput-boolean p1, p0, Lc4/r$a;->i:Z

    .line 40
    :cond_27
    invoke-virtual {p0}, Lc4/r$a;->k()V

    .line 43
    return-void
.end method

.method public final cancel()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->h:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lc4/r$a;->h:Z

    .line 9
    iget-object v0, p0, Lc4/r$a;->f:Lz5/c;

    .line 11
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 14
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 16
    invoke-interface {v0}, LT3/b;->dispose()V

    .line 19
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1d

    .line 25
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 27
    invoke-interface {v0}, LZ3/j;->clear()V

    .line 30
    :cond_1d
    return-void
.end method

.method public final clear()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 3
    invoke-interface {v0}, LZ3/j;->clear()V

    .line 6
    return-void
.end method

.method public final d(ZZLz5/b;)Z
    .registers 6

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->h:Z

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_9

    .line 6
    invoke-virtual {p0}, Lc4/r$a;->clear()V

    .line 9
    return v1

    .line 10
    :cond_9
    if-eqz p1, :cond_3d

    .line 12
    iget-boolean p1, p0, Lc4/r$a;->b:Z

    .line 14
    if-eqz p1, :cond_22

    .line 16
    if-eqz p2, :cond_3d

    .line 18
    iget-object p1, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 20
    if-eqz p1, :cond_19

    .line 22
    invoke-interface {p3, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 25
    goto :goto_1c

    .line 26
    :cond_19
    invoke-interface {p3}, Lz5/b;->onComplete()V

    .line 29
    :goto_1c
    iget-object p1, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 31
    invoke-interface {p1}, LT3/b;->dispose()V

    .line 34
    return v1

    .line 35
    :cond_22
    iget-object p1, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 37
    if-eqz p1, :cond_32

    .line 39
    invoke-virtual {p0}, Lc4/r$a;->clear()V

    .line 42
    invoke-interface {p3, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 45
    iget-object p1, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 47
    invoke-interface {p1}, LT3/b;->dispose()V

    .line 50
    return v1

    .line 51
    :cond_32
    if-eqz p2, :cond_3d

    .line 53
    invoke-interface {p3}, Lz5/b;->onComplete()V

    .line 56
    iget-object p1, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 58
    invoke-interface {p1}, LT3/b;->dispose()V

    .line 61
    return v1

    .line 62
    :cond_3d
    const/4 p1, 0x0

    .line 63
    return p1
.end method

.method public final f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_e

    .line 7
    iget-object v0, p0, Lc4/r$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 9
    invoke-static {v0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 12
    invoke-virtual {p0}, Lc4/r$a;->k()V

    .line 15
    :cond_e
    return-void
.end method

.method public final g(I)I
    .registers 3

    .line 1
    const/4 v0, 0x2

    .line 2
    and-int/2addr p1, v0

    .line 3
    if-eqz p1, :cond_8

    .line 5
    const/4 p1, 0x1

    .line 6
    iput-boolean p1, p0, Lc4/r$a;->m:Z

    .line 8
    return v0

    .line 9
    :cond_8
    const/4 p1, 0x0

    .line 10
    return p1
.end method

.method public abstract h()V
.end method

.method public abstract i()V
.end method

.method public final isEmpty()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/r$a;->g:LZ3/j;

    .line 3
    invoke-interface {v0}, LZ3/j;->isEmpty()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public abstract j()V
.end method

.method public final k()V
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    iget-object v0, p0, Lc4/r$a;->a:LQ3/r$b;

    .line 10
    invoke-virtual {v0, p0}, LQ3/r$b;->b(Ljava/lang/Runnable;)LT3/b;

    .line 13
    return-void
.end method

.method public final onComplete()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->i:Z

    .line 3
    if-nez v0, :cond_a

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lc4/r$a;->i:Z

    .line 8
    invoke-virtual {p0}, Lc4/r$a;->k()V

    .line 11
    :cond_a
    return-void
.end method

.method public final onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->i:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    iput-object p1, p0, Lc4/r$a;->j:Ljava/lang/Throwable;

    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, p0, Lc4/r$a;->i:Z

    .line 14
    invoke-virtual {p0}, Lc4/r$a;->k()V

    .line 17
    return-void
.end method

.method public final run()V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/r$a;->m:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-virtual {p0}, Lc4/r$a;->i()V

    .line 8
    goto :goto_14

    .line 9
    :cond_8
    iget v0, p0, Lc4/r$a;->k:I

    .line 11
    const/4 v1, 0x1

    .line 12
    if-ne v0, v1, :cond_11

    .line 14
    invoke-virtual {p0}, Lc4/r$a;->j()V

    .line 17
    goto :goto_14

    .line 18
    :cond_11
    invoke-virtual {p0}, Lc4/r$a;->h()V

    .line 21
    :goto_14
    return-void
.end method
