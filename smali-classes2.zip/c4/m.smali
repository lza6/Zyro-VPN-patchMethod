.class public final Lc4/m;
.super LQ3/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/m$b;,
        Lc4/m$c;,
        Lc4/m$a;
    }
.end annotation


# instance fields
.field public final b:Ljava/lang/Iterable;


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/m;->b:Ljava/lang/Iterable;

    .line 6
    return-void
.end method

.method public static K(Lz5/b;Ljava/util/Iterator;)V
    .registers 4

    .line 1
    :try_start_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 4
    move-result v0
    :try_end_4
    .catchall {:try_start_0 .. :try_end_4} :catchall_23

    .line 5
    if-nez v0, :cond_a

    .line 7
    invoke-static {p0}, Lj4/d;->a(Lz5/b;)V

    .line 10
    return-void

    .line 11
    :cond_a
    instance-of v0, p0, LZ3/a;

    .line 13
    if-eqz v0, :cond_1a

    .line 15
    new-instance v0, Lc4/m$b;

    .line 17
    move-object v1, p0

    .line 18
    check-cast v1, LZ3/a;

    .line 20
    invoke-direct {v0, v1, p1}, Lc4/m$b;-><init>(LZ3/a;Ljava/util/Iterator;)V

    .line 23
    invoke-interface {p0, v0}, Lz5/b;->c(Lz5/c;)V

    .line 26
    goto :goto_22

    .line 27
    :cond_1a
    new-instance v0, Lc4/m$c;

    .line 29
    invoke-direct {v0, p0, p1}, Lc4/m$c;-><init>(Lz5/b;Ljava/util/Iterator;)V

    .line 32
    invoke-interface {p0, v0}, Lz5/b;->c(Lz5/c;)V

    .line 35
    :goto_22
    return-void

    .line 36
    :catchall_23
    move-exception p1

    .line 37
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 40
    invoke-static {p1, p0}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 43
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 3

    .line 1
    :try_start_0
    iget-object v0, p0, Lc4/m;->b:Ljava/lang/Iterable;

    .line 3
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 6
    move-result-object v0
    :try_end_6
    .catchall {:try_start_0 .. :try_end_6} :catchall_a

    .line 7
    invoke-static {p1, v0}, Lc4/m;->K(Lz5/b;Ljava/util/Iterator;)V

    .line 10
    return-void

    .line 11
    :catchall_a
    move-exception v0

    .line 12
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 15
    invoke-static {v0, p1}, Lj4/d;->b(Ljava/lang/Throwable;Lz5/b;)V

    .line 18
    return-void
.end method
