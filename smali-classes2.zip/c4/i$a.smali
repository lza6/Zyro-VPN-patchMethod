.class public final Lc4/i$a;
.super Ljava/util/concurrent/atomic/AtomicReference;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:J

.field public final b:Lc4/i$b;

.field public final c:I

.field public final d:I

.field public volatile e:Z

.field public volatile f:LZ3/j;

.field public g:J

.field public h:I


# direct methods
.method public constructor <init>(Lc4/i$b;J)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 4
    iput-wide p2, p0, Lc4/i$a;->a:J

    .line 6
    iput-object p1, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 8
    iget p1, p1, Lc4/i$b;->e:I

    .line 10
    iput p1, p0, Lc4/i$a;->d:I

    .line 12
    shr-int/lit8 p1, p1, 0x2

    .line 14
    iput p1, p0, Lc4/i$a;->c:I

    .line 16
    return-void
.end method


# virtual methods
.method public a(J)V
    .registers 5

    .line 1
    iget v0, p0, Lc4/i$a;->h:I

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eq v0, v1, :cond_1f

    .line 6
    iget-wide v0, p0, Lc4/i$a;->g:J

    .line 8
    add-long/2addr v0, p1

    .line 9
    iget p1, p0, Lc4/i$a;->c:I

    .line 11
    int-to-long p1, p1

    .line 12
    cmp-long p1, v0, p1

    .line 14
    if-ltz p1, :cond_1d

    .line 16
    const-wide/16 p1, 0x0

    .line 18
    iput-wide p1, p0, Lc4/i$a;->g:J

    .line 20
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 23
    move-result-object p1

    .line 24
    check-cast p1, Lz5/c;

    .line 26
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    iput-wide v0, p0, Lc4/i$a;->g:J

    .line 32
    :cond_1f
    :goto_1f
    return-void
.end method

.method public b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget v0, p0, Lc4/i$a;->h:I

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eq v0, v1, :cond_b

    .line 6
    iget-object v0, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 8
    invoke-virtual {v0, p1, p0}, Lc4/i$b;->o(Ljava/lang/Object;Lc4/i$a;)V

    .line 11
    goto :goto_10

    .line 12
    :cond_b
    iget-object p1, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 14
    invoke-virtual {p1}, Lc4/i$b;->i()V

    .line 17
    :goto_10
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 5

    .line 1
    invoke-static {p0, p1}, Lj4/g;->g(Ljava/util/concurrent/atomic/AtomicReference;Lz5/c;)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_2e

    .line 7
    instance-of v0, p1, LZ3/g;

    .line 9
    if-eqz v0, :cond_28

    .line 11
    move-object v0, p1

    .line 12
    check-cast v0, LZ3/g;

    .line 14
    const/4 v1, 0x7

    .line 15
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 18
    move-result v1

    .line 19
    const/4 v2, 0x1

    .line 20
    if-ne v1, v2, :cond_21

    .line 22
    iput v1, p0, Lc4/i$a;->h:I

    .line 24
    iput-object v0, p0, Lc4/i$a;->f:LZ3/j;

    .line 26
    iput-boolean v2, p0, Lc4/i$a;->e:Z

    .line 28
    iget-object p1, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 30
    invoke-virtual {p1}, Lc4/i$b;->i()V

    .line 33
    return-void

    .line 34
    :cond_21
    const/4 v2, 0x2

    .line 35
    if-ne v1, v2, :cond_28

    .line 37
    iput v1, p0, Lc4/i$a;->h:I

    .line 39
    iput-object v0, p0, Lc4/i$a;->f:LZ3/j;

    .line 41
    :cond_28
    iget v0, p0, Lc4/i$a;->d:I

    .line 43
    int-to-long v0, v0

    .line 44
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 47
    :cond_2e
    return-void
.end method

.method public d()Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lj4/g;->a:Lj4/g;

    .line 7
    if-ne v0, v1, :cond_a

    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    :goto_b
    return v0
.end method

.method public dispose()V
    .registers 1

    .line 1
    invoke-static {p0}, Lj4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    .line 4
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lc4/i$a;->e:Z

    .line 4
    iget-object v0, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 6
    invoke-virtual {v0}, Lc4/i$b;->i()V

    .line 9
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 3
    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    .line 6
    iget-object v0, p0, Lc4/i$a;->b:Lc4/i$b;

    .line 8
    invoke-virtual {v0, p0, p1}, Lc4/i$b;->m(Lc4/i$a;Ljava/lang/Throwable;)V

    .line 11
    return-void
.end method
