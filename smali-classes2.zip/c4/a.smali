.class public abstract Lc4/a;
.super LQ3/f;
.source "SourceFile"


# instance fields
.field public final b:LQ3/f;


# direct methods
.method public constructor <init>(LQ3/f;)V
    .registers 3

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    const-string v0, "source is null"

    .line 6
    invoke-static {p1, v0}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    move-result-object p1

    .line 10
    check-cast p1, LQ3/f;

    .line 12
    iput-object p1, p0, Lc4/a;->b:LQ3/f;

    .line 14
    return-void
.end method
