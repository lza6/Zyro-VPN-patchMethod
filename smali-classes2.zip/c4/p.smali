.class public final Lc4/p;
.super LQ3/f;
.source "SourceFile"

# interfaces
.implements LZ3/h;


# instance fields
.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-direct {p0}, LQ3/f;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/p;->b:Ljava/lang/Object;

    .line 6
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 4

    .line 1
    new-instance v0, Lj4/e;

    .line 3
    iget-object v1, p0, Lc4/p;->b:Ljava/lang/Object;

    .line 5
    invoke-direct {v0, p1, v1}, Lj4/e;-><init>(Lz5/b;Ljava/lang/Object;)V

    .line 8
    invoke-interface {p1, v0}, Lz5/b;->c(Lz5/c;)V

    .line 11
    return-void
.end method

.method public call()Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/p;->b:Ljava/lang/Object;

    .line 3
    return-object v0
.end method
