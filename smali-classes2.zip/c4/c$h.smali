.class public abstract Lc4/c$h;
.super Lc4/c$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "h"
.end annotation


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/c$b;-><init>(Lz5/b;)V

    .line 4
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Lc4/c$b;->d()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    if-nez p1, :cond_14

    .line 10
    new-instance p1, Ljava/lang/NullPointerException;

    .line 12
    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    .line 14
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 17
    invoke-virtual {p0, p1}, Lc4/c$b;->e(Ljava/lang/Throwable;)V

    .line 20
    return-void

    .line 21
    :cond_14
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 24
    move-result-wide v0

    .line 25
    const-wide/16 v2, 0x0

    .line 27
    cmp-long v0, v0, v2

    .line 29
    if-eqz v0, :cond_29

    .line 31
    iget-object v0, p0, Lc4/c$b;->a:Lz5/b;

    .line 33
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 36
    const-wide/16 v0, 0x1

    .line 38
    invoke-static {p0, v0, v1}, Lk4/d;->d(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 41
    goto :goto_2c

    .line 42
    :cond_29
    invoke-virtual {p0}, Lc4/c$h;->j()V

    .line 45
    :goto_2c
    return-void
.end method

.method public abstract j()V
.end method
