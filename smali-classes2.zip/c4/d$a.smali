.class public final Lc4/d$a;
.super Li4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final f:LW3/d;

.field public final g:LW3/d;

.field public final h:LW3/a;

.field public final i:LW3/a;


# direct methods
.method public constructor <init>(LZ3/a;LW3/d;LW3/d;LW3/a;LW3/a;)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Li4/a;-><init>(LZ3/a;)V

    .line 4
    iput-object p2, p0, Lc4/d$a;->f:LW3/d;

    .line 6
    iput-object p3, p0, Lc4/d$a;->g:LW3/d;

    .line 8
    iput-object p4, p0, Lc4/d$a;->h:LW3/a;

    .line 10
    iput-object p5, p0, Lc4/d$a;->i:LW3/a;

    .line 12
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Li4/a;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget v0, p0, Li4/a;->e:I

    .line 8
    if-eqz v0, :cond_10

    .line 10
    iget-object p1, p0, Li4/a;->a:LZ3/a;

    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-interface {p1, v0}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 16
    return-void

    .line 17
    :cond_10
    :try_start_10
    iget-object v0, p0, Lc4/d$a;->f:LW3/d;

    .line 19
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_15
    .catchall {:try_start_10 .. :try_end_15} :catchall_1b

    .line 22
    iget-object v0, p0, Li4/a;->a:LZ3/a;

    .line 24
    invoke-interface {v0, p1}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 27
    return-void

    .line 28
    :catchall_1b
    move-exception p1

    .line 29
    invoke-virtual {p0, p1}, Li4/a;->h(Ljava/lang/Throwable;)V

    .line 32
    return-void
.end method

.method public e(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    iget-boolean v0, p0, Li4/a;->d:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 6
    return v1

    .line 7
    :cond_6
    :try_start_6
    iget-object v0, p0, Lc4/d$a;->f:LW3/d;

    .line 9
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_b
    .catchall {:try_start_6 .. :try_end_b} :catchall_12

    .line 12
    iget-object v0, p0, Li4/a;->a:LZ3/a;

    .line 14
    invoke-interface {v0, p1}, LZ3/a;->e(Ljava/lang/Object;)Z

    .line 17
    move-result p1

    .line 18
    return p1

    .line 19
    :catchall_12
    move-exception p1

    .line 20
    invoke-virtual {p0, p1}, Li4/a;->h(Ljava/lang/Throwable;)V

    .line 23
    return v1
.end method

.method public g(I)I
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Li4/a;->i(I)I

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Li4/a;->d:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    :try_start_5
    iget-object v0, p0, Lc4/d$a;->h:LW3/a;

    .line 8
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_a
    .catchall {:try_start_5 .. :try_end_a} :catchall_20

    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Li4/a;->d:Z

    .line 14
    iget-object v0, p0, Li4/a;->a:LZ3/a;

    .line 16
    invoke-interface {v0}, Lz5/b;->onComplete()V

    .line 19
    :try_start_12
    iget-object v0, p0, Lc4/d$a;->i:LW3/a;

    .line 21
    invoke-interface {v0}, LW3/a;->run()V
    :try_end_17
    .catchall {:try_start_12 .. :try_end_17} :catchall_18

    .line 24
    goto :goto_1f

    .line 25
    :catchall_18
    move-exception v0

    .line 26
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 29
    invoke-static {v0}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 32
    :goto_1f
    return-void

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    invoke-virtual {p0, v0}, Li4/a;->h(Ljava/lang/Throwable;)V

    .line 37
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    iget-boolean v0, p0, Li4/a;->d:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Li4/a;->d:Z

    .line 12
    :try_start_b
    iget-object v0, p0, Lc4/d$a;->g:LW3/d;

    .line 14
    invoke-interface {v0, p1}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_10
    .catchall {:try_start_b .. :try_end_10} :catchall_16

    .line 17
    iget-object v0, p0, Li4/a;->a:LZ3/a;

    .line 19
    invoke-interface {v0, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 22
    goto :goto_28

    .line 23
    :catchall_16
    move-exception v0

    .line 24
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 27
    iget-object v1, p0, Li4/a;->a:LZ3/a;

    .line 29
    new-instance v2, LU3/a;

    .line 31
    filled-new-array {p1, v0}, [Ljava/lang/Throwable;

    .line 34
    move-result-object p1

    .line 35
    invoke-direct {v2, p1}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 38
    invoke-interface {v1, v2}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 41
    :goto_28
    :try_start_28
    iget-object p1, p0, Lc4/d$a;->i:LW3/a;

    .line 43
    invoke-interface {p1}, LW3/a;->run()V
    :try_end_2d
    .catchall {:try_start_28 .. :try_end_2d} :catchall_2e

    .line 46
    goto :goto_35

    .line 47
    :catchall_2e
    move-exception p1

    .line 48
    invoke-static {p1}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 51
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 54
    :goto_35
    return-void
.end method

.method public poll()Ljava/lang/Object;
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Li4/a;->c:LZ3/g;

    .line 3
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 6
    move-result-object v0
    :try_end_6
    .catchall {:try_start_0 .. :try_end_6} :catchall_44

    .line 7
    if-eqz v0, :cond_34

    .line 9
    :try_start_8
    iget-object v1, p0, Lc4/d$a;->f:LW3/d;

    .line 11
    invoke-interface {v1, v0}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_d
    .catchall {:try_start_8 .. :try_end_d} :catchall_13

    .line 14
    iget-object v1, p0, Lc4/d$a;->i:LW3/a;

    .line 16
    invoke-interface {v1}, LW3/a;->run()V

    .line 19
    goto :goto_43

    .line 20
    :catchall_13
    move-exception v0

    .line 21
    :try_start_14
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V
    :try_end_17
    .catchall {:try_start_14 .. :try_end_17} :catchall_21

    .line 24
    :try_start_17
    iget-object v1, p0, Lc4/d$a;->g:LW3/d;

    .line 26
    invoke-interface {v1, v0}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_1c
    .catchall {:try_start_17 .. :try_end_1c} :catchall_23

    .line 29
    :try_start_1c
    invoke-static {v0}, Lk4/g;->c(Ljava/lang/Throwable;)Ljava/lang/Exception;

    .line 32
    move-result-object v0

    .line 33
    throw v0

    .line 34
    :catchall_21
    move-exception v0

    .line 35
    goto :goto_2e

    .line 36
    :catchall_23
    move-exception v1

    .line 37
    new-instance v2, LU3/a;

    .line 39
    filled-new-array {v0, v1}, [Ljava/lang/Throwable;

    .line 42
    move-result-object v0

    .line 43
    invoke-direct {v2, v0}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 46
    throw v2
    :try_end_2e
    .catchall {:try_start_1c .. :try_end_2e} :catchall_21

    .line 47
    :goto_2e
    iget-object v1, p0, Lc4/d$a;->i:LW3/a;

    .line 49
    invoke-interface {v1}, LW3/a;->run()V

    .line 52
    throw v0

    .line 53
    :cond_34
    iget v1, p0, Li4/a;->e:I

    .line 55
    const/4 v2, 0x1

    .line 56
    if-ne v1, v2, :cond_43

    .line 58
    iget-object v1, p0, Lc4/d$a;->h:LW3/a;

    .line 60
    invoke-interface {v1}, LW3/a;->run()V

    .line 63
    iget-object v1, p0, Lc4/d$a;->i:LW3/a;

    .line 65
    invoke-interface {v1}, LW3/a;->run()V

    .line 68
    :cond_43
    :goto_43
    return-object v0

    .line 69
    :catchall_44
    move-exception v0

    .line 70
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 73
    :try_start_48
    iget-object v1, p0, Lc4/d$a;->g:LW3/d;

    .line 75
    invoke-interface {v1, v0}, LW3/d;->accept(Ljava/lang/Object;)V
    :try_end_4d
    .catchall {:try_start_48 .. :try_end_4d} :catchall_52

    .line 78
    invoke-static {v0}, Lk4/g;->c(Ljava/lang/Throwable;)Ljava/lang/Exception;

    .line 81
    move-result-object v0

    .line 82
    throw v0

    .line 83
    :catchall_52
    move-exception v1

    .line 84
    new-instance v2, LU3/a;

    .line 86
    filled-new-array {v0, v1}, [Ljava/lang/Throwable;

    .line 89
    move-result-object v0

    .line 90
    invoke-direct {v2, v0}, LU3/a;-><init>([Ljava/lang/Throwable;)V

    .line 93
    throw v2
.end method
