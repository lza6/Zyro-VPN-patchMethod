.class public final Lc4/k$a;
.super Lj4/a;
.source "SourceFile"

# interfaces
.implements LQ3/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public final b:LW3/e;

.field public final c:I

.field public final d:I

.field public final e:Ljava/util/concurrent/atomic/AtomicLong;

.field public f:Lz5/c;

.field public g:LZ3/j;

.field public volatile h:Z

.field public volatile i:Z

.field public final j:Ljava/util/concurrent/atomic/AtomicReference;

.field public k:Ljava/util/Iterator;

.field public l:I

.field public m:I


# direct methods
.method public constructor <init>(Lz5/b;LW3/e;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Lj4/a;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/k$a;->a:Lz5/b;

    .line 6
    iput-object p2, p0, Lc4/k$a;->b:LW3/e;

    .line 8
    iput p3, p0, Lc4/k$a;->c:I

    .line 10
    shr-int/lit8 p1, p3, 0x2

    .line 12
    sub-int/2addr p3, p1

    .line 13
    iput p3, p0, Lc4/k$a;->d:I

    .line 15
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 20
    iput-object p1, p0, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 22
    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 24
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 27
    iput-object p1, p0, Lc4/k$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 29
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/k$a;->h:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget v0, p0, Lc4/k$a;->m:I

    .line 8
    if-nez v0, :cond_1c

    .line 10
    iget-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 12
    invoke-interface {v0, p1}, LZ3/j;->offer(Ljava/lang/Object;)Z

    .line 15
    move-result p1

    .line 16
    if-nez p1, :cond_1c

    .line 18
    new-instance p1, LU3/c;

    .line 20
    const-string v0, "Queue is full?!"

    .line 22
    invoke-direct {p1, v0}, LU3/c;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-virtual {p0, p1}, Lc4/k$a;->onError(Ljava/lang/Throwable;)V

    .line 28
    return-void

    .line 29
    :cond_1c
    invoke-virtual {p0}, Lc4/k$a;->i()V

    .line 32
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/k$a;->f:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_4c

    .line 9
    iput-object p1, p0, Lc4/k$a;->f:Lz5/c;

    .line 11
    instance-of v0, p1, LZ3/g;

    .line 13
    if-eqz v0, :cond_38

    .line 15
    move-object v0, p1

    .line 16
    check-cast v0, LZ3/g;

    .line 18
    const/4 v1, 0x3

    .line 19
    invoke-interface {v0, v1}, LZ3/f;->g(I)I

    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x1

    .line 24
    if-ne v1, v2, :cond_25

    .line 26
    iput v1, p0, Lc4/k$a;->m:I

    .line 28
    iput-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 30
    iput-boolean v2, p0, Lc4/k$a;->h:Z

    .line 32
    iget-object p1, p0, Lc4/k$a;->a:Lz5/b;

    .line 34
    invoke-interface {p1, p0}, Lz5/b;->c(Lz5/c;)V

    .line 37
    return-void

    .line 38
    :cond_25
    const/4 v2, 0x2

    .line 39
    if-ne v1, v2, :cond_38

    .line 41
    iput v1, p0, Lc4/k$a;->m:I

    .line 43
    iput-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 45
    iget-object v0, p0, Lc4/k$a;->a:Lz5/b;

    .line 47
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 50
    iget v0, p0, Lc4/k$a;->c:I

    .line 52
    int-to-long v0, v0

    .line 53
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 56
    return-void

    .line 57
    :cond_38
    new-instance v0, Lg4/a;

    .line 59
    iget v1, p0, Lc4/k$a;->c:I

    .line 61
    invoke-direct {v0, v1}, Lg4/a;-><init>(I)V

    .line 64
    iput-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 66
    iget-object v0, p0, Lc4/k$a;->a:Lz5/b;

    .line 68
    invoke-interface {v0, p0}, Lz5/b;->c(Lz5/c;)V

    .line 71
    iget v0, p0, Lc4/k$a;->c:I

    .line 73
    int-to-long v0, v0

    .line 74
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 77
    :cond_4c
    return-void
.end method

.method public cancel()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/k$a;->i:Z

    .line 3
    if-nez v0, :cond_17

    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lc4/k$a;->i:Z

    .line 8
    iget-object v0, p0, Lc4/k$a;->f:Lz5/c;

    .line 10
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 13
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_17

    .line 19
    iget-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 21
    invoke-interface {v0}, LZ3/j;->clear()V

    .line 24
    :cond_17
    return-void
.end method

.method public clear()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 4
    iget-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 6
    invoke-interface {v0}, LZ3/j;->clear()V

    .line 9
    return-void
.end method

.method public d(ZZLz5/b;LZ3/j;)Z
    .registers 8

    .line 1
    iget-boolean v0, p0, Lc4/k$a;->i:Z

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_c

    .line 7
    iput-object v1, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 9
    invoke-interface {p4}, LZ3/j;->clear()V

    .line 12
    return v2

    .line 13
    :cond_c
    if-eqz p1, :cond_2d

    .line 15
    iget-object p1, p0, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 20
    move-result-object p1

    .line 21
    check-cast p1, Ljava/lang/Throwable;

    .line 23
    if-eqz p1, :cond_27

    .line 25
    iget-object p1, p0, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 27
    invoke-static {p1}, Lk4/g;->b(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    .line 30
    move-result-object p1

    .line 31
    iput-object v1, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 33
    invoke-interface {p4}, LZ3/j;->clear()V

    .line 36
    invoke-interface {p3, p1}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 39
    return v2

    .line 40
    :cond_27
    if-eqz p2, :cond_2d

    .line 42
    invoke-interface {p3}, Lz5/b;->onComplete()V

    .line 45
    return v2

    .line 46
    :cond_2d
    const/4 p1, 0x0

    .line 47
    return p1
.end method

.method public f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_e

    .line 7
    iget-object v0, p0, Lc4/k$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 9
    invoke-static {v0, p1, p2}, Lk4/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 12
    invoke-virtual {p0}, Lc4/k$a;->i()V

    .line 15
    :cond_e
    return-void
.end method

.method public g(I)I
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    and-int/2addr p1, v0

    .line 3
    if-eqz p1, :cond_9

    .line 5
    iget p1, p0, Lc4/k$a;->m:I

    .line 7
    if-ne p1, v0, :cond_9

    .line 9
    return v0

    .line 10
    :cond_9
    const/4 p1, 0x0

    .line 11
    return p1
.end method

.method public h(Z)V
    .registers 5

    .line 1
    if-eqz p1, :cond_16

    .line 3
    iget p1, p0, Lc4/k$a;->l:I

    .line 5
    add-int/lit8 p1, p1, 0x1

    .line 7
    iget v0, p0, Lc4/k$a;->d:I

    .line 9
    if-ne p1, v0, :cond_14

    .line 11
    const/4 v0, 0x0

    .line 12
    iput v0, p0, Lc4/k$a;->l:I

    .line 14
    iget-object v0, p0, Lc4/k$a;->f:Lz5/c;

    .line 16
    int-to-long v1, p1

    .line 17
    invoke-interface {v0, v1, v2}, Lz5/c;->f(J)V

    .line 20
    goto :goto_16

    .line 21
    :cond_14
    iput p1, p0, Lc4/k$a;->l:I

    .line 23
    :cond_16
    :goto_16
    return-void
.end method

.method public i()V
    .registers 19

    .line 1
    move-object/from16 v1, p0

    .line 3
    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    iget-object v2, v1, Lc4/k$a;->a:Lz5/b;

    .line 12
    iget-object v3, v1, Lc4/k$a;->g:LZ3/j;

    .line 14
    iget v0, v1, Lc4/k$a;->m:I

    .line 16
    const/4 v4, 0x0

    .line 17
    const/4 v5, 0x1

    .line 18
    if-eq v0, v5, :cond_15

    .line 20
    move v0, v5

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, v4

    .line 23
    :goto_16
    iget-object v6, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 25
    move v7, v5

    .line 26
    :goto_19
    const/4 v8, 0x0

    .line 27
    if-nez v6, :cond_80

    .line 29
    iget-boolean v9, v1, Lc4/k$a;->h:Z

    .line 31
    :try_start_1e
    invoke-interface {v3}, LZ3/j;->poll()Ljava/lang/Object;

    .line 34
    move-result-object v10
    :try_end_22
    .catchall {:try_start_1e .. :try_end_22} :catchall_62

    .line 35
    if-nez v10, :cond_26

    .line 37
    move v11, v5

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v11, v4

    .line 40
    :goto_27
    invoke-virtual {v1, v9, v11, v2, v3}, Lc4/k$a;->d(ZZLz5/b;LZ3/j;)Z

    .line 43
    move-result v9

    .line 44
    if-eqz v9, :cond_2e

    .line 46
    return-void

    .line 47
    :cond_2e
    if-eqz v10, :cond_80

    .line 49
    :try_start_30
    iget-object v6, v1, Lc4/k$a;->b:LW3/e;

    .line 51
    invoke-interface {v6, v10}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    move-result-object v6

    .line 55
    check-cast v6, Ljava/lang/Iterable;

    .line 57
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 60
    move-result-object v6

    .line 61
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    move-result v9
    :try_end_40
    .catchall {:try_start_30 .. :try_end_40} :catchall_4a

    .line 65
    if-nez v9, :cond_47

    .line 67
    invoke-virtual {v1, v0}, Lc4/k$a;->h(Z)V

    .line 70
    move-object v6, v8

    .line 71
    goto :goto_19

    .line 72
    :cond_47
    iput-object v6, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 74
    goto :goto_80

    .line 75
    :catchall_4a
    move-exception v0

    .line 76
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 79
    iget-object v3, v1, Lc4/k$a;->f:Lz5/c;

    .line 81
    invoke-interface {v3}, Lz5/c;->cancel()V

    .line 84
    iget-object v3, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 86
    invoke-static {v3, v0}, Lk4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    .line 89
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 91
    invoke-static {v0}, Lk4/g;->b(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    .line 94
    move-result-object v0

    .line 95
    invoke-interface {v2, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 98
    return-void

    .line 99
    :catchall_62
    move-exception v0

    .line 100
    move-object v4, v0

    .line 101
    invoke-static {v4}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 104
    iget-object v0, v1, Lc4/k$a;->f:Lz5/c;

    .line 106
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 109
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 111
    invoke-static {v0, v4}, Lk4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    .line 114
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 116
    invoke-static {v0}, Lk4/g;->b(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    .line 119
    move-result-object v0

    .line 120
    iput-object v8, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 122
    invoke-interface {v3}, LZ3/j;->clear()V

    .line 125
    invoke-interface {v2, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 128
    return-void

    .line 129
    :cond_80
    :goto_80
    if-eqz v6, :cond_126

    .line 131
    iget-object v9, v1, Lc4/k$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 133
    invoke-virtual {v9}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 136
    move-result-wide v9

    .line 137
    const-wide/16 v11, 0x0

    .line 139
    move-wide v13, v11

    .line 140
    :goto_8b
    cmp-long v15, v13, v9

    .line 142
    if-eqz v15, :cond_f6

    .line 144
    iget-boolean v15, v1, Lc4/k$a;->h:Z

    .line 146
    invoke-virtual {v1, v15, v4, v2, v3}, Lc4/k$a;->d(ZZLz5/b;LZ3/j;)Z

    .line 149
    move-result v15

    .line 150
    if-eqz v15, :cond_98

    .line 152
    return-void

    .line 153
    :cond_98
    :try_start_98
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    move-result-object v15

    .line 157
    const-string v5, "The iterator returned a null value"

    .line 159
    invoke-static {v15, v5}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 162
    move-result-object v5
    :try_end_a2
    .catchall {:try_start_98 .. :try_end_a2} :catchall_dc

    .line 163
    invoke-interface {v2, v5}, Lz5/b;->b(Ljava/lang/Object;)V

    .line 166
    iget-boolean v5, v1, Lc4/k$a;->h:Z

    .line 168
    invoke-virtual {v1, v5, v4, v2, v3}, Lc4/k$a;->d(ZZLz5/b;LZ3/j;)Z

    .line 171
    move-result v5

    .line 172
    if-eqz v5, :cond_ae

    .line 174
    return-void

    .line 175
    :cond_ae
    const-wide/16 v16, 0x1

    .line 177
    add-long v13, v13, v16

    .line 179
    :try_start_b2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 182
    move-result v5
    :try_end_b6
    .catchall {:try_start_b2 .. :try_end_b6} :catchall_c1

    .line 183
    if-nez v5, :cond_bf

    .line 185
    invoke-virtual {v1, v0}, Lc4/k$a;->h(Z)V

    .line 188
    iput-object v8, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 190
    move-object v6, v8

    .line 191
    goto :goto_f6

    .line 192
    :cond_bf
    const/4 v5, 0x1

    .line 193
    goto :goto_8b

    .line 194
    :catchall_c1
    move-exception v0

    .line 195
    move-object v3, v0

    .line 196
    invoke-static {v3}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 199
    iput-object v8, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 201
    iget-object v0, v1, Lc4/k$a;->f:Lz5/c;

    .line 203
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 206
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 208
    invoke-static {v0, v3}, Lk4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    .line 211
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 213
    invoke-static {v0}, Lk4/g;->b(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    .line 216
    move-result-object v0

    .line 217
    invoke-interface {v2, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 220
    return-void

    .line 221
    :catchall_dc
    move-exception v0

    .line 222
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 225
    iput-object v8, v1, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 227
    iget-object v3, v1, Lc4/k$a;->f:Lz5/c;

    .line 229
    invoke-interface {v3}, Lz5/c;->cancel()V

    .line 232
    iget-object v3, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 234
    invoke-static {v3, v0}, Lk4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    .line 237
    iget-object v0, v1, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 239
    invoke-static {v0}, Lk4/g;->b(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    .line 242
    move-result-object v0

    .line 243
    invoke-interface {v2, v0}, Lz5/b;->onError(Ljava/lang/Throwable;)V

    .line 246
    return-void

    .line 247
    :cond_f6
    :goto_f6
    cmp-long v5, v13, v9

    .line 249
    if-nez v5, :cond_10e

    .line 251
    iget-boolean v5, v1, Lc4/k$a;->h:Z

    .line 253
    invoke-interface {v3}, LZ3/j;->isEmpty()Z

    .line 256
    move-result v8

    .line 257
    if-eqz v8, :cond_106

    .line 259
    if-nez v6, :cond_106

    .line 261
    const/4 v8, 0x1

    .line 262
    goto :goto_107

    .line 263
    :cond_106
    move v8, v4

    .line 264
    :goto_107
    invoke-virtual {v1, v5, v8, v2, v3}, Lc4/k$a;->d(ZZLz5/b;LZ3/j;)Z

    .line 267
    move-result v5

    .line 268
    if-eqz v5, :cond_10e

    .line 270
    return-void

    .line 271
    :cond_10e
    cmp-long v5, v13, v11

    .line 273
    if-eqz v5, :cond_121

    .line 275
    const-wide v11, 0x7fffffffffffffffL

    .line 280
    cmp-long v5, v9, v11

    .line 282
    if-eqz v5, :cond_121

    .line 284
    iget-object v5, v1, Lc4/k$a;->e:Ljava/util/concurrent/atomic/AtomicLong;

    .line 286
    neg-long v8, v13

    .line 287
    invoke-virtual {v5, v8, v9}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    .line 290
    :cond_121
    if-nez v6, :cond_126

    .line 292
    :cond_123
    const/4 v5, 0x1

    .line 293
    goto/16 :goto_19

    .line 295
    :cond_126
    neg-int v5, v7

    .line 296
    invoke-virtual {v1, v5}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    .line 299
    move-result v7

    .line 300
    if-nez v7, :cond_123

    .line 302
    return-void
.end method

.method public isEmpty()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 3
    if-nez v0, :cond_e

    .line 5
    iget-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 7
    invoke-interface {v0}, LZ3/j;->isEmpty()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_e

    .line 13
    const/4 v0, 0x1

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    return v0
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc4/k$a;->h:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lc4/k$a;->h:Z

    .line 9
    invoke-virtual {p0}, Lc4/k$a;->i()V

    .line 12
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/k$a;->h:Z

    .line 3
    if-nez v0, :cond_13

    .line 5
    iget-object v0, p0, Lc4/k$a;->j:Ljava/util/concurrent/atomic/AtomicReference;

    .line 7
    invoke-static {v0, p1}, Lk4/g;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_13

    .line 13
    const/4 p1, 0x1

    .line 14
    iput-boolean p1, p0, Lc4/k$a;->h:Z

    .line 16
    invoke-virtual {p0}, Lc4/k$a;->i()V

    .line 19
    goto :goto_16

    .line 20
    :cond_13
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 23
    :goto_16
    return-void
.end method

.method public poll()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 3
    :goto_2
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_24

    .line 6
    iget-object v0, p0, Lc4/k$a;->g:LZ3/j;

    .line 8
    invoke-interface {v0}, LZ3/j;->poll()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_e

    .line 14
    return-object v1

    .line 15
    :cond_e
    iget-object v2, p0, Lc4/k$a;->b:LW3/e;

    .line 17
    invoke-interface {v2, v0}, LW3/e;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Ljava/lang/Iterable;

    .line 23
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    move-result-object v0

    .line 27
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_22

    .line 33
    move-object v0, v1

    .line 34
    goto :goto_2

    .line 35
    :cond_22
    iput-object v0, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 37
    :cond_24
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    move-result-object v2

    .line 41
    const-string v3, "The iterator returned a null value"

    .line 43
    invoke-static {v2, v3}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 46
    move-result-object v2

    .line 47
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_36

    .line 53
    iput-object v1, p0, Lc4/k$a;->k:Ljava/util/Iterator;

    .line 55
    :cond_36
    return-object v2
.end method
