.class public final Lc4/i;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/i$a;,
        Lc4/i$b;
    }
.end annotation


# instance fields
.field public final c:LW3/e;

.field public final d:Z

.field public final e:I

.field public final f:I


# direct methods
.method public constructor <init>(LQ3/f;LW3/e;ZII)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/i;->c:LW3/e;

    .line 6
    iput-boolean p3, p0, Lc4/i;->d:Z

    .line 8
    iput p4, p0, Lc4/i;->e:I

    .line 10
    iput p5, p0, Lc4/i;->f:I

    .line 12
    return-void
.end method

.method public static K(Lz5/b;LW3/e;ZII)LQ3/i;
    .registers 12

    .line 1
    new-instance v6, Lc4/i$b;

    .line 3
    move-object v0, v6

    .line 4
    move-object v1, p0

    .line 5
    move-object v2, p1

    .line 6
    move v3, p2

    .line 7
    move v4, p3

    .line 8
    move v5, p4

    .line 9
    invoke-direct/range {v0 .. v5}, Lc4/i$b;-><init>(Lz5/b;LW3/e;ZII)V

    .line 12
    return-object v6
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    iget-object v1, p0, Lc4/i;->c:LW3/e;

    .line 5
    invoke-static {v0, p1, v1}, Lc4/x;->b(Lz5/a;Lz5/b;LW3/e;)Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    return-void

    .line 12
    :cond_b
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 14
    iget-object v1, p0, Lc4/i;->c:LW3/e;

    .line 16
    iget-boolean v2, p0, Lc4/i;->d:Z

    .line 18
    iget v3, p0, Lc4/i;->e:I

    .line 20
    iget v4, p0, Lc4/i;->f:I

    .line 22
    invoke-static {p1, v1, v2, v3, v4}, Lc4/i;->K(Lz5/b;LW3/e;ZII)LQ3/i;

    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {v0, p1}, LQ3/f;->H(LQ3/i;)V

    .line 29
    return-void
.end method
