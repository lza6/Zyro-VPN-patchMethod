.class public final Lc4/e;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/e$a;
    }
.end annotation


# instance fields
.field public final c:J

.field public final d:Ljava/lang/Object;

.field public final e:Z


# direct methods
.method public constructor <init>(LQ3/f;JLjava/lang/Object;Z)V
    .registers 6

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-wide p2, p0, Lc4/e;->c:J

    .line 6
    iput-object p4, p0, Lc4/e;->d:Ljava/lang/Object;

    .line 8
    iput-boolean p5, p0, Lc4/e;->e:Z

    .line 10
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    new-instance v7, Lc4/e$a;

    .line 5
    iget-wide v3, p0, Lc4/e;->c:J

    .line 7
    iget-object v5, p0, Lc4/e;->d:Ljava/lang/Object;

    .line 9
    iget-boolean v6, p0, Lc4/e;->e:Z

    .line 11
    move-object v1, v7

    .line 12
    move-object v2, p1

    .line 13
    invoke-direct/range {v1 .. v6}, Lc4/e$a;-><init>(Lz5/b;JLjava/lang/Object;Z)V

    .line 16
    invoke-virtual {v0, v7}, LQ3/f;->H(LQ3/i;)V

    .line 19
    return-void
.end method
