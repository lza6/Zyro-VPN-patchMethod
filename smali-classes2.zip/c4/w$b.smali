.class public final Lc4/w$b;
.super Ljava/util/concurrent/atomic/AtomicLong;
.source "SourceFile"

# interfaces
.implements Lz5/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/w;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Lz5/b;

.field public volatile b:Lc4/w$c;

.field public c:J


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/w$b;->a:Lz5/b;

    .line 6
    return-void
.end method


# virtual methods
.method public cancel()V
    .registers 5

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 4
    move-result-wide v0

    .line 5
    const-wide/high16 v2, -0x8000000000000000L

    .line 7
    cmp-long v0, v0, v2

    .line 9
    if-eqz v0, :cond_1c

    .line 11
    invoke-virtual {p0, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    .line 14
    move-result-wide v0

    .line 15
    cmp-long v0, v0, v2

    .line 17
    if-eqz v0, :cond_1c

    .line 19
    iget-object v0, p0, Lc4/w$b;->b:Lc4/w$c;

    .line 21
    if-eqz v0, :cond_1c

    .line 23
    invoke-virtual {v0, p0}, Lc4/w$c;->h(Lc4/w$b;)V

    .line 26
    invoke-virtual {v0}, Lc4/w$c;->g()V

    .line 29
    :cond_1c
    return-void
.end method

.method public f(J)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lj4/g;->h(J)Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_10

    .line 7
    invoke-static {p0, p1, p2}, Lk4/d;->b(Ljava/util/concurrent/atomic/AtomicLong;J)J

    .line 10
    iget-object p1, p0, Lc4/w$b;->b:Lc4/w$c;

    .line 12
    if-eqz p1, :cond_10

    .line 14
    invoke-virtual {p1}, Lc4/w$c;->g()V

    .line 17
    :cond_10
    return-void
.end method
