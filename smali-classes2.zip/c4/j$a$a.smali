.class public final Lc4/j$a$a;
.super Ljava/util/concurrent/atomic/AtomicReference;
.source "SourceFile"

# interfaces
.implements LQ3/l;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/j$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "a"
.end annotation


# instance fields
.field public final synthetic a:Lc4/j$a;


# direct methods
.method public constructor <init>(Lc4/j$a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lc4/j$a$a;->a:Lc4/j$a;

    .line 3
    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public a(LT3/b;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, LX3/b;->g(Ljava/util/concurrent/atomic/AtomicReference;LT3/b;)Z

    .line 4
    return-void
.end method

.method public d()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LT3/b;

    .line 7
    invoke-static {v0}, LX3/b;->b(LT3/b;)Z

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public dispose()V
    .registers 1

    .line 1
    invoke-static {p0}, LX3/b;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    .line 4
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/j$a$a;->a:Lc4/j$a;

    .line 3
    invoke-virtual {v0, p0}, Lc4/j$a;->i(Lc4/j$a$a;)V

    .line 6
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/j$a$a;->a:Lc4/j$a;

    .line 3
    invoke-virtual {v0, p0, p1}, Lc4/j$a;->j(Lc4/j$a$a;Ljava/lang/Throwable;)V

    .line 6
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/j$a$a;->a:Lc4/j$a;

    .line 3
    invoke-virtual {v0, p0, p1}, Lc4/j$a;->k(Lc4/j$a$a;Ljava/lang/Object;)V

    .line 6
    return-void
.end method
