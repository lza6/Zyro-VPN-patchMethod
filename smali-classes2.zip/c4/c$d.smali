.class public final Lc4/c$d;
.super Lc4/c$h;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# direct methods
.method public constructor <init>(Lz5/b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/c$h;-><init>(Lz5/b;)V

    .line 4
    return-void
.end method


# virtual methods
.method public j()V
    .registers 1

    .line 1
    return-void
.end method
