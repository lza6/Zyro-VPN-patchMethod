.class public final Lc4/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ3/i;
.implements LT3/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc4/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final a:LQ3/l;

.field public final b:J

.field public c:Lz5/c;

.field public d:J

.field public e:Z


# direct methods
.method public constructor <init>(LQ3/l;J)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc4/f$a;->a:LQ3/l;

    .line 6
    iput-wide p2, p0, Lc4/f$a;->b:J

    .line 8
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lc4/f$a;->e:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget-wide v0, p0, Lc4/f$a;->d:J

    .line 8
    iget-wide v2, p0, Lc4/f$a;->b:J

    .line 10
    cmp-long v2, v0, v2

    .line 12
    if-nez v2, :cond_1f

    .line 14
    const/4 v0, 0x1

    .line 15
    iput-boolean v0, p0, Lc4/f$a;->e:Z

    .line 17
    iget-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 19
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 22
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 24
    iput-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 26
    iget-object v0, p0, Lc4/f$a;->a:LQ3/l;

    .line 28
    invoke-interface {v0, p1}, LQ3/l;->onSuccess(Ljava/lang/Object;)V

    .line 31
    return-void

    .line 32
    :cond_1f
    const-wide/16 v2, 0x1

    .line 34
    add-long/2addr v0, v2

    .line 35
    iput-wide v0, p0, Lc4/f$a;->d:J

    .line 37
    return-void
.end method

.method public c(Lz5/c;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 3
    invoke-static {v0, p1}, Lj4/g;->i(Lz5/c;Lz5/c;)Z

    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_17

    .line 9
    iput-object p1, p0, Lc4/f$a;->c:Lz5/c;

    .line 11
    iget-object v0, p0, Lc4/f$a;->a:LQ3/l;

    .line 13
    invoke-interface {v0, p0}, LQ3/l;->a(LT3/b;)V

    .line 16
    const-wide v0, 0x7fffffffffffffffL

    .line 21
    invoke-interface {p1, v0, v1}, Lz5/c;->f(J)V

    .line 24
    :cond_17
    return-void
.end method

.method public d()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 3
    sget-object v1, Lj4/g;->a:Lj4/g;

    .line 5
    if-ne v0, v1, :cond_8

    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    return v0
.end method

.method public dispose()V
    .registers 2

    .line 1
    iget-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 3
    invoke-interface {v0}, Lz5/c;->cancel()V

    .line 6
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 8
    iput-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 10
    return-void
.end method

.method public onComplete()V
    .registers 2

    .line 1
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 3
    iput-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 5
    iget-boolean v0, p0, Lc4/f$a;->e:Z

    .line 7
    if-nez v0, :cond_10

    .line 9
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Lc4/f$a;->e:Z

    .line 12
    iget-object v0, p0, Lc4/f$a;->a:LQ3/l;

    .line 14
    invoke-interface {v0}, LQ3/l;->onComplete()V

    .line 17
    :cond_10
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lc4/f$a;->e:Z

    .line 3
    if-eqz v0, :cond_8

    .line 5
    invoke-static {p1}, Ll4/a;->q(Ljava/lang/Throwable;)V

    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Lc4/f$a;->e:Z

    .line 12
    sget-object v0, Lj4/g;->a:Lj4/g;

    .line 14
    iput-object v0, p0, Lc4/f$a;->c:Lz5/c;

    .line 16
    iget-object v0, p0, Lc4/f$a;->a:LQ3/l;

    .line 18
    invoke-interface {v0, p1}, LQ3/l;->onError(Ljava/lang/Throwable;)V

    .line 21
    return-void
.end method
