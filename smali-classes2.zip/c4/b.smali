.class public final Lc4/b;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/b$e;,
        Lc4/b$f;,
        Lc4/b$c;,
        Lc4/b$g;,
        Lc4/b$d;,
        Lc4/b$b;
    }
.end annotation


# instance fields
.field public final c:LW3/e;

.field public final d:I

.field public final e:Lk4/f;


# direct methods
.method public constructor <init>(LQ3/f;LW3/e;ILk4/f;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    iput-object p2, p0, Lc4/b;->c:LW3/e;

    .line 6
    iput p3, p0, Lc4/b;->d:I

    .line 8
    iput-object p4, p0, Lc4/b;->e:Lk4/f;

    .line 10
    return-void
.end method

.method public static K(Lz5/b;LW3/e;ILk4/f;)Lz5/b;
    .registers 6

    .line 1
    sget-object v0, Lc4/b$a;->a:[I

    .line 3
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 6
    move-result p3

    .line 7
    aget p3, v0, p3

    .line 9
    const/4 v0, 0x1

    .line 10
    if-eq p3, v0, :cond_1a

    .line 12
    const/4 v1, 0x2

    .line 13
    if-eq p3, v1, :cond_14

    .line 15
    new-instance p3, Lc4/b$d;

    .line 17
    invoke-direct {p3, p0, p1, p2}, Lc4/b$d;-><init>(Lz5/b;LW3/e;I)V

    .line 20
    return-object p3

    .line 21
    :cond_14
    new-instance p3, Lc4/b$c;

    .line 23
    invoke-direct {p3, p0, p1, p2, v0}, Lc4/b$c;-><init>(Lz5/b;LW3/e;IZ)V

    .line 26
    return-object p3

    .line 27
    :cond_1a
    new-instance p3, Lc4/b$c;

    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-direct {p3, p0, p1, p2, v0}, Lc4/b$c;-><init>(Lz5/b;LW3/e;IZ)V

    .line 33
    return-object p3
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    iget-object v1, p0, Lc4/b;->c:LW3/e;

    .line 5
    invoke-static {v0, p1, v1}, Lc4/x;->b(Lz5/a;Lz5/b;LW3/e;)Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 11
    return-void

    .line 12
    :cond_b
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 14
    iget-object v1, p0, Lc4/b;->c:LW3/e;

    .line 16
    iget v2, p0, Lc4/b;->d:I

    .line 18
    iget-object v3, p0, Lc4/b;->e:Lk4/f;

    .line 20
    invoke-static {p1, v1, v2, v3}, Lc4/b;->K(Lz5/b;LW3/e;ILk4/f;)Lz5/b;

    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {v0, p1}, LQ3/f;->a(Lz5/b;)V

    .line 27
    return-void
.end method
