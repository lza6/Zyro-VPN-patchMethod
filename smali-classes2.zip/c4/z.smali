.class public final Lc4/z;
.super LQ3/s;
.source "SourceFile"

# interfaces
.implements LZ3/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/z$a;
    }
.end annotation


# instance fields
.field public final a:LQ3/f;

.field public final b:Ljava/util/concurrent/Callable;


# direct methods
.method public constructor <init>(LQ3/f;)V
    .registers 3

    .line 1
    invoke-static {}, Lk4/b;->b()Ljava/util/concurrent/Callable;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lc4/z;-><init>(LQ3/f;Ljava/util/concurrent/Callable;)V

    return-void
.end method

.method public constructor <init>(LQ3/f;Ljava/util/concurrent/Callable;)V
    .registers 3

    .line 2
    invoke-direct {p0}, LQ3/s;-><init>()V

    .line 3
    iput-object p1, p0, Lc4/z;->a:LQ3/f;

    .line 4
    iput-object p2, p0, Lc4/z;->b:Ljava/util/concurrent/Callable;

    return-void
.end method


# virtual methods
.method public d()LQ3/f;
    .registers 4

    .line 1
    new-instance v0, Lc4/y;

    .line 3
    iget-object v1, p0, Lc4/z;->a:LQ3/f;

    .line 5
    iget-object v2, p0, Lc4/z;->b:Ljava/util/concurrent/Callable;

    .line 7
    invoke-direct {v0, v1, v2}, Lc4/y;-><init>(LQ3/f;Ljava/util/concurrent/Callable;)V

    .line 10
    invoke-static {v0}, Ll4/a;->k(LQ3/f;)LQ3/f;

    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public k(LQ3/t;)V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lc4/z;->b:Ljava/util/concurrent/Callable;

    .line 3
    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    const-string v1, "The collectionSupplier returned a null collection. Null values are generally not allowed in 2.x operators and sources."

    .line 9
    invoke-static {v0, v1}, LY3/b;->d(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Ljava/util/Collection;
    :try_end_e
    .catchall {:try_start_0 .. :try_end_e} :catchall_19

    .line 15
    iget-object v1, p0, Lc4/z;->a:LQ3/f;

    .line 17
    new-instance v2, Lc4/z$a;

    .line 19
    invoke-direct {v2, p1, v0}, Lc4/z$a;-><init>(LQ3/t;Ljava/util/Collection;)V

    .line 22
    invoke-virtual {v1, v2}, LQ3/f;->H(LQ3/i;)V

    .line 25
    return-void

    .line 26
    :catchall_19
    move-exception v0

    .line 27
    invoke-static {v0}, LU3/b;->b(Ljava/lang/Throwable;)V

    .line 30
    invoke-static {v0, p1}, LX3/c;->i(Ljava/lang/Throwable;LQ3/t;)V

    .line 33
    return-void
.end method
