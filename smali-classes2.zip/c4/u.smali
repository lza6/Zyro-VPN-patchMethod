.class public final Lc4/u;
.super Lc4/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lc4/u$a;
    }
.end annotation


# direct methods
.method public constructor <init>(LQ3/f;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lc4/a;-><init>(LQ3/f;)V

    .line 4
    return-void
.end method


# virtual methods
.method public I(Lz5/b;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc4/a;->b:LQ3/f;

    .line 3
    new-instance v1, Lc4/u$a;

    .line 5
    invoke-direct {v1, p1}, Lc4/u$a;-><init>(Lz5/b;)V

    .line 8
    invoke-virtual {v0, v1}, LQ3/f;->H(LQ3/i;)V

    .line 11
    return-void
.end method
