.class public final LB2/k;
.super LB2/g;
.source "SourceFile"


# instance fields
.field public final synthetic b:LB2/q;


# direct methods
.method public constructor <init>(LB2/q;)V
    .registers 2

    .line 1
    iput-object p1, p0, LB2/k;->b:LB2/q;

    .line 3
    invoke-direct {p0}, LB2/g;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 6

    .line 1
    iget-object v0, p0, LB2/k;->b:LB2/q;

    .line 3
    invoke-static {v0}, LB2/q;->g(LB2/q;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 10
    invoke-static {v1}, LB2/q;->i(LB2/q;)Ljava/util/concurrent/atomic/AtomicInteger;

    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 17
    move-result v1

    .line 18
    const/4 v2, 0x0

    .line 19
    if-lez v1, :cond_31

    .line 21
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 23
    invoke-static {v1}, LB2/q;->i(LB2/q;)Ljava/util/concurrent/atomic/AtomicInteger;

    .line 26
    move-result-object v1

    .line 27
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 30
    move-result v1

    .line 31
    if-lez v1, :cond_31

    .line 33
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 35
    invoke-static {v1}, LB2/q;->f(LB2/q;)LB2/f;

    .line 38
    move-result-object v1

    .line 39
    const-string v3, "Leaving the connection open for other ongoing calls."

    .line 41
    new-array v2, v2, [Ljava/lang/Object;

    .line 43
    invoke-virtual {v1, v3, v2}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 46
    monitor-exit v0

    .line 47
    return-void

    .line 48
    :catchall_2f
    move-exception v1

    .line 49
    goto :goto_68

    .line 50
    :cond_31
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 52
    invoke-static {v1}, LB2/q;->d(LB2/q;)Landroid/os/IInterface;

    .line 55
    move-result-object v3

    .line 56
    if-eqz v3, :cond_61

    .line 58
    invoke-static {v1}, LB2/q;->f(LB2/q;)LB2/f;

    .line 61
    move-result-object v1

    .line 62
    const-string v3, "Unbind from service."

    .line 64
    new-array v4, v2, [Ljava/lang/Object;

    .line 66
    invoke-virtual {v1, v3, v4}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 69
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 71
    invoke-static {v1}, LB2/q;->a(LB2/q;)Landroid/content/Context;

    .line 74
    move-result-object v3

    .line 75
    invoke-static {v1}, LB2/q;->b(LB2/q;)Landroid/content/ServiceConnection;

    .line 78
    move-result-object v1

    .line 79
    invoke-virtual {v3, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    .line 82
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 84
    invoke-static {v1, v2}, LB2/q;->l(LB2/q;Z)V

    .line 87
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 89
    const/4 v2, 0x0

    .line 90
    invoke-static {v1, v2}, LB2/q;->m(LB2/q;Landroid/os/IInterface;)V

    .line 93
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 95
    invoke-static {v1, v2}, LB2/q;->k(LB2/q;Landroid/content/ServiceConnection;)V

    .line 98
    :cond_61
    iget-object v1, p0, LB2/k;->b:LB2/q;

    .line 100
    invoke-static {v1}, LB2/q;->o(LB2/q;)V

    .line 103
    monitor-exit v0

    .line 104
    return-void

    .line 105
    :goto_68
    monitor-exit v0
    :try_end_69
    .catchall {:try_start_7 .. :try_end_69} :catchall_2f

    .line 106
    throw v1
.end method
