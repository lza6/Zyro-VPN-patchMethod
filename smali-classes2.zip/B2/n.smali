.class public final LB2/n;
.super LB2/g;
.source "SourceFile"


# instance fields
.field public final synthetic b:LB2/o;


# direct methods
.method public constructor <init>(LB2/o;)V
    .registers 2

    .line 1
    iput-object p1, p0, LB2/n;->b:LB2/o;

    .line 3
    invoke-direct {p0}, LB2/g;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    .line 1
    iget-object v0, p0, LB2/n;->b:LB2/o;

    .line 3
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 5
    invoke-static {v0}, LB2/q;->r(LB2/q;)V

    .line 8
    iget-object v0, p0, LB2/n;->b:LB2/o;

    .line 10
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-static {v0, v1}, LB2/q;->m(LB2/q;Landroid/os/IInterface;)V

    .line 16
    iget-object v0, p0, LB2/n;->b:LB2/o;

    .line 18
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-static {v0, v1}, LB2/q;->l(LB2/q;Z)V

    .line 24
    return-void
.end method
