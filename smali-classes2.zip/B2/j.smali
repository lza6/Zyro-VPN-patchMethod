.class public final LB2/j;
.super LB2/g;
.source "SourceFile"


# instance fields
.field public final synthetic b:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field public final synthetic c:LB2/g;

.field public final synthetic d:LB2/q;


# direct methods
.method public constructor <init>(LB2/q;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/tasks/TaskCompletionSource;LB2/g;)V
    .registers 5

    .line 1
    iput-object p3, p0, LB2/j;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 3
    iput-object p4, p0, LB2/j;->c:LB2/g;

    .line 5
    iput-object p1, p0, LB2/j;->d:LB2/q;

    .line 7
    invoke-direct {p0, p2}, LB2/g;-><init>(Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 10
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    .line 1
    iget-object v0, p0, LB2/j;->d:LB2/q;

    .line 3
    invoke-static {v0}, LB2/q;->g(LB2/q;)Ljava/lang/Object;

    .line 6
    move-result-object v0

    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    iget-object v1, p0, LB2/j;->d:LB2/q;

    .line 10
    iget-object v2, p0, LB2/j;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    .line 12
    invoke-static {v1, v2}, LB2/q;->n(LB2/q;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    .line 15
    iget-object v1, p0, LB2/j;->d:LB2/q;

    .line 17
    invoke-static {v1}, LB2/q;->i(LB2/q;)Ljava/util/concurrent/atomic/AtomicInteger;

    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 24
    move-result v1

    .line 25
    if-lez v1, :cond_2b

    .line 27
    iget-object v1, p0, LB2/j;->d:LB2/q;

    .line 29
    invoke-static {v1}, LB2/q;->f(LB2/q;)LB2/f;

    .line 32
    move-result-object v1

    .line 33
    const-string v2, "Already connected to the service."

    .line 35
    const/4 v3, 0x0

    .line 36
    new-array v3, v3, [Ljava/lang/Object;

    .line 38
    invoke-virtual {v1, v2, v3}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 41
    goto :goto_2b

    .line 42
    :catchall_29
    move-exception v1

    .line 43
    goto :goto_34

    .line 44
    :cond_2b
    :goto_2b
    iget-object v1, p0, LB2/j;->d:LB2/q;

    .line 46
    iget-object v2, p0, LB2/j;->c:LB2/g;

    .line 48
    invoke-static {v1, v2}, LB2/q;->p(LB2/q;LB2/g;)V

    .line 51
    monitor-exit v0

    .line 52
    return-void

    .line 53
    :goto_34
    monitor-exit v0
    :try_end_35
    .catchall {:try_start_7 .. :try_end_35} :catchall_29

    .line 54
    throw v1
.end method
