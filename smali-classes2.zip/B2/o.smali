.class public final LB2/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final synthetic a:LB2/q;


# direct methods
.method public synthetic constructor <init>(LB2/q;LB2/p;)V
    .registers 3

    .line 1
    iput-object p1, p0, LB2/o;->a:LB2/q;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .registers 5

    .line 1
    iget-object v0, p0, LB2/o;->a:LB2/q;

    .line 3
    invoke-static {v0}, LB2/q;->f(LB2/q;)LB2/f;

    .line 6
    move-result-object v0

    .line 7
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 10
    move-result-object p1

    .line 11
    const-string v1, "ServiceConnectionImpl.onServiceConnected(%s)"

    .line 13
    invoke-virtual {v0, v1, p1}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 16
    new-instance p1, LB2/m;

    .line 18
    invoke-direct {p1, p0, p2}, LB2/m;-><init>(LB2/o;Landroid/os/IBinder;)V

    .line 21
    iget-object p2, p0, LB2/o;->a:LB2/q;

    .line 23
    invoke-virtual {p2}, LB2/q;->c()Landroid/os/Handler;

    .line 26
    move-result-object p2

    .line 27
    invoke-virtual {p2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 30
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 4

    .line 1
    iget-object v0, p0, LB2/o;->a:LB2/q;

    .line 3
    invoke-static {v0}, LB2/q;->f(LB2/q;)LB2/f;

    .line 6
    move-result-object v0

    .line 7
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 10
    move-result-object p1

    .line 11
    const-string v1, "ServiceConnectionImpl.onServiceDisconnected(%s)"

    .line 13
    invoke-virtual {v0, v1, p1}, LB2/f;->c(Ljava/lang/String;[Ljava/lang/Object;)I

    .line 16
    new-instance p1, LB2/n;

    .line 18
    invoke-direct {p1, p0}, LB2/n;-><init>(LB2/o;)V

    .line 21
    iget-object v0, p0, LB2/o;->a:LB2/q;

    .line 23
    invoke-virtual {v0}, LB2/q;->c()Landroid/os/Handler;

    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 30
    return-void
.end method
