.class public final synthetic LB2/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# instance fields
.field public final synthetic a:LB2/q;


# direct methods
.method public synthetic constructor <init>(LB2/q;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, LB2/h;->a:LB2/q;

    .line 6
    return-void
.end method


# virtual methods
.method public final binderDied()V
    .registers 2

    .line 1
    iget-object v0, p0, LB2/h;->a:LB2/q;

    .line 3
    invoke-static {v0}, LB2/q;->j(LB2/q;)V

    .line 6
    return-void
.end method
