.class public final LB2/c;
.super LB2/a;
.source "SourceFile"

# interfaces
.implements LB2/d;


# direct methods
.method public constructor <init>(Landroid/os/IBinder;)V
    .registers 3

    .line 1
    const-string v0, "com.google.android.play.core.inappreview.protocol.IInAppReviewService"

    .line 3
    invoke-direct {p0, p1, v0}, LB2/a;-><init>(Landroid/os/IBinder;Ljava/lang/String;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/String;Landroid/os/Bundle;LB2/e;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, LB2/a;->f1()Landroid/os/Parcel;

    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 8
    sget p1, LB2/b;->a:I

    .line 10
    const/4 p1, 0x1

    .line 11
    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 14
    const/4 p1, 0x0

    .line 15
    invoke-interface {p2, v0, p1}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    .line 18
    invoke-virtual {v0, p3}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    .line 21
    const/4 p1, 0x2

    .line 22
    invoke-virtual {p0, p1, v0}, LB2/a;->g1(ILandroid/os/Parcel;)V

    .line 25
    return-void
.end method
