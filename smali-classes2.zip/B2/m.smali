.class public final LB2/m;
.super LB2/g;
.source "SourceFile"


# instance fields
.field public final synthetic b:Landroid/os/IBinder;

.field public final synthetic c:LB2/o;


# direct methods
.method public constructor <init>(LB2/o;Landroid/os/IBinder;)V
    .registers 3

    .line 1
    iput-object p2, p0, LB2/m;->b:Landroid/os/IBinder;

    .line 3
    iput-object p1, p0, LB2/m;->c:LB2/o;

    .line 5
    invoke-direct {p0}, LB2/g;-><init>()V

    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    .line 1
    iget-object v0, p0, LB2/m;->b:Landroid/os/IBinder;

    .line 3
    invoke-static {v0}, Lcom/google/android/play/core/review/internal/zze;->zzb(Landroid/os/IBinder;)LB2/d;

    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, LB2/m;->c:LB2/o;

    .line 9
    iget-object v1, v1, LB2/o;->a:LB2/q;

    .line 11
    invoke-static {v1, v0}, LB2/q;->m(LB2/q;Landroid/os/IInterface;)V

    .line 14
    iget-object v0, p0, LB2/m;->c:LB2/o;

    .line 16
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 18
    invoke-static {v0}, LB2/q;->q(LB2/q;)V

    .line 21
    iget-object v0, p0, LB2/m;->c:LB2/o;

    .line 23
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 25
    const/4 v1, 0x0

    .line 26
    invoke-static {v0, v1}, LB2/q;->l(LB2/q;Z)V

    .line 29
    iget-object v0, p0, LB2/m;->c:LB2/o;

    .line 31
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 33
    invoke-static {v0}, LB2/q;->h(LB2/q;)Ljava/util/List;

    .line 36
    move-result-object v0

    .line 37
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 40
    move-result-object v0

    .line 41
    :goto_28
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_38

    .line 47
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Ljava/lang/Runnable;

    .line 53
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 56
    goto :goto_28

    .line 57
    :cond_38
    iget-object v0, p0, LB2/m;->c:LB2/o;

    .line 59
    iget-object v0, v0, LB2/o;->a:LB2/q;

    .line 61
    invoke-static {v0}, LB2/q;->h(LB2/q;)Ljava/util/List;

    .line 64
    move-result-object v0

    .line 65
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 68
    return-void
.end method
