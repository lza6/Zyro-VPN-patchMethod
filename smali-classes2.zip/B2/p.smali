.class public abstract synthetic LB2/p;
.super Ljava/lang/Object;
.source "SourceFile"
