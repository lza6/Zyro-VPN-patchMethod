.class public interface abstract LB2/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract zzb(Landroid/os/Bundle;)V
.end method
