.class public interface abstract LB2/l;
.super Ljava/lang/Object;
.source "SourceFile"
