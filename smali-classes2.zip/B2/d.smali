.class public interface abstract LB2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract A(Ljava/lang/String;Landroid/os/Bundle;LB2/e;)V
.end method
