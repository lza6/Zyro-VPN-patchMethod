.class public La3/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/flutter/embedding/engine/plugins/FlutterPlugin;
.implements Lio/flutter/plugin/common/MethodChannel$MethodCallHandler;
.implements Lio/flutter/plugin/common/EventChannel$StreamHandler;
.implements Lio/flutter/embedding/engine/plugins/activity/ActivityAware;
.implements Lio/flutter/plugin/common/PluginRegistry$NewIntentListener;


# instance fields
.field public a:Lio/flutter/plugin/common/MethodChannel;

.field public b:Lio/flutter/plugin/common/EventChannel;

.field public c:Lio/flutter/plugin/common/EventChannel$EventSink;

.field public d:Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;

.field public e:Ljava/lang/String;

.field public f:Z

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La3/b;->f:Z

    .line 7
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Intent;)Z
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_4

    .line 4
    return v0

    .line 5
    :cond_4
    const-string v1, "com.llfbandit.app_links"

    .line 7
    invoke-virtual {p1}, Landroid/content/Intent;->toString()Ljava/lang/String;

    .line 10
    move-result-object v2

    .line 11
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    invoke-virtual {p1}, Landroid/content/Intent;->getFlags()I

    .line 17
    move-result v1

    .line 18
    const/high16 v2, 0x100000

    .line 20
    and-int/2addr v1, v2

    .line 21
    if-ne v1, v2, :cond_17

    .line 23
    return v0

    .line 24
    :cond_17
    invoke-static {p1}, La3/a;->a(Landroid/content/Intent;)Ljava/lang/String;

    .line 27
    move-result-object p1

    .line 28
    if-nez p1, :cond_1e

    .line 30
    return v0

    .line 31
    :cond_1e
    iget-object v0, p0, La3/b;->e:Ljava/lang/String;

    .line 33
    if-nez v0, :cond_24

    .line 35
    iput-object p1, p0, La3/b;->e:Ljava/lang/String;

    .line 37
    :cond_24
    iput-object p1, p0, La3/b;->g:Ljava/lang/String;

    .line 39
    iget-object v0, p0, La3/b;->c:Lio/flutter/plugin/common/EventChannel$EventSink;

    .line 41
    const/4 v1, 0x1

    .line 42
    if-eqz v0, :cond_30

    .line 44
    iput-boolean v1, p0, La3/b;->f:Z

    .line 46
    invoke-interface {v0, p1}, Lio/flutter/plugin/common/EventChannel$EventSink;->success(Ljava/lang/Object;)V

    .line 49
    :cond_30
    return v1
.end method

.method public onAttachedToActivity(Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;)V
    .registers 2

    .line 1
    iput-object p1, p0, La3/b;->d:Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;

    .line 3
    invoke-interface {p1, p0}, Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;->addOnNewIntentListener(Lio/flutter/plugin/common/PluginRegistry$NewIntentListener;)V

    .line 6
    invoke-interface {p1}, Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;->getActivity()Landroid/app/Activity;

    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p0, p1}, La3/b;->a(Landroid/content/Intent;)Z

    .line 17
    return-void
.end method

.method public onAttachedToEngine(Lio/flutter/embedding/engine/plugins/FlutterPlugin$FlutterPluginBinding;)V
    .registers 5

    .line 1
    new-instance v0, Lio/flutter/plugin/common/MethodChannel;

    .line 3
    invoke-virtual {p1}, Lio/flutter/embedding/engine/plugins/FlutterPlugin$FlutterPluginBinding;->getBinaryMessenger()Lio/flutter/plugin/common/BinaryMessenger;

    .line 6
    move-result-object v1

    .line 7
    const-string v2, "com.llfbandit.app_links/messages"

    .line 9
    invoke-direct {v0, v1, v2}, Lio/flutter/plugin/common/MethodChannel;-><init>(Lio/flutter/plugin/common/BinaryMessenger;Ljava/lang/String;)V

    .line 12
    iput-object v0, p0, La3/b;->a:Lio/flutter/plugin/common/MethodChannel;

    .line 14
    invoke-virtual {v0, p0}, Lio/flutter/plugin/common/MethodChannel;->setMethodCallHandler(Lio/flutter/plugin/common/MethodChannel$MethodCallHandler;)V

    .line 17
    new-instance v0, Lio/flutter/plugin/common/EventChannel;

    .line 19
    invoke-virtual {p1}, Lio/flutter/embedding/engine/plugins/FlutterPlugin$FlutterPluginBinding;->getBinaryMessenger()Lio/flutter/plugin/common/BinaryMessenger;

    .line 22
    move-result-object p1

    .line 23
    const-string v1, "com.llfbandit.app_links/events"

    .line 25
    invoke-direct {v0, p1, v1}, Lio/flutter/plugin/common/EventChannel;-><init>(Lio/flutter/plugin/common/BinaryMessenger;Ljava/lang/String;)V

    .line 28
    iput-object v0, p0, La3/b;->b:Lio/flutter/plugin/common/EventChannel;

    .line 30
    invoke-virtual {v0, p0}, Lio/flutter/plugin/common/EventChannel;->setStreamHandler(Lio/flutter/plugin/common/EventChannel$StreamHandler;)V

    .line 33
    return-void
.end method

.method public onCancel(Ljava/lang/Object;)V
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, La3/b;->c:Lio/flutter/plugin/common/EventChannel$EventSink;

    .line 4
    return-void
.end method

.method public onDetachedFromActivity()V
    .registers 2

    .line 1
    iget-object v0, p0, La3/b;->d:Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;

    .line 3
    if-eqz v0, :cond_7

    .line 5
    invoke-interface {v0, p0}, Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;->removeOnNewIntentListener(Lio/flutter/plugin/common/PluginRegistry$NewIntentListener;)V

    .line 8
    :cond_7
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, La3/b;->d:Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;

    .line 11
    return-void
.end method

.method public onDetachedFromActivityForConfigChanges()V
    .registers 1

    .line 1
    invoke-virtual {p0}, La3/b;->onDetachedFromActivity()V

    .line 4
    return-void
.end method

.method public onDetachedFromEngine(Lio/flutter/embedding/engine/plugins/FlutterPlugin$FlutterPluginBinding;)V
    .registers 3

    .line 1
    iget-object p1, p0, La3/b;->a:Lio/flutter/plugin/common/MethodChannel;

    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodChannel;->setMethodCallHandler(Lio/flutter/plugin/common/MethodChannel$MethodCallHandler;)V

    .line 7
    iget-object p1, p0, La3/b;->b:Lio/flutter/plugin/common/EventChannel;

    .line 9
    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/EventChannel;->setStreamHandler(Lio/flutter/plugin/common/EventChannel$StreamHandler;)V

    .line 12
    return-void
.end method

.method public onListen(Ljava/lang/Object;Lio/flutter/plugin/common/EventChannel$EventSink;)V
    .registers 4

    .line 1
    iput-object p2, p0, La3/b;->c:Lio/flutter/plugin/common/EventChannel$EventSink;

    .line 3
    iget-boolean p1, p0, La3/b;->f:Z

    .line 5
    if-nez p1, :cond_10

    .line 7
    iget-object p1, p0, La3/b;->e:Ljava/lang/String;

    .line 9
    if-eqz p1, :cond_10

    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, La3/b;->f:Z

    .line 14
    invoke-interface {p2, p1}, Lio/flutter/plugin/common/EventChannel$EventSink;->success(Ljava/lang/Object;)V

    .line 17
    :cond_10
    return-void
.end method

.method public onMethodCall(Lio/flutter/plugin/common/MethodCall;Lio/flutter/plugin/common/MethodChannel$Result;)V
    .registers 5

    .line 1
    iget-object v0, p1, Lio/flutter/plugin/common/MethodCall;->method:Ljava/lang/String;

    .line 3
    const-string v1, "getLatestLink"

    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_10

    .line 11
    iget-object p1, p0, La3/b;->g:Ljava/lang/String;

    .line 13
    invoke-interface {p2, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    .line 16
    goto :goto_23

    .line 17
    :cond_10
    iget-object p1, p1, Lio/flutter/plugin/common/MethodCall;->method:Ljava/lang/String;

    .line 19
    const-string v0, "getInitialLink"

    .line 21
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_20

    .line 27
    iget-object p1, p0, La3/b;->e:Ljava/lang/String;

    .line 29
    invoke-interface {p2, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    .line 32
    goto :goto_23

    .line 33
    :cond_20
    invoke-interface {p2}, Lio/flutter/plugin/common/MethodChannel$Result;->notImplemented()V

    .line 36
    :goto_23
    return-void
.end method

.method public onNewIntent(Landroid/content/Intent;)Z
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, La3/b;->a(Landroid/content/Intent;)Z

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public onReattachedToActivityForConfigChanges(Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;)V
    .registers 2

    .line 1
    iput-object p1, p0, La3/b;->d:Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;

    .line 3
    invoke-interface {p1, p0}, Lio/flutter/embedding/engine/plugins/activity/ActivityPluginBinding;->addOnNewIntentListener(Lio/flutter/plugin/common/PluginRegistry$NewIntentListener;)V

    .line 6
    return-void
.end method
