.class public Lb3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lb3/b;->b:Z

    .line 7
    iput-object p1, p0, Lb3/b;->a:Landroid/content/Context;

    .line 9
    return-void
.end method


# virtual methods
.method public a()Z
    .registers 2

    .line 1
    new-instance v0, Lcom/scottyab/rootbeer/RootBeerNative;

    .line 3
    invoke-direct {v0}, Lcom/scottyab/rootbeer/RootBeerNative;-><init>()V

    .line 6
    invoke-virtual {v0}, Lcom/scottyab/rootbeer/RootBeerNative;->a()Z

    .line 9
    move-result v0

    .line 10
    return v0
.end method

.method public b(Ljava/lang/String;)Z
    .registers 9

    .line 1
    invoke-static {}, Lb3/a;->a()[Ljava/lang/String;

    .line 4
    move-result-object v0

    .line 5
    array-length v1, v0

    .line 6
    const/4 v2, 0x0

    .line 7
    move v3, v2

    .line 8
    :goto_7
    if-ge v2, v1, :cond_3d

    .line 10
    aget-object v4, v0, v2

    .line 12
    new-instance v5, Ljava/lang/StringBuilder;

    .line 14
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 17
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    move-result-object v5

    .line 27
    new-instance v6, Ljava/io/File;

    .line 29
    invoke-direct {v6, v4, p1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    .line 35
    move-result v4

    .line 36
    if-eqz v4, :cond_3a

    .line 38
    new-instance v3, Ljava/lang/StringBuilder;

    .line 40
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 43
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    const-string v4, " binary detected!"

    .line 48
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    move-result-object v3

    .line 55
    invoke-static {v3}, Lc3/a;->f(Ljava/lang/Object;)V

    .line 58
    const/4 v3, 0x1

    .line 59
    :cond_3a
    add-int/lit8 v2, v2, 0x1

    .line 61
    goto :goto_7

    .line 62
    :cond_3d
    return v3
.end method

.method public c()Z
    .registers 12

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 6
    const-string v1, "ro.debuggable"

    .line 8
    const-string v2, "1"

    .line 10
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    const-string v1, "ro.secure"

    .line 15
    const-string v2, "0"

    .line 17
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    invoke-virtual {p0}, Lb3/b;->q()[Ljava/lang/String;

    .line 23
    move-result-object v1

    .line 24
    const/4 v2, 0x0

    .line 25
    if-nez v1, :cond_1b

    .line 27
    return v2

    .line 28
    :cond_1b
    array-length v3, v1

    .line 29
    move v4, v2

    .line 30
    :goto_1d
    if-ge v2, v3, :cond_7e

    .line 32
    aget-object v5, v1, v2

    .line 34
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 37
    move-result-object v6

    .line 38
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 41
    move-result-object v6

    .line 42
    :cond_29
    :goto_29
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    move-result v7

    .line 46
    if-eqz v7, :cond_7b

    .line 48
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    move-result-object v7

    .line 52
    check-cast v7, Ljava/lang/String;

    .line 54
    invoke-virtual {v5, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 57
    move-result v8

    .line 58
    if-eqz v8, :cond_29

    .line 60
    invoke-interface {v0, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    move-result-object v8

    .line 64
    check-cast v8, Ljava/lang/String;

    .line 66
    new-instance v9, Ljava/lang/StringBuilder;

    .line 68
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 71
    const-string v10, "["

    .line 73
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    const-string v8, "]"

    .line 81
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    move-result-object v8

    .line 88
    invoke-virtual {v5, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 91
    move-result v9

    .line 92
    if-eqz v9, :cond_29

    .line 94
    new-instance v4, Ljava/lang/StringBuilder;

    .line 96
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 99
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    const-string v7, " = "

    .line 104
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    const-string v7, " detected!"

    .line 112
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    move-result-object v4

    .line 119
    invoke-static {v4}, Lc3/a;->f(Ljava/lang/Object;)V

    .line 122
    const/4 v4, 0x1

    .line 123
    goto :goto_29

    .line 124
    :cond_7b
    add-int/lit8 v2, v2, 0x1

    .line 126
    goto :goto_1d

    .line 127
    :cond_7e
    return v4
.end method

.method public d()Z
    .registers 2

    .line 1
    const-string v0, "magisk"

    .line 3
    invoke-virtual {p0, v0}, Lb3/b;->b(Ljava/lang/String;)Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public e()Z
    .registers 17

    .line 1
    invoke-virtual/range {p0 .. p0}, Lb3/b;->p()[Ljava/lang/String;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_8

    .line 8
    return v1

    .line 9
    :cond_8
    array-length v2, v0

    .line 10
    move v3, v1

    .line 11
    move v4, v3

    .line 12
    :goto_b
    if-ge v3, v2, :cond_8a

    .line 14
    aget-object v5, v0, v3

    .line 16
    const-string v6, " "

    .line 18
    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 21
    move-result-object v6

    .line 22
    array-length v7, v6

    .line 23
    const/4 v8, 0x6

    .line 24
    if-ge v7, v8, :cond_2e

    .line 26
    new-instance v6, Ljava/lang/StringBuilder;

    .line 28
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 31
    const-string v7, "Error formatting mount line: "

    .line 33
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    move-result-object v5

    .line 43
    invoke-static {v5}, Lc3/a;->b(Ljava/lang/Object;)V

    .line 46
    goto :goto_86

    .line 47
    :cond_2e
    const/4 v7, 0x2

    .line 48
    aget-object v7, v6, v7

    .line 50
    const/4 v8, 0x5

    .line 51
    aget-object v6, v6, v8

    .line 53
    sget-object v8, Lb3/a;->e:[Ljava/lang/String;

    .line 55
    array-length v9, v8

    .line 56
    move v10, v1

    .line 57
    :goto_38
    if-ge v10, v9, :cond_86

    .line 59
    aget-object v11, v8, v10

    .line 61
    invoke-virtual {v7, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 64
    move-result v12

    .line 65
    if-eqz v12, :cond_82

    .line 67
    const-string v12, "("

    .line 69
    const-string v13, ""

    .line 71
    invoke-virtual {v6, v12, v13}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 74
    move-result-object v6

    .line 75
    const-string v12, ")"

    .line 77
    invoke-virtual {v6, v12, v13}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 80
    move-result-object v6

    .line 81
    const-string v12, ","

    .line 83
    invoke-virtual {v6, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 86
    move-result-object v12

    .line 87
    array-length v13, v12

    .line 88
    move v14, v1

    .line 89
    :goto_58
    if-ge v14, v13, :cond_82

    .line 91
    aget-object v15, v12, v14

    .line 93
    const-string v1, "rw"

    .line 95
    invoke-virtual {v15, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 98
    move-result v1

    .line 99
    if-eqz v1, :cond_7e

    .line 101
    new-instance v1, Ljava/lang/StringBuilder;

    .line 103
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 106
    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    const-string v4, " path is mounted with rw permissions! "

    .line 111
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 120
    move-result-object v1

    .line 121
    invoke-static {v1}, Lc3/a;->f(Ljava/lang/Object;)V

    .line 124
    const/4 v1, 0x1

    .line 125
    move v4, v1

    .line 126
    goto :goto_82

    .line 127
    :cond_7e
    add-int/lit8 v14, v14, 0x1

    .line 129
    const/4 v1, 0x0

    .line 130
    goto :goto_58

    .line 131
    :cond_82
    :goto_82
    add-int/lit8 v10, v10, 0x1

    .line 133
    const/4 v1, 0x0

    .line 134
    goto :goto_38

    .line 135
    :cond_86
    :goto_86
    add-int/lit8 v3, v3, 0x1

    .line 137
    const/4 v1, 0x0

    .line 138
    goto :goto_b

    .line 139
    :cond_8a
    return v4
.end method

.method public f()Z
    .registers 8

    .line 1
    invoke-virtual {p0}, Lb3/b;->a()Z

    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_d

    .line 8
    const-string v0, "We could not load the native library to test for root"

    .line 10
    invoke-static {v0}, Lc3/a;->b(Ljava/lang/Object;)V

    .line 13
    return v1

    .line 14
    :cond_d
    invoke-static {}, Lb3/a;->a()[Ljava/lang/String;

    .line 17
    move-result-object v0

    .line 18
    array-length v2, v0

    .line 19
    new-array v3, v2, [Ljava/lang/String;

    .line 21
    move v4, v1

    .line 22
    :goto_15
    if-ge v4, v2, :cond_2f

    .line 24
    new-instance v5, Ljava/lang/StringBuilder;

    .line 26
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 29
    aget-object v6, v0, v4

    .line 31
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    const-string v6, "su"

    .line 36
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    move-result-object v5

    .line 43
    aput-object v5, v3, v4

    .line 45
    add-int/lit8 v4, v4, 0x1

    .line 47
    goto :goto_15

    .line 48
    :cond_2f
    new-instance v0, Lcom/scottyab/rootbeer/RootBeerNative;

    .line 50
    invoke-direct {v0}, Lcom/scottyab/rootbeer/RootBeerNative;-><init>()V

    .line 53
    :try_start_34
    iget-boolean v2, p0, Lb3/b;->b:Z

    .line 55
    invoke-virtual {v0, v2}, Lcom/scottyab/rootbeer/RootBeerNative;->setLogDebugMessages(Z)I

    .line 58
    invoke-virtual {v0, v3}, Lcom/scottyab/rootbeer/RootBeerNative;->checkForRoot([Ljava/lang/Object;)I

    .line 61
    move-result v0
    :try_end_3d
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_34 .. :try_end_3d} :catch_40

    .line 62
    if-lez v0, :cond_40

    .line 64
    const/4 v1, 0x1

    .line 65
    :catch_40
    :cond_40
    return v1
.end method

.method public g()Z
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :try_start_2
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 6
    move-result-object v2

    .line 7
    const-string v3, "which"

    .line 9
    const-string v4, "su"

    .line 11
    filled-new-array {v3, v4}, [Ljava/lang/String;

    .line 14
    move-result-object v3

    .line 15
    invoke-virtual {v2, v3}, Ljava/lang/Runtime;->exec([Ljava/lang/String;)Ljava/lang/Process;

    .line 18
    move-result-object v1

    .line 19
    new-instance v2, Ljava/io/BufferedReader;

    .line 21
    new-instance v3, Ljava/io/InputStreamReader;

    .line 23
    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    .line 26
    move-result-object v4

    .line 27
    invoke-direct {v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 30
    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 33
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 36
    move-result-object v2
    :try_end_24
    .catchall {:try_start_2 .. :try_end_24} :catchall_2b

    .line 37
    if-eqz v2, :cond_27

    .line 39
    const/4 v0, 0x1

    .line 40
    :cond_27
    invoke-virtual {v1}, Ljava/lang/Process;->destroy()V

    .line 43
    return v0

    .line 44
    :catchall_2b
    if-eqz v1, :cond_30

    .line 46
    invoke-virtual {v1}, Ljava/lang/Process;->destroy()V

    .line 49
    :cond_30
    return v0
.end method

.method public h()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Lb3/b;->i([Ljava/lang/String;)Z

    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public i([Ljava/lang/String;)Z
    .registers 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    sget-object v1, Lb3/a;->b:[Ljava/lang/String;

    .line 8
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 15
    if-eqz p1, :cond_1a

    .line 17
    array-length v1, p1

    .line 18
    if-lez v1, :cond_1a

    .line 20
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 27
    :cond_1a
    invoke-virtual {p0, v0}, Lb3/b;->m(Ljava/util/List;)Z

    .line 30
    move-result p1

    .line 31
    return p1
.end method

.method public j()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Lb3/b;->k([Ljava/lang/String;)Z

    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public k([Ljava/lang/String;)Z
    .registers 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 3
    sget-object v1, Lb3/a;->a:[Ljava/lang/String;

    .line 5
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 8
    move-result-object v1

    .line 9
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 12
    if-eqz p1, :cond_17

    .line 14
    array-length v1, p1

    .line 15
    if-lez v1, :cond_17

    .line 17
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 24
    :cond_17
    invoke-virtual {p0, v0}, Lb3/b;->m(Ljava/util/List;)Z

    .line 27
    move-result p1

    .line 28
    return p1
.end method

.method public l()Z
    .registers 3

    .line 1
    sget-object v0, Landroid/os/Build;->TAGS:Ljava/lang/String;

    .line 3
    if-eqz v0, :cond_e

    .line 5
    const-string v1, "test-keys"

    .line 7
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_e

    .line 13
    const/4 v0, 0x1

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    return v0
.end method

.method public final m(Ljava/util/List;)Z
    .registers 7

    .line 1
    iget-object v0, p0, Lb3/b;->a:Landroid/content/Context;

    .line 3
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 6
    move-result-object v0

    .line 7
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    move-result-object p1

    .line 11
    const/4 v1, 0x0

    .line 12
    move v2, v1

    .line 13
    :catch_c
    :goto_c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    move-result v3

    .line 17
    if-eqz v3, :cond_31

    .line 19
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    move-result-object v3

    .line 23
    check-cast v3, Ljava/lang/String;

    .line 25
    :try_start_18
    invoke-virtual {v0, v3, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 28
    new-instance v4, Ljava/lang/StringBuilder;

    .line 30
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 33
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    const-string v3, " ROOT management app detected!"

    .line 38
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 44
    move-result-object v3

    .line 45
    invoke-static {v3}, Lc3/a;->b(Ljava/lang/Object;)V
    :try_end_2f
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_18 .. :try_end_2f} :catch_c

    .line 48
    const/4 v2, 0x1

    .line 49
    goto :goto_c

    .line 50
    :cond_31
    return v2
.end method

.method public n()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lb3/b;->j()Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_3b

    .line 7
    invoke-virtual {p0}, Lb3/b;->h()Z

    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_3b

    .line 13
    const-string v0, "su"

    .line 15
    invoke-virtual {p0, v0}, Lb3/b;->b(Ljava/lang/String;)Z

    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_3b

    .line 21
    invoke-virtual {p0}, Lb3/b;->c()Z

    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_3b

    .line 27
    invoke-virtual {p0}, Lb3/b;->e()Z

    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_3b

    .line 33
    invoke-virtual {p0}, Lb3/b;->l()Z

    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_3b

    .line 39
    invoke-virtual {p0}, Lb3/b;->g()Z

    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_3b

    .line 45
    invoke-virtual {p0}, Lb3/b;->f()Z

    .line 48
    move-result v0

    .line 49
    if-nez v0, :cond_3b

    .line 51
    invoke-virtual {p0}, Lb3/b;->d()Z

    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_39

    .line 57
    goto :goto_3b

    .line 58
    :cond_39
    const/4 v0, 0x0

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    :goto_3b
    const/4 v0, 0x1

    .line 61
    :goto_3c
    return v0
.end method

.method public o()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lb3/b;->n()Z

    .line 4
    move-result v0

    .line 5
    return v0
.end method

.method public final p()[Ljava/lang/String;
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 5
    move-result-object v1

    .line 6
    const-string v2, "mount"

    .line 8
    invoke-virtual {v1, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    .line 15
    move-result-object v1

    .line 16
    if-nez v1, :cond_12

    .line 18
    return-object v0

    .line 19
    :cond_12
    new-instance v2, Ljava/util/Scanner;

    .line 21
    invoke-direct {v2, v1}, Ljava/util/Scanner;-><init>(Ljava/io/InputStream;)V

    .line 24
    const-string v1, "\\A"

    .line 26
    invoke-virtual {v2, v1}, Ljava/util/Scanner;->useDelimiter(Ljava/lang/String;)Ljava/util/Scanner;

    .line 29
    move-result-object v1

    .line 30
    invoke-virtual {v1}, Ljava/util/Scanner;->next()Ljava/lang/String;

    .line 33
    move-result-object v1

    .line 34
    const-string v2, "\n"

    .line 36
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 39
    move-result-object v0
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_27} :catch_2a
    .catch Ljava/util/NoSuchElementException; {:try_start_1 .. :try_end_27} :catch_28

    .line 40
    return-object v0

    .line 41
    :catch_28
    move-exception v1

    .line 42
    goto :goto_2b

    .line 43
    :catch_2a
    move-exception v1

    .line 44
    :goto_2b
    invoke-static {v1}, Lc3/a;->a(Ljava/lang/Exception;)V

    .line 47
    return-object v0
.end method

.method public final q()[Ljava/lang/String;
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 5
    move-result-object v1

    .line 6
    const-string v2, "getprop"

    .line 8
    invoke-virtual {v1, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    .line 15
    move-result-object v1

    .line 16
    if-nez v1, :cond_12

    .line 18
    return-object v0

    .line 19
    :cond_12
    new-instance v2, Ljava/util/Scanner;

    .line 21
    invoke-direct {v2, v1}, Ljava/util/Scanner;-><init>(Ljava/io/InputStream;)V

    .line 24
    const-string v1, "\\A"

    .line 26
    invoke-virtual {v2, v1}, Ljava/util/Scanner;->useDelimiter(Ljava/lang/String;)Ljava/util/Scanner;

    .line 29
    move-result-object v1

    .line 30
    invoke-virtual {v1}, Ljava/util/Scanner;->next()Ljava/lang/String;

    .line 33
    move-result-object v1

    .line 34
    const-string v2, "\n"

    .line 36
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 39
    move-result-object v0
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_27} :catch_2a
    .catch Ljava/util/NoSuchElementException; {:try_start_1 .. :try_end_27} :catch_28

    .line 40
    return-object v0

    .line 41
    :catch_28
    move-exception v1

    .line 42
    goto :goto_2b

    .line 43
    :catch_2a
    move-exception v1

    .line 44
    :goto_2b
    invoke-static {v1}, Lc3/a;->a(Ljava/lang/Exception;)V

    .line 47
    return-object v0
.end method

.method public r(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lb3/b;->b:Z

    .line 3
    if-eqz p1, :cond_6

    .line 5
    const/4 p1, 0x5

    .line 6
    goto :goto_7

    .line 7
    :cond_6
    const/4 p1, 0x0

    .line 8
    :goto_7
    sput p1, Lc3/a;->a:I

    .line 10
    return-void
.end method
