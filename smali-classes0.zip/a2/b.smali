.class public interface abstract La2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La2/b$a;
    }
.end annotation


# virtual methods
.method public abstract n(La2/b$a;)Ljava/lang/Object;
.end method
