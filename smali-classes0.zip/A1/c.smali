.class public final LA1/c;
.super LA1/b;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, LA1/b;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 4
    return-void
.end method

.method public static f(Landroid/graphics/drawable/Drawable;)Lr1/v;
    .registers 2

    .line 1
    if-eqz p0, :cond_8

    .line 3
    new-instance v0, LA1/c;

    .line 5
    invoke-direct {v0, p0}, LA1/c;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    return-object v0
.end method


# virtual methods
.method public b()V
    .registers 1

    .line 1
    return-void
.end method

.method public c()I
    .registers 3

    .line 1
    iget-object v0, p0, LA1/b;->a:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, LA1/b;->a:Landroid/graphics/drawable/Drawable;

    .line 9
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 12
    move-result v1

    .line 13
    mul-int/2addr v0, v1

    .line 14
    mul-int/lit8 v0, v0, 0x4

    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 20
    move-result v0

    .line 21
    return v0
.end method

.method public d()Ljava/lang/Class;
    .registers 2

    .line 1
    iget-object v0, p0, LA1/b;->a:Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method
