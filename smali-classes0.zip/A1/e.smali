.class public LA1/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo1/j;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;Lo1/h;)Z
    .registers 3

    .line 1
    check-cast p1, Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {p0, p1, p2}, LA1/e;->d(Landroid/graphics/drawable/Drawable;Lo1/h;)Z

    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;IILo1/h;)Lr1/v;
    .registers 5

    .line 1
    check-cast p1, Landroid/graphics/drawable/Drawable;

    .line 3
    invoke-virtual {p0, p1, p2, p3, p4}, LA1/e;->c(Landroid/graphics/drawable/Drawable;IILo1/h;)Lr1/v;

    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public c(Landroid/graphics/drawable/Drawable;IILo1/h;)Lr1/v;
    .registers 5

    .line 1
    invoke-static {p1}, LA1/c;->f(Landroid/graphics/drawable/Drawable;)Lr1/v;

    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public d(Landroid/graphics/drawable/Drawable;Lo1/h;)Z
    .registers 3

    .line 1
    const/4 p1, 0x1

    .line 2
    return p1
.end method
