.class public interface abstract Landroidx/appcompat/view/menu/g;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/g$a;
    }
.end annotation


# virtual methods
.method public abstract a(Landroidx/appcompat/view/menu/d;Z)V
.end method

.method public abstract b(Z)V
.end method

.method public abstract c()Z
.end method

.method public abstract d(Landroidx/appcompat/view/menu/d;Landroidx/appcompat/view/menu/e;)Z
.end method

.method public abstract f(Landroidx/appcompat/view/menu/d;Landroidx/appcompat/view/menu/e;)Z
.end method

.method public abstract g(Landroidx/appcompat/view/menu/g$a;)V
.end method

.method public abstract h(Landroid/content/Context;Landroidx/appcompat/view/menu/d;)V
.end method

.method public abstract j(Landroidx/appcompat/view/menu/j;)Z
.end method
