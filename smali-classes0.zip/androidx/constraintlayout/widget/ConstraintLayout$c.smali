.class public Landroidx/constraintlayout/widget/ConstraintLayout$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lx/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "c"
.end annotation


# instance fields
.field public a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public final synthetic h:Landroidx/constraintlayout/widget/ConstraintLayout;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V
    .registers 3

    .line 1
    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 3
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    move v2, v1

    .line 9
    :goto_8
    if-ge v2, v0, :cond_12

    .line 11
    iget-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 13
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 16
    add-int/lit8 v2, v2, 0x1

    .line 18
    goto :goto_8

    .line 19
    :cond_12
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 21
    invoke-static {v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->i(Landroidx/constraintlayout/widget/ConstraintLayout;)Ljava/util/ArrayList;

    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 28
    move-result v0

    .line 29
    if-lez v0, :cond_34

    .line 31
    :goto_1e
    if-ge v1, v0, :cond_34

    .line 33
    iget-object v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 35
    invoke-static {v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->i(Landroidx/constraintlayout/widget/ConstraintLayout;)Ljava/util/ArrayList;

    .line 38
    move-result-object v2

    .line 39
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 42
    move-result-object v2

    .line 43
    check-cast v2, Landroidx/constraintlayout/widget/b;

    .line 45
    iget-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 47
    invoke-virtual {v2, v3}, Landroidx/constraintlayout/widget/b;->l(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 50
    add-int/lit8 v1, v1, 0x1

    .line 52
    goto :goto_1e

    .line 53
    :cond_34
    return-void
.end method

.method public final b(Lw/e;Lx/b$a;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move-object/from16 v2, p2

    .line 7
    if-nez v1, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    invoke-virtual/range {p1 .. p1}, Lw/e;->V()I

    .line 13
    move-result v3

    .line 14
    const/16 v4, 0x8

    .line 16
    const/4 v5, 0x0

    .line 17
    if-ne v3, v4, :cond_1f

    .line 19
    invoke-virtual/range {p1 .. p1}, Lw/e;->j0()Z

    .line 22
    move-result v3

    .line 23
    if-nez v3, :cond_1f

    .line 25
    iput v5, v2, Lx/b$a;->e:I

    .line 27
    iput v5, v2, Lx/b$a;->f:I

    .line 29
    iput v5, v2, Lx/b$a;->g:I

    .line 31
    return-void

    .line 32
    :cond_1f
    invoke-virtual/range {p1 .. p1}, Lw/e;->K()Lw/e;

    .line 35
    move-result-object v3

    .line 36
    if-nez v3, :cond_26

    .line 38
    return-void

    .line 39
    :cond_26
    iget-object v3, v2, Lx/b$a;->a:Lw/e$b;

    .line 41
    iget-object v4, v2, Lx/b$a;->b:Lw/e$b;

    .line 43
    iget v6, v2, Lx/b$a;->c:I

    .line 45
    iget v7, v2, Lx/b$a;->d:I

    .line 47
    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->b:I

    .line 49
    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->c:I

    .line 51
    add-int/2addr v8, v9

    .line 52
    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->d:I

    .line 54
    invoke-virtual/range {p1 .. p1}, Lw/e;->s()Ljava/lang/Object;

    .line 57
    move-result-object v10

    .line 58
    check-cast v10, Landroid/view/View;

    .line 60
    sget-object v11, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:[I

    .line 62
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 65
    move-result v12

    .line 66
    aget v12, v11, v12

    .line 68
    const/4 v13, 0x4

    .line 69
    const/4 v14, 0x3

    .line 70
    const/4 v15, 0x2

    .line 71
    const/4 v5, 0x1

    .line 72
    if-eq v12, v5, :cond_ac

    .line 74
    if-eq v12, v15, :cond_a2

    .line 76
    if-eq v12, v14, :cond_93

    .line 78
    if-eq v12, v13, :cond_51

    .line 80
    const/4 v6, 0x0

    .line 81
    goto :goto_b2

    .line 82
    :cond_51
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->f:I

    .line 84
    const/4 v12, -0x2

    .line 85
    invoke-static {v6, v9, v12}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 88
    move-result v6

    .line 89
    iget v9, v1, Lw/e;->w:I

    .line 91
    if-ne v9, v5, :cond_5e

    .line 93
    move v9, v5

    .line 94
    goto :goto_5f

    .line 95
    :cond_5e
    const/4 v9, 0x0

    .line 96
    :goto_5f
    iget v12, v2, Lx/b$a;->j:I

    .line 98
    sget v13, Lx/b$a;->l:I

    .line 100
    if-eq v12, v13, :cond_69

    .line 102
    sget v13, Lx/b$a;->m:I

    .line 104
    if-ne v12, v13, :cond_b2

    .line 106
    :cond_69
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    .line 109
    move-result v12

    .line 110
    invoke-virtual/range {p1 .. p1}, Lw/e;->x()I

    .line 113
    move-result v13

    .line 114
    if-ne v12, v13, :cond_75

    .line 116
    move v12, v5

    .line 117
    goto :goto_76

    .line 118
    :cond_75
    const/4 v12, 0x0

    .line 119
    :goto_76
    iget v13, v2, Lx/b$a;->j:I

    .line 121
    sget v14, Lx/b$a;->m:I

    .line 123
    if-eq v13, v14, :cond_88

    .line 125
    if-eqz v9, :cond_88

    .line 127
    if-eqz v9, :cond_82

    .line 129
    if-nez v12, :cond_88

    .line 131
    :cond_82
    invoke-virtual/range {p1 .. p1}, Lw/e;->n0()Z

    .line 134
    move-result v9

    .line 135
    if-eqz v9, :cond_b2

    .line 137
    :cond_88
    invoke-virtual/range {p1 .. p1}, Lw/e;->W()I

    .line 140
    move-result v6

    .line 141
    const/high16 v12, 0x40000000    # 2.0f

    .line 143
    invoke-static {v6, v12}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 146
    move-result v6

    .line 147
    goto :goto_b2

    .line 148
    :cond_93
    const/high16 v12, 0x40000000    # 2.0f

    .line 150
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->f:I

    .line 152
    invoke-virtual/range {p1 .. p1}, Lw/e;->B()I

    .line 155
    move-result v13

    .line 156
    add-int/2addr v9, v13

    .line 157
    const/4 v13, -0x1

    .line 158
    invoke-static {v6, v9, v13}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 161
    move-result v6

    .line 162
    goto :goto_b2

    .line 163
    :cond_a2
    const/high16 v12, 0x40000000    # 2.0f

    .line 165
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->f:I

    .line 167
    const/4 v13, -0x2

    .line 168
    invoke-static {v6, v9, v13}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 171
    move-result v6

    .line 172
    goto :goto_b2

    .line 173
    :cond_ac
    const/high16 v12, 0x40000000    # 2.0f

    .line 175
    invoke-static {v6, v12}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 178
    move-result v6

    .line 179
    :cond_b2
    :goto_b2
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 182
    move-result v9

    .line 183
    aget v9, v11, v9

    .line 185
    if-eq v9, v5, :cond_11f

    .line 187
    if-eq v9, v15, :cond_115

    .line 189
    const/4 v7, 0x3

    .line 190
    if-eq v9, v7, :cond_106

    .line 192
    const/4 v7, 0x4

    .line 193
    if-eq v9, v7, :cond_c4

    .line 195
    const/4 v7, 0x0

    .line 196
    goto :goto_125

    .line 197
    :cond_c4
    iget v7, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->g:I

    .line 199
    const/4 v9, -0x2

    .line 200
    invoke-static {v7, v8, v9}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 203
    move-result v7

    .line 204
    iget v8, v1, Lw/e;->x:I

    .line 206
    if-ne v8, v5, :cond_d1

    .line 208
    move v8, v5

    .line 209
    goto :goto_d2

    .line 210
    :cond_d1
    const/4 v8, 0x0

    .line 211
    :goto_d2
    iget v9, v2, Lx/b$a;->j:I

    .line 213
    sget v11, Lx/b$a;->l:I

    .line 215
    if-eq v9, v11, :cond_dc

    .line 217
    sget v11, Lx/b$a;->m:I

    .line 219
    if-ne v9, v11, :cond_125

    .line 221
    :cond_dc
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    .line 224
    move-result v9

    .line 225
    invoke-virtual/range {p1 .. p1}, Lw/e;->W()I

    .line 228
    move-result v11

    .line 229
    if-ne v9, v11, :cond_e8

    .line 231
    move v9, v5

    .line 232
    goto :goto_e9

    .line 233
    :cond_e8
    const/4 v9, 0x0

    .line 234
    :goto_e9
    iget v11, v2, Lx/b$a;->j:I

    .line 236
    sget v12, Lx/b$a;->m:I

    .line 238
    if-eq v11, v12, :cond_fb

    .line 240
    if-eqz v8, :cond_fb

    .line 242
    if-eqz v8, :cond_f5

    .line 244
    if-nez v9, :cond_fb

    .line 246
    :cond_f5
    invoke-virtual/range {p1 .. p1}, Lw/e;->o0()Z

    .line 249
    move-result v8

    .line 250
    if-eqz v8, :cond_125

    .line 252
    :cond_fb
    invoke-virtual/range {p1 .. p1}, Lw/e;->x()I

    .line 255
    move-result v7

    .line 256
    const/high16 v9, 0x40000000    # 2.0f

    .line 258
    invoke-static {v7, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 261
    move-result v7

    .line 262
    goto :goto_125

    .line 263
    :cond_106
    const/high16 v9, 0x40000000    # 2.0f

    .line 265
    iget v7, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->g:I

    .line 267
    invoke-virtual/range {p1 .. p1}, Lw/e;->U()I

    .line 270
    move-result v11

    .line 271
    add-int/2addr v8, v11

    .line 272
    const/4 v11, -0x1

    .line 273
    invoke-static {v7, v8, v11}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 276
    move-result v7

    .line 277
    goto :goto_125

    .line 278
    :cond_115
    const/high16 v9, 0x40000000    # 2.0f

    .line 280
    iget v7, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->g:I

    .line 282
    const/4 v11, -0x2

    .line 283
    invoke-static {v7, v8, v11}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 286
    move-result v7

    .line 287
    goto :goto_125

    .line 288
    :cond_11f
    const/high16 v9, 0x40000000    # 2.0f

    .line 290
    invoke-static {v7, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 293
    move-result v7

    .line 294
    :cond_125
    :goto_125
    invoke-virtual/range {p1 .. p1}, Lw/e;->K()Lw/e;

    .line 297
    move-result-object v8

    .line 298
    check-cast v8, Lw/f;

    .line 300
    if-eqz v8, :cond_1a2

    .line 302
    iget-object v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 304
    invoke-static {v9}, Landroidx/constraintlayout/widget/ConstraintLayout;->h(Landroidx/constraintlayout/widget/ConstraintLayout;)I

    .line 307
    move-result v9

    .line 308
    const/16 v11, 0x100

    .line 310
    invoke-static {v9, v11}, Lw/k;->b(II)Z

    .line 313
    move-result v9

    .line 314
    if-eqz v9, :cond_1a2

    .line 316
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    .line 319
    move-result v9

    .line 320
    invoke-virtual/range {p1 .. p1}, Lw/e;->W()I

    .line 323
    move-result v11

    .line 324
    if-ne v9, v11, :cond_1a2

    .line 326
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    .line 329
    move-result v9

    .line 330
    invoke-virtual {v8}, Lw/e;->W()I

    .line 333
    move-result v11

    .line 334
    if-ge v9, v11, :cond_1a2

    .line 336
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    .line 339
    move-result v9

    .line 340
    invoke-virtual/range {p1 .. p1}, Lw/e;->x()I

    .line 343
    move-result v11

    .line 344
    if-ne v9, v11, :cond_1a2

    .line 346
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    .line 349
    move-result v9

    .line 350
    invoke-virtual {v8}, Lw/e;->x()I

    .line 353
    move-result v8

    .line 354
    if-ge v9, v8, :cond_1a2

    .line 356
    invoke-virtual {v10}, Landroid/view/View;->getBaseline()I

    .line 359
    move-result v8

    .line 360
    invoke-virtual/range {p1 .. p1}, Lw/e;->p()I

    .line 363
    move-result v9

    .line 364
    if-ne v8, v9, :cond_1a2

    .line 366
    invoke-virtual/range {p1 .. p1}, Lw/e;->m0()Z

    .line 369
    move-result v8

    .line 370
    if-nez v8, :cond_1a2

    .line 372
    invoke-virtual/range {p1 .. p1}, Lw/e;->C()I

    .line 375
    move-result v8

    .line 376
    invoke-virtual/range {p1 .. p1}, Lw/e;->W()I

    .line 379
    move-result v9

    .line 380
    invoke-virtual {v0, v8, v6, v9}, Landroidx/constraintlayout/widget/ConstraintLayout$c;->d(III)Z

    .line 383
    move-result v8

    .line 384
    if-eqz v8, :cond_1a2

    .line 386
    invoke-virtual/range {p1 .. p1}, Lw/e;->D()I

    .line 389
    move-result v8

    .line 390
    invoke-virtual/range {p1 .. p1}, Lw/e;->x()I

    .line 393
    move-result v9

    .line 394
    invoke-virtual {v0, v8, v7, v9}, Landroidx/constraintlayout/widget/ConstraintLayout$c;->d(III)Z

    .line 397
    move-result v8

    .line 398
    if-eqz v8, :cond_1a2

    .line 400
    invoke-virtual/range {p1 .. p1}, Lw/e;->W()I

    .line 403
    move-result v3

    .line 404
    iput v3, v2, Lx/b$a;->e:I

    .line 406
    invoke-virtual/range {p1 .. p1}, Lw/e;->x()I

    .line 409
    move-result v3

    .line 410
    iput v3, v2, Lx/b$a;->f:I

    .line 412
    invoke-virtual/range {p1 .. p1}, Lw/e;->p()I

    .line 415
    move-result v1

    .line 416
    iput v1, v2, Lx/b$a;->g:I

    .line 418
    return-void

    .line 419
    :cond_1a2
    sget-object v8, Lw/e$b;->c:Lw/e$b;

    .line 421
    if-ne v3, v8, :cond_1a8

    .line 423
    move v9, v5

    .line 424
    goto :goto_1a9

    .line 425
    :cond_1a8
    const/4 v9, 0x0

    .line 426
    :goto_1a9
    if-ne v4, v8, :cond_1ad

    .line 428
    move v8, v5

    .line 429
    goto :goto_1ae

    .line 430
    :cond_1ad
    const/4 v8, 0x0

    .line 431
    :goto_1ae
    sget-object v11, Lw/e$b;->d:Lw/e$b;

    .line 433
    if-eq v4, v11, :cond_1b9

    .line 435
    sget-object v12, Lw/e$b;->a:Lw/e$b;

    .line 437
    if-ne v4, v12, :cond_1b7

    .line 439
    goto :goto_1b9

    .line 440
    :cond_1b7
    const/4 v4, 0x0

    .line 441
    goto :goto_1ba

    .line 442
    :cond_1b9
    :goto_1b9
    move v4, v5

    .line 443
    :goto_1ba
    if-eq v3, v11, :cond_1c3

    .line 445
    sget-object v11, Lw/e$b;->a:Lw/e$b;

    .line 447
    if-ne v3, v11, :cond_1c1

    .line 449
    goto :goto_1c3

    .line 450
    :cond_1c1
    const/4 v3, 0x0

    .line 451
    goto :goto_1c4

    .line 452
    :cond_1c3
    :goto_1c3
    move v3, v5

    .line 453
    :goto_1c4
    const/4 v11, 0x0

    .line 454
    if-eqz v9, :cond_1cf

    .line 456
    iget v12, v1, Lw/e;->d0:F

    .line 458
    cmpl-float v12, v12, v11

    .line 460
    if-lez v12, :cond_1cf

    .line 462
    move v12, v5

    .line 463
    goto :goto_1d0

    .line 464
    :cond_1cf
    const/4 v12, 0x0

    .line 465
    :goto_1d0
    if-eqz v8, :cond_1da

    .line 467
    iget v13, v1, Lw/e;->d0:F

    .line 469
    cmpl-float v11, v13, v11

    .line 471
    if-lez v11, :cond_1da

    .line 473
    move v11, v5

    .line 474
    goto :goto_1db

    .line 475
    :cond_1da
    const/4 v11, 0x0

    .line 476
    :goto_1db
    if-nez v10, :cond_1de

    .line 478
    return-void

    .line 479
    :cond_1de
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 482
    move-result-object v13

    .line 483
    check-cast v13, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    .line 485
    iget v14, v2, Lx/b$a;->j:I

    .line 487
    sget v15, Lx/b$a;->l:I

    .line 489
    if-eq v14, v15, :cond_201

    .line 491
    sget v15, Lx/b$a;->m:I

    .line 493
    if-eq v14, v15, :cond_201

    .line 495
    if-eqz v9, :cond_201

    .line 497
    iget v9, v1, Lw/e;->w:I

    .line 499
    if-nez v9, :cond_201

    .line 501
    if-eqz v8, :cond_201

    .line 503
    iget v8, v1, Lw/e;->x:I

    .line 505
    if-eqz v8, :cond_1fb

    .line 507
    goto :goto_201

    .line 508
    :cond_1fb
    const/4 v0, -0x1

    .line 509
    const/4 v5, 0x0

    .line 510
    const/4 v14, 0x0

    .line 511
    const/4 v15, 0x0

    .line 512
    goto/16 :goto_29c

    .line 514
    :cond_201
    :goto_201
    instance-of v8, v10, Lz/f;

    .line 516
    if-eqz v8, :cond_213

    .line 518
    instance-of v8, v1, Lw/l;

    .line 520
    if-eqz v8, :cond_213

    .line 522
    move-object v8, v1

    .line 523
    check-cast v8, Lw/l;

    .line 525
    move-object v9, v10

    .line 526
    check-cast v9, Lz/f;

    .line 528
    invoke-virtual {v9, v8, v6, v7}, Lz/f;->p(Lw/l;II)V

    .line 531
    goto :goto_216

    .line 532
    :cond_213
    invoke-virtual {v10, v6, v7}, Landroid/view/View;->measure(II)V

    .line 535
    :goto_216
    invoke-virtual {v1, v6, v7}, Lw/e;->V0(II)V

    .line 538
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    .line 541
    move-result v8

    .line 542
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    .line 545
    move-result v9

    .line 546
    invoke-virtual {v10}, Landroid/view/View;->getBaseline()I

    .line 549
    move-result v14

    .line 550
    iget v15, v1, Lw/e;->z:I

    .line 552
    if-lez v15, :cond_22e

    .line 554
    invoke-static {v15, v8}, Ljava/lang/Math;->max(II)I

    .line 557
    move-result v15

    .line 558
    goto :goto_22f

    .line 559
    :cond_22e
    move v15, v8

    .line 560
    :goto_22f
    iget v5, v1, Lw/e;->A:I

    .line 562
    if-lez v5, :cond_237

    .line 564
    invoke-static {v5, v15}, Ljava/lang/Math;->min(II)I

    .line 567
    move-result v15

    .line 568
    :cond_237
    iget v5, v1, Lw/e;->C:I

    .line 570
    if-lez v5, :cond_242

    .line 572
    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    .line 575
    move-result v5

    .line 576
    move/from16 v16, v6

    .line 578
    goto :goto_245

    .line 579
    :cond_242
    move/from16 v16, v6

    .line 581
    move v5, v9

    .line 582
    :goto_245
    iget v6, v1, Lw/e;->D:I

    .line 584
    if-lez v6, :cond_24d

    .line 586
    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    .line 589
    move-result v5

    .line 590
    :cond_24d
    iget-object v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 592
    invoke-static {v6}, Landroidx/constraintlayout/widget/ConstraintLayout;->h(Landroidx/constraintlayout/widget/ConstraintLayout;)I

    .line 595
    move-result v6

    .line 596
    const/4 v0, 0x1

    .line 597
    invoke-static {v6, v0}, Lw/k;->b(II)Z

    .line 600
    move-result v6

    .line 601
    if-nez v6, :cond_271

    .line 603
    const/high16 v0, 0x3f000000    # 0.5f

    .line 605
    if-eqz v12, :cond_267

    .line 607
    if-eqz v4, :cond_267

    .line 609
    iget v3, v1, Lw/e;->d0:F

    .line 611
    int-to-float v4, v5

    .line 612
    mul-float/2addr v4, v3

    .line 613
    add-float/2addr v4, v0

    .line 614
    float-to-int v15, v4

    .line 615
    goto :goto_271

    .line 616
    :cond_267
    if-eqz v11, :cond_271

    .line 618
    if-eqz v3, :cond_271

    .line 620
    iget v3, v1, Lw/e;->d0:F

    .line 622
    int-to-float v4, v15

    .line 623
    div-float/2addr v4, v3

    .line 624
    add-float/2addr v4, v0

    .line 625
    float-to-int v5, v4

    .line 626
    :cond_271
    :goto_271
    if-ne v8, v15, :cond_278

    .line 628
    if-eq v9, v5, :cond_276

    .line 630
    goto :goto_278

    .line 631
    :cond_276
    :goto_276
    const/4 v0, -0x1

    .line 632
    goto :goto_29c

    .line 633
    :cond_278
    :goto_278
    const/high16 v0, 0x40000000    # 2.0f

    .line 635
    if-eq v8, v15, :cond_281

    .line 637
    invoke-static {v15, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 640
    move-result v6

    .line 641
    goto :goto_283

    .line 642
    :cond_281
    move/from16 v6, v16

    .line 644
    :goto_283
    if-eq v9, v5, :cond_289

    .line 646
    invoke-static {v5, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 649
    move-result v7

    .line 650
    :cond_289
    invoke-virtual {v10, v6, v7}, Landroid/view/View;->measure(II)V

    .line 653
    invoke-virtual {v1, v6, v7}, Lw/e;->V0(II)V

    .line 656
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    .line 659
    move-result v15

    .line 660
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    .line 663
    move-result v5

    .line 664
    invoke-virtual {v10}, Landroid/view/View;->getBaseline()I

    .line 667
    move-result v14

    .line 668
    goto :goto_276

    .line 669
    :goto_29c
    if-eq v14, v0, :cond_2a0

    .line 671
    const/4 v0, 0x1

    .line 672
    goto :goto_2a1

    .line 673
    :cond_2a0
    const/4 v0, 0x0

    .line 674
    :goto_2a1
    iget v3, v2, Lx/b$a;->c:I

    .line 676
    if-ne v15, v3, :cond_2ac

    .line 678
    iget v3, v2, Lx/b$a;->d:I

    .line 680
    if-eq v5, v3, :cond_2aa

    .line 682
    goto :goto_2ac

    .line 683
    :cond_2aa
    const/4 v3, 0x0

    .line 684
    goto :goto_2ad

    .line 685
    :cond_2ac
    :goto_2ac
    const/4 v3, 0x1

    .line 686
    :goto_2ad
    iput-boolean v3, v2, Lx/b$a;->i:Z

    .line 688
    iget-boolean v3, v13, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:Z

    .line 690
    if-eqz v3, :cond_2b4

    .line 692
    const/4 v0, 0x1

    .line 693
    :cond_2b4
    if-eqz v0, :cond_2c2

    .line 695
    const/4 v3, -0x1

    .line 696
    if-eq v14, v3, :cond_2c2

    .line 698
    invoke-virtual/range {p1 .. p1}, Lw/e;->p()I

    .line 701
    move-result v1

    .line 702
    if-eq v1, v14, :cond_2c2

    .line 704
    const/4 v1, 0x1

    .line 705
    iput-boolean v1, v2, Lx/b$a;->i:Z

    .line 707
    :cond_2c2
    iput v15, v2, Lx/b$a;->e:I

    .line 709
    iput v5, v2, Lx/b$a;->f:I

    .line 711
    iput-boolean v0, v2, Lx/b$a;->h:Z

    .line 713
    iput v14, v2, Lx/b$a;->g:I

    .line 715
    return-void
.end method

.method public c(IIIIII)V
    .registers 7

    .line 1
    iput p3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->b:I

    .line 3
    iput p4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->c:I

    .line 5
    iput p5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->d:I

    .line 7
    iput p6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->e:I

    .line 9
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->f:I

    .line 11
    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$c;->g:I

    .line 13
    return-void
.end method

.method public final d(III)Z
    .registers 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p2, :cond_4

    .line 4
    return v0

    .line 5
    :cond_4
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 8
    move-result v1

    .line 9
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 12
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 15
    move-result p1

    .line 16
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 19
    move-result p2

    .line 20
    const/high16 v2, 0x40000000    # 2.0f

    .line 22
    if-ne p1, v2, :cond_20

    .line 24
    const/high16 p1, -0x80000000

    .line 26
    if-eq v1, p1, :cond_1d

    .line 28
    if-nez v1, :cond_20

    .line 30
    :cond_1d
    if-ne p3, p2, :cond_20

    .line 32
    return v0

    .line 33
    :cond_20
    const/4 p1, 0x0

    .line 34
    return p1
.end method
