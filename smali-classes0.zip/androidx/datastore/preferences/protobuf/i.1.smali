.class public final Landroidx/datastore/preferences/protobuf/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/datastore/preferences/protobuf/d0;


# instance fields
.field public final a:Landroidx/datastore/preferences/protobuf/h;

.field public b:I

.field public c:I

.field public d:I


# direct methods
.method public constructor <init>(Landroidx/datastore/preferences/protobuf/h;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 7
    const-string v0, "input"

    .line 9
    invoke-static {p1, v0}, Landroidx/datastore/preferences/protobuf/y;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    move-result-object p1

    .line 13
    check-cast p1, Landroidx/datastore/preferences/protobuf/h;

    .line 15
    iput-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 17
    iput-object p0, p1, Landroidx/datastore/preferences/protobuf/h;->d:Landroidx/datastore/preferences/protobuf/i;

    .line 19
    return-void
.end method

.method public static f(Landroidx/datastore/preferences/protobuf/h;)Landroidx/datastore/preferences/protobuf/i;
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/h;->d:Landroidx/datastore/preferences/protobuf/i;

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-object v0

    .line 6
    :cond_5
    new-instance v0, Landroidx/datastore/preferences/protobuf/i;

    .line 8
    invoke-direct {v0, p0}, Landroidx/datastore/preferences/protobuf/i;-><init>(Landroidx/datastore/preferences/protobuf/h;)V

    .line 11
    return-object v0
.end method

.method private g(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Class;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 5

    .line 1
    sget-object v0, Landroidx/datastore/preferences/protobuf/i$a;->a:[I

    .line 3
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 6
    move-result p1

    .line 7
    aget p1, v0, p1

    .line 9
    packed-switch p1, :pswitch_data_a0

    .line 12
    new-instance p1, Ljava/lang/RuntimeException;

    .line 14
    const-string p2, "unsupported field type."

    .line 16
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 19
    throw p1

    .line 20
    :pswitch_13
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readUInt64()J

    .line 23
    move-result-wide p1

    .line 24
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 27
    move-result-object p1

    .line 28
    return-object p1

    .line 29
    :pswitch_1c
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readUInt32()I

    .line 32
    move-result p1

    .line 33
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    move-result-object p1

    .line 37
    return-object p1

    .line 38
    :pswitch_25
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readStringRequireUtf8()Ljava/lang/String;

    .line 41
    move-result-object p1

    .line 42
    return-object p1

    .line 43
    :pswitch_2a
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readSInt64()J

    .line 46
    move-result-wide p1

    .line 47
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 50
    move-result-object p1

    .line 51
    return-object p1

    .line 52
    :pswitch_33
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readSInt32()I

    .line 55
    move-result p1

    .line 56
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 59
    move-result-object p1

    .line 60
    return-object p1

    .line 61
    :pswitch_3c
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readSFixed64()J

    .line 64
    move-result-wide p1

    .line 65
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 68
    move-result-object p1

    .line 69
    return-object p1

    .line 70
    :pswitch_45
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readSFixed32()I

    .line 73
    move-result p1

    .line 74
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 77
    move-result-object p1

    .line 78
    return-object p1

    .line 79
    :pswitch_4e
    invoke-virtual {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/i;->j(Ljava/lang/Class;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 82
    move-result-object p1

    .line 83
    return-object p1

    .line 84
    :pswitch_53
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readInt64()J

    .line 87
    move-result-wide p1

    .line 88
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 91
    move-result-object p1

    .line 92
    return-object p1

    .line 93
    :pswitch_5c
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readInt32()I

    .line 96
    move-result p1

    .line 97
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 100
    move-result-object p1

    .line 101
    return-object p1

    .line 102
    :pswitch_65
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readFloat()F

    .line 105
    move-result p1

    .line 106
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 109
    move-result-object p1

    .line 110
    return-object p1

    .line 111
    :pswitch_6e
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readFixed64()J

    .line 114
    move-result-wide p1

    .line 115
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 118
    move-result-object p1

    .line 119
    return-object p1

    .line 120
    :pswitch_77
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readFixed32()I

    .line 123
    move-result p1

    .line 124
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    move-result-object p1

    .line 128
    return-object p1

    .line 129
    :pswitch_80
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readEnum()I

    .line 132
    move-result p1

    .line 133
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 136
    move-result-object p1

    .line 137
    return-object p1

    .line 138
    :pswitch_89
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readDouble()D

    .line 141
    move-result-wide p1

    .line 142
    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 145
    move-result-object p1

    .line 146
    return-object p1

    .line 147
    :pswitch_92
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readBytes()Landroidx/datastore/preferences/protobuf/g;

    .line 150
    move-result-object p1

    .line 151
    return-object p1

    .line 152
    :pswitch_97
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readBool()Z

    .line 155
    move-result p1

    .line 156
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 159
    move-result-object p1

    .line 160
    return-object p1

    .line 161
    :pswitch_data_a0
    .packed-switch 0x1
        :pswitch_97
        :pswitch_92
        :pswitch_89
        :pswitch_80
        :pswitch_77
        :pswitch_6e
        :pswitch_65
        :pswitch_5c
        :pswitch_53
        :pswitch_4e
        :pswitch_45
        :pswitch_3c
        :pswitch_33
        :pswitch_2a
        :pswitch_25
        :pswitch_1c
        :pswitch_13
    .end packed-switch
.end method

.method private h(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 3
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 5
    invoke-static {v1}, Landroidx/datastore/preferences/protobuf/r0;->a(I)I

    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x4

    .line 10
    invoke-static {v1, v2}, Landroidx/datastore/preferences/protobuf/r0;->c(II)I

    .line 13
    move-result v1

    .line 14
    iput v1, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 16
    :try_start_f
    invoke-interface {p1}, Landroidx/datastore/preferences/protobuf/e0;->newInstance()Ljava/lang/Object;

    .line 19
    move-result-object v1

    .line 20
    invoke-interface {p1, v1, p0, p2}, Landroidx/datastore/preferences/protobuf/e0;->a(Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/d0;Landroidx/datastore/preferences/protobuf/o;)V

    .line 23
    invoke-interface {p1, v1}, Landroidx/datastore/preferences/protobuf/e0;->makeImmutable(Ljava/lang/Object;)V

    .line 26
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 28
    iget p2, p0, Landroidx/datastore/preferences/protobuf/i;->c:I
    :try_end_1d
    .catchall {:try_start_f .. :try_end_1d} :catchall_27

    .line 30
    if-ne p1, p2, :cond_22

    .line 32
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 34
    return-object v1

    .line 35
    :cond_22
    :try_start_22
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->g()Landroidx/datastore/preferences/protobuf/z;

    .line 38
    move-result-object p1

    .line 39
    throw p1
    :try_end_27
    .catchall {:try_start_22 .. :try_end_27} :catchall_27

    .line 40
    :catchall_27
    move-exception p1

    .line 41
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 43
    throw p1
.end method

.method private i(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 3
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 9
    iget v2, v1, Landroidx/datastore/preferences/protobuf/h;->a:I

    .line 11
    iget v3, v1, Landroidx/datastore/preferences/protobuf/h;->b:I

    .line 13
    if-ge v2, v3, :cond_36

    .line 15
    invoke-virtual {v1, v0}, Landroidx/datastore/preferences/protobuf/h;->l(I)I

    .line 18
    move-result v0

    .line 19
    invoke-interface {p1}, Landroidx/datastore/preferences/protobuf/e0;->newInstance()Ljava/lang/Object;

    .line 22
    move-result-object v1

    .line 23
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 25
    iget v3, v2, Landroidx/datastore/preferences/protobuf/h;->a:I

    .line 27
    add-int/lit8 v3, v3, 0x1

    .line 29
    iput v3, v2, Landroidx/datastore/preferences/protobuf/h;->a:I

    .line 31
    invoke-interface {p1, v1, p0, p2}, Landroidx/datastore/preferences/protobuf/e0;->a(Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/d0;Landroidx/datastore/preferences/protobuf/o;)V

    .line 34
    invoke-interface {p1, v1}, Landroidx/datastore/preferences/protobuf/e0;->makeImmutable(Ljava/lang/Object;)V

    .line 37
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 39
    const/4 p2, 0x0

    .line 40
    invoke-virtual {p1, p2}, Landroidx/datastore/preferences/protobuf/h;->a(I)V

    .line 43
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 45
    iget p2, p1, Landroidx/datastore/preferences/protobuf/h;->a:I

    .line 47
    add-int/lit8 p2, p2, -0x1

    .line 49
    iput p2, p1, Landroidx/datastore/preferences/protobuf/h;->a:I

    .line 51
    invoke-virtual {p1, v0}, Landroidx/datastore/preferences/protobuf/h;->k(I)V

    .line 54
    return-object v1

    .line 55
    :cond_36
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->h()Landroidx/datastore/preferences/protobuf/z;

    .line 58
    move-result-object p1

    .line 59
    throw p1
.end method

.method private l(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 3
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 6
    move-result v0

    .line 7
    if-ne v0, p1, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->k()Landroidx/datastore/preferences/protobuf/z;

    .line 13
    move-result-object p1

    .line 14
    throw p1
.end method

.method private m(I)V
    .registers 3

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 6
    move-result v0

    .line 7
    if-ne v0, p1, :cond_9

    .line 9
    return-void

    .line 10
    :cond_9
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 13
    move-result-object p1

    .line 14
    throw p1
.end method

.method private n(I)V
    .registers 2

    .line 1
    and-int/lit8 p1, p1, 0x3

    .line 3
    if-nez p1, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->g()Landroidx/datastore/preferences/protobuf/z;

    .line 9
    move-result-object p1

    .line 10
    throw p1
.end method

.method private o(I)V
    .registers 2

    .line 1
    and-int/lit8 p1, p1, 0x7

    .line 3
    if-nez p1, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->g()Landroidx/datastore/preferences/protobuf/z;

    .line 9
    move-result-object p1

    .line 10
    throw p1
.end method


# virtual methods
.method public a(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 4

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    invoke-direct {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/i;->i(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public b(Ljava/util/Map;Landroidx/datastore/preferences/protobuf/H$a;Landroidx/datastore/preferences/protobuf/o;)V
    .registers 11

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 10
    move-result v1

    .line 11
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 13
    invoke-virtual {v2, v1}, Landroidx/datastore/preferences/protobuf/h;->l(I)I

    .line 16
    move-result v1

    .line 17
    iget-object v2, p2, Landroidx/datastore/preferences/protobuf/H$a;->b:Ljava/lang/Object;

    .line 19
    iget-object v3, p2, Landroidx/datastore/preferences/protobuf/H$a;->d:Ljava/lang/Object;

    .line 21
    :goto_14
    :try_start_14
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->getFieldNumber()I

    .line 24
    move-result v4

    .line 25
    const v5, 0x7fffffff

    .line 28
    if-eq v4, v5, :cond_5e

    .line 30
    iget-object v5, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {v5}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 35
    move-result v5
    :try_end_23
    .catchall {:try_start_14 .. :try_end_23} :catchall_3a

    .line 36
    if-eqz v5, :cond_26

    .line 38
    goto :goto_5e

    .line 39
    :cond_26
    const/4 v5, 0x1

    .line 40
    const-string v6, "Unable to parse map entry."

    .line 42
    if-eq v4, v5, :cond_49

    .line 44
    if-eq v4, v0, :cond_3c

    .line 46
    :try_start_2d
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->skipField()Z

    .line 49
    move-result v4

    .line 50
    if-eqz v4, :cond_34

    .line 52
    goto :goto_14

    .line 53
    :cond_34
    new-instance v4, Landroidx/datastore/preferences/protobuf/z;

    .line 55
    invoke-direct {v4, v6}, Landroidx/datastore/preferences/protobuf/z;-><init>(Ljava/lang/String;)V

    .line 58
    throw v4

    .line 59
    :catchall_3a
    move-exception p1

    .line 60
    goto :goto_67

    .line 61
    :cond_3c
    iget-object v4, p2, Landroidx/datastore/preferences/protobuf/H$a;->c:Landroidx/datastore/preferences/protobuf/r0$b;

    .line 63
    iget-object v5, p2, Landroidx/datastore/preferences/protobuf/H$a;->d:Ljava/lang/Object;

    .line 65
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    move-result-object v5

    .line 69
    invoke-direct {p0, v4, v5, p3}, Landroidx/datastore/preferences/protobuf/i;->g(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Class;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 72
    move-result-object v3

    .line 73
    goto :goto_14

    .line 74
    :cond_49
    iget-object v4, p2, Landroidx/datastore/preferences/protobuf/H$a;->a:Landroidx/datastore/preferences/protobuf/r0$b;

    .line 76
    const/4 v5, 0x0

    .line 77
    invoke-direct {p0, v4, v5, v5}, Landroidx/datastore/preferences/protobuf/i;->g(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Class;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 80
    move-result-object v2
    :try_end_50
    .catch Landroidx/datastore/preferences/protobuf/z$a; {:try_start_2d .. :try_end_50} :catch_51
    .catchall {:try_start_2d .. :try_end_50} :catchall_3a

    .line 81
    goto :goto_14

    .line 82
    :catch_51
    :try_start_51
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->skipField()Z

    .line 85
    move-result v4

    .line 86
    if-eqz v4, :cond_58

    .line 88
    goto :goto_14

    .line 89
    :cond_58
    new-instance p1, Landroidx/datastore/preferences/protobuf/z;

    .line 91
    invoke-direct {p1, v6}, Landroidx/datastore/preferences/protobuf/z;-><init>(Ljava/lang/String;)V

    .line 94
    throw p1

    .line 95
    :cond_5e
    :goto_5e
    invoke-interface {p1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_61
    .catchall {:try_start_51 .. :try_end_61} :catchall_3a

    .line 98
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 100
    invoke-virtual {p1, v1}, Landroidx/datastore/preferences/protobuf/h;->k(I)V

    .line 103
    return-void

    .line 104
    :goto_67
    iget-object p2, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 106
    invoke-virtual {p2, v1}, Landroidx/datastore/preferences/protobuf/h;->k(I)V

    .line 109
    throw p1
.end method

.method public c(Ljava/util/List;Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)V
    .registers 6

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x3

    .line 8
    if-ne v0, v1, :cond_2a

    .line 10
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    :cond_b
    invoke-direct {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/i;->h(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 15
    move-result-object v1

    .line 16
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 19
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 21
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_29

    .line 27
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 29
    if-eqz v1, :cond_1f

    .line 31
    goto :goto_29

    .line 32
    :cond_1f
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 34
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 37
    move-result v1

    .line 38
    if-eq v1, v0, :cond_b

    .line 40
    iput v1, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 42
    :cond_29
    :goto_29
    return-void

    .line 43
    :cond_2a
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 46
    move-result-object p1

    .line 47
    throw p1
.end method

.method public d(Ljava/util/List;Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)V
    .registers 6

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x2

    .line 8
    if-ne v0, v1, :cond_2a

    .line 10
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    :cond_b
    invoke-direct {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/i;->i(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 15
    move-result-object v1

    .line 16
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 19
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 21
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_29

    .line 27
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 29
    if-eqz v1, :cond_1f

    .line 31
    goto :goto_29

    .line 32
    :cond_1f
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 34
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 37
    move-result v1

    .line 38
    if-eq v1, v0, :cond_b

    .line 40
    iput v1, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 42
    :cond_29
    :goto_29
    return-void

    .line 43
    :cond_2a
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 46
    move-result-object p1

    .line 47
    throw p1
.end method

.method public e(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    invoke-direct {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/i;->h(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public getFieldNumber()I
    .registers 3

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 3
    if-eqz v0, :cond_a

    .line 5
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 7
    const/4 v0, 0x0

    .line 8
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 10
    goto :goto_12

    .line 11
    :cond_a
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 13
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 16
    move-result v0

    .line 17
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 19
    :goto_12
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 21
    if-eqz v0, :cond_20

    .line 23
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 25
    if-ne v0, v1, :cond_1b

    .line 27
    goto :goto_20

    .line 28
    :cond_1b
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->a(I)I

    .line 31
    move-result v0

    .line 32
    return v0

    .line 33
    :cond_20
    :goto_20
    const v0, 0x7fffffff

    .line 36
    return v0
.end method

.method public getTag()I
    .registers 2

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    return v0
.end method

.method public j(Ljava/lang/Class;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;
    .registers 4

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    invoke-static {}, Landroidx/datastore/preferences/protobuf/a0;->a()Landroidx/datastore/preferences/protobuf/a0;

    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0, p1}, Landroidx/datastore/preferences/protobuf/a0;->c(Ljava/lang/Class;)Landroidx/datastore/preferences/protobuf/e0;

    .line 12
    move-result-object p1

    .line 13
    invoke-direct {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/i;->i(Landroidx/datastore/preferences/protobuf/e0;Landroidx/datastore/preferences/protobuf/o;)Ljava/lang/Object;

    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public k(Ljava/util/List;Z)V
    .registers 5

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x2

    .line 8
    if-ne v0, v1, :cond_53

    .line 10
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/D;

    .line 12
    if-eqz v0, :cond_2f

    .line 14
    if-nez p2, :cond_2f

    .line 16
    move-object v0, p1

    .line 17
    check-cast v0, Landroidx/datastore/preferences/protobuf/D;

    .line 19
    :cond_12
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readBytes()Landroidx/datastore/preferences/protobuf/g;

    .line 22
    move-result-object p1

    .line 23
    invoke-interface {v0, p1}, Landroidx/datastore/preferences/protobuf/D;->U(Landroidx/datastore/preferences/protobuf/g;)V

    .line 26
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_22

    .line 34
    return-void

    .line 35
    :cond_22
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 40
    move-result p1

    .line 41
    iget p2, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 43
    if-eq p1, p2, :cond_12

    .line 45
    iput p1, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 47
    return-void

    .line 48
    :cond_2f
    if-eqz p2, :cond_36

    .line 50
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readStringRequireUtf8()Ljava/lang/String;

    .line 53
    move-result-object v0

    .line 54
    goto :goto_3a

    .line 55
    :cond_36
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readString()Ljava/lang/String;

    .line 58
    move-result-object v0

    .line 59
    :goto_3a
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 62
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_46

    .line 70
    return-void

    .line 71
    :cond_46
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 73
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 76
    move-result v0

    .line 77
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 79
    if-eq v0, v1, :cond_2f

    .line 81
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 83
    return-void

    .line 84
    :cond_53
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 87
    move-result-object p1

    .line 88
    throw p1
.end method

.method public readBool()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->m()Z

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readBoolList(Ljava/util/List;)V
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/e;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->m()Z

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->m()Z

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->m()Z

    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->m()Z

    .line 105
    move-result v0

    .line 106
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readBytes()Landroidx/datastore/preferences/protobuf/g;
    .registers 2

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->n()Landroidx/datastore/preferences/protobuf/g;

    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method public readBytesList(Ljava/util/List;)V
    .registers 4

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 3
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x2

    .line 8
    if-ne v0, v1, :cond_26

    .line 10
    :cond_9
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/i;->readBytes()Landroidx/datastore/preferences/protobuf/g;

    .line 13
    move-result-object v0

    .line 14
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 17
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 19
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_19

    .line 25
    return-void

    .line 26
    :cond_19
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 31
    move-result v0

    .line 32
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 34
    if-eq v0, v1, :cond_9

    .line 36
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 38
    return-void

    .line 39
    :cond_26
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 42
    move-result-object p1

    .line 43
    throw p1
.end method

.method public readDouble()D
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->o()D

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readDoubleList(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/l;

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_2d

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 31
    move-result p1

    .line 32
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 40
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 42
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->o()D

    .line 45
    throw v0

    .line 46
    :cond_2d
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->o()D

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_68

    .line 60
    if-ne v0, v1, :cond_63

    .line 62
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 67
    move-result v0

    .line 68
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 71
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 73
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 76
    move-result v1

    .line 77
    add-int/2addr v1, v0

    .line 78
    :cond_4d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 80
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->o()D

    .line 83
    move-result-wide v2

    .line 84
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 87
    move-result-object v0

    .line 88
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 91
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 93
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 96
    move-result v0

    .line 97
    if-lt v0, v1, :cond_4d

    .line 99
    return-void

    .line 100
    :cond_63
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 103
    move-result-object p1

    .line 104
    throw p1

    .line 105
    :cond_68
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 107
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->o()D

    .line 110
    move-result-wide v0

    .line 111
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 114
    move-result-object v0

    .line 115
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 118
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_7e

    .line 126
    return-void

    .line 127
    :cond_7e
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 129
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 132
    move-result v0

    .line 133
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 135
    if-eq v0, v1, :cond_68

    .line 137
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 139
    return-void
.end method

.method public readEnum()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->p()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readEnumList(Ljava/util/List;)V
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->p()I

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->p()I

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->p()I

    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->p()I

    .line 105
    move-result v0

    .line 106
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readFixed32()I
    .registers 2

    .line 1
    const/4 v0, 0x5

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->q()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readFixed32List(Ljava/util/List;)V
    .registers 5

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x2

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_1f

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->q()I

    .line 31
    throw v0

    .line 32
    :cond_1f
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 34
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 37
    move-result p1

    .line 38
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 41
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 46
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->q()I

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_65

    .line 60
    if-ne v0, v1, :cond_60

    .line 62
    :cond_3d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->q()I

    .line 67
    move-result v0

    .line 68
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    move-result-object v0

    .line 72
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 77
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_53

    .line 83
    return-void

    .line 84
    :cond_53
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 86
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 89
    move-result v0

    .line 90
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 92
    if-eq v0, v1, :cond_3d

    .line 94
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 96
    return-void

    .line 97
    :cond_60
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 100
    move-result-object p1

    .line 101
    throw p1

    .line 102
    :cond_65
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 104
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 107
    move-result v0

    .line 108
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 111
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 113
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 116
    move-result v1

    .line 117
    add-int/2addr v1, v0

    .line 118
    :cond_75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->q()I

    .line 123
    move-result v0

    .line 124
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    move-result-object v0

    .line 128
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 131
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 133
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 136
    move-result v0

    .line 137
    if-lt v0, v1, :cond_75

    .line 139
    return-void
.end method

.method public readFixed64()J
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->r()J

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readFixed64List(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/F;

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_2d

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 31
    move-result p1

    .line 32
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 40
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 42
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->r()J

    .line 45
    throw v0

    .line 46
    :cond_2d
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->r()J

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_68

    .line 60
    if-ne v0, v1, :cond_63

    .line 62
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 67
    move-result v0

    .line 68
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 71
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 73
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 76
    move-result v1

    .line 77
    add-int/2addr v1, v0

    .line 78
    :cond_4d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 80
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->r()J

    .line 83
    move-result-wide v2

    .line 84
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 87
    move-result-object v0

    .line 88
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 91
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 93
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 96
    move-result v0

    .line 97
    if-lt v0, v1, :cond_4d

    .line 99
    return-void

    .line 100
    :cond_63
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 103
    move-result-object p1

    .line 104
    throw p1

    .line 105
    :cond_68
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 107
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->r()J

    .line 110
    move-result-wide v0

    .line 111
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 114
    move-result-object v0

    .line 115
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 118
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_7e

    .line 126
    return-void

    .line 127
    :cond_7e
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 129
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 132
    move-result v0

    .line 133
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 135
    if-eq v0, v1, :cond_68

    .line 137
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 139
    return-void
.end method

.method public readFloat()F
    .registers 2

    .line 1
    const/4 v0, 0x5

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->s()F

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readFloatList(Ljava/util/List;)V
    .registers 5

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/u;

    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x2

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_1f

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->s()F

    .line 31
    throw v0

    .line 32
    :cond_1f
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 34
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 37
    move-result p1

    .line 38
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 41
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 46
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->s()F

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_65

    .line 60
    if-ne v0, v1, :cond_60

    .line 62
    :cond_3d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->s()F

    .line 67
    move-result v0

    .line 68
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 71
    move-result-object v0

    .line 72
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 77
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_53

    .line 83
    return-void

    .line 84
    :cond_53
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 86
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 89
    move-result v0

    .line 90
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 92
    if-eq v0, v1, :cond_3d

    .line 94
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 96
    return-void

    .line 97
    :cond_60
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 100
    move-result-object p1

    .line 101
    throw p1

    .line 102
    :cond_65
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 104
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 107
    move-result v0

    .line 108
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 111
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 113
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 116
    move-result v1

    .line 117
    add-int/2addr v1, v0

    .line 118
    :cond_75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->s()F

    .line 123
    move-result v0

    .line 124
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 127
    move-result-object v0

    .line 128
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 131
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 133
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 136
    move-result v0

    .line 137
    if-lt v0, v1, :cond_75

    .line 139
    return-void
.end method

.method public readInt32()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->t()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readInt32List(Ljava/util/List;)V
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->t()I

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->t()I

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->t()I

    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->t()I

    .line 105
    move-result v0

    .line 106
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readInt64()J
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->u()J

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readInt64List(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/F;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->u()J

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->u()J

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->u()J

    .line 75
    move-result-wide v2

    .line 76
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->u()J

    .line 105
    move-result-wide v0

    .line 106
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readSFixed32()I
    .registers 2

    .line 1
    const/4 v0, 0x5

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->v()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readSFixed32List(Ljava/util/List;)V
    .registers 5

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x2

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_1f

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->v()I

    .line 31
    throw v0

    .line 32
    :cond_1f
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 34
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 37
    move-result p1

    .line 38
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 41
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 46
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->v()I

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_65

    .line 60
    if-ne v0, v1, :cond_60

    .line 62
    :cond_3d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->v()I

    .line 67
    move-result v0

    .line 68
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    move-result-object v0

    .line 72
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 77
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_53

    .line 83
    return-void

    .line 84
    :cond_53
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 86
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 89
    move-result v0

    .line 90
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 92
    if-eq v0, v1, :cond_3d

    .line 94
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 96
    return-void

    .line 97
    :cond_60
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 100
    move-result-object p1

    .line 101
    throw p1

    .line 102
    :cond_65
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 104
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 107
    move-result v0

    .line 108
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->n(I)V

    .line 111
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 113
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 116
    move-result v1

    .line 117
    add-int/2addr v1, v0

    .line 118
    :cond_75
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->v()I

    .line 123
    move-result v0

    .line 124
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    move-result-object v0

    .line 128
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 131
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 133
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 136
    move-result v0

    .line 137
    if-lt v0, v1, :cond_75

    .line 139
    return-void
.end method

.method public readSFixed64()J
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->w()J

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readSFixed64List(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/F;

    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_33

    .line 7
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 10
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 12
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    if-eq p1, v2, :cond_2d

    .line 19
    if-eq p1, v1, :cond_19

    .line 21
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 24
    move-result-object p1

    .line 25
    throw p1

    .line 26
    :cond_19
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 28
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 31
    move-result p1

    .line 32
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 40
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 42
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->w()J

    .line 45
    throw v0

    .line 46
    :cond_2d
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 48
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->w()J

    .line 51
    throw v0

    .line 52
    :cond_33
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 54
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 57
    move-result v0

    .line 58
    if-eq v0, v2, :cond_68

    .line 60
    if-ne v0, v1, :cond_63

    .line 62
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 64
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 67
    move-result v0

    .line 68
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->o(I)V

    .line 71
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 73
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 76
    move-result v1

    .line 77
    add-int/2addr v1, v0

    .line 78
    :cond_4d
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 80
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->w()J

    .line 83
    move-result-wide v2

    .line 84
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 87
    move-result-object v0

    .line 88
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 91
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 93
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 96
    move-result v0

    .line 97
    if-lt v0, v1, :cond_4d

    .line 99
    return-void

    .line 100
    :cond_63
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 103
    move-result-object p1

    .line 104
    throw p1

    .line 105
    :cond_68
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 107
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->w()J

    .line 110
    move-result-wide v0

    .line 111
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 114
    move-result-object v0

    .line 115
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 118
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 120
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_7e

    .line 126
    return-void

    .line 127
    :cond_7e
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 129
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 132
    move-result v0

    .line 133
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 135
    if-eq v0, v1, :cond_68

    .line 137
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 139
    return-void
.end method

.method public readSInt32()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->x()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readSInt32List(Ljava/util/List;)V
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->x()I

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->x()I

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->x()I

    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->x()I

    .line 105
    move-result v0

    .line 106
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readSInt64()J
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->y()J

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readSInt64List(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/F;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->y()J

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->y()J

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->y()J

    .line 75
    move-result-wide v2

    .line 76
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->y()J

    .line 105
    move-result-wide v0

    .line 106
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readString()Ljava/lang/String;
    .registers 2

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->z()Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method public readStringList(Ljava/util/List;)V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, v0}, Landroidx/datastore/preferences/protobuf/i;->k(Ljava/util/List;Z)V

    .line 5
    return-void
.end method

.method public readStringListRequireUtf8(Ljava/util/List;)V
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, p1, v0}, Landroidx/datastore/preferences/protobuf/i;->k(Ljava/util/List;Z)V

    .line 5
    return-void
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .registers 2

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->A()Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method public readUInt32()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public readUInt32List(Ljava/util/List;)V
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/x;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 75
    move-result v0

    .line 76
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 105
    move-result v0

    .line 106
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public readUInt64()J
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Landroidx/datastore/preferences/protobuf/i;->m(I)V

    .line 5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 7
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->D()J

    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method

.method public readUInt64List(Ljava/util/List;)V
    .registers 6

    .line 1
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/F;

    .line 3
    const/4 v1, 0x2

    .line 4
    if-eqz v0, :cond_2e

    .line 6
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 9
    iget p1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p1, :cond_28

    .line 18
    if-eq p1, v1, :cond_18

    .line 20
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 23
    move-result-object p1

    .line 24
    throw p1

    .line 25
    :cond_18
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 27
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 30
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 32
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 35
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 37
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->D()J

    .line 40
    throw v0

    .line 41
    :cond_28
    iget-object p1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 43
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h;->D()J

    .line 46
    throw v0

    .line 47
    :cond_2e
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 49
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/r0;->b(I)I

    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_63

    .line 55
    if-ne v0, v1, :cond_5e

    .line 57
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 59
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->C()I

    .line 62
    move-result v0

    .line 63
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 65
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 68
    move-result v1

    .line 69
    add-int/2addr v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 72
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->D()J

    .line 75
    move-result-wide v2

    .line 76
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 79
    move-result-object v0

    .line 80
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 85
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->d()I

    .line 88
    move-result v0

    .line 89
    if-lt v0, v1, :cond_45

    .line 91
    invoke-direct {p0, v1}, Landroidx/datastore/preferences/protobuf/i;->l(I)V

    .line 94
    return-void

    .line 95
    :cond_5e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->d()Landroidx/datastore/preferences/protobuf/z$a;

    .line 98
    move-result-object p1

    .line 99
    throw p1

    .line 100
    :cond_63
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 102
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->D()J

    .line 105
    move-result-wide v0

    .line 106
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 109
    move-result-object v0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 113
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 115
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_79

    .line 121
    return-void

    .line 122
    :cond_79
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 124
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->B()I

    .line 127
    move-result v0

    .line 128
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 130
    if-eq v0, v1, :cond_63

    .line 132
    iput v0, p0, Landroidx/datastore/preferences/protobuf/i;->d:I

    .line 134
    return-void
.end method

.method public skipField()Z
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 3
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h;->e()Z

    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_16

    .line 9
    iget v0, p0, Landroidx/datastore/preferences/protobuf/i;->b:I

    .line 11
    iget v1, p0, Landroidx/datastore/preferences/protobuf/i;->c:I

    .line 13
    if-ne v0, v1, :cond_f

    .line 15
    goto :goto_16

    .line 16
    :cond_f
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/i;->a:Landroidx/datastore/preferences/protobuf/h;

    .line 18
    invoke-virtual {v1, v0}, Landroidx/datastore/preferences/protobuf/h;->E(I)Z

    .line 21
    move-result v0

    .line 22
    return v0

    .line 23
    :cond_16
    :goto_16
    const/4 v0, 0x0

    .line 24
    return v0
.end method
