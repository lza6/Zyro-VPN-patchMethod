.class public final Landroidx/datastore/preferences/protobuf/s;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/datastore/preferences/protobuf/s$b;
    }
.end annotation


# static fields
.field public static final d:Landroidx/datastore/preferences/protobuf/s;


# instance fields
.field public final a:Landroidx/datastore/preferences/protobuf/h0;

.field public b:Z

.field public c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Landroidx/datastore/preferences/protobuf/s;

    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Landroidx/datastore/preferences/protobuf/s;-><init>(Z)V

    .line 7
    sput-object v0, Landroidx/datastore/preferences/protobuf/s;->d:Landroidx/datastore/preferences/protobuf/s;

    .line 9
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10

    .line 2
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/h0;->r(I)Landroidx/datastore/preferences/protobuf/h0;

    move-result-object v0

    iput-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    return-void
.end method

.method public constructor <init>(Landroidx/datastore/preferences/protobuf/h0;)V
    .registers 2

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 7
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/s;->o()V

    return-void
.end method

.method public constructor <init>(Z)V
    .registers 2

    const/4 p1, 0x0

    .line 3
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/h0;->r(I)Landroidx/datastore/preferences/protobuf/h0;

    move-result-object p1

    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/s;-><init>(Landroidx/datastore/preferences/protobuf/h0;)V

    .line 4
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/s;->o()V

    return-void
.end method

.method public static b(Landroidx/datastore/preferences/protobuf/r0$b;ILjava/lang/Object;)I
    .registers 4

    .line 1
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->P(I)I

    .line 4
    move-result p1

    .line 5
    sget-object v0, Landroidx/datastore/preferences/protobuf/r0$b;->l:Landroidx/datastore/preferences/protobuf/r0$b;

    .line 7
    if-ne p0, v0, :cond_a

    .line 9
    mul-int/lit8 p1, p1, 0x2

    .line 11
    :cond_a
    invoke-static {p0, p2}, Landroidx/datastore/preferences/protobuf/s;->c(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)I

    .line 14
    move-result p0

    .line 15
    add-int/2addr p1, p0

    .line 16
    return p1
.end method

.method public static c(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)I
    .registers 3

    .line 1
    sget-object v0, Landroidx/datastore/preferences/protobuf/s$a;->b:[I

    .line 3
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 6
    move-result p0

    .line 7
    aget p0, v0, p0

    .line 9
    packed-switch p0, :pswitch_data_e0

    .line 12
    new-instance p0, Ljava/lang/RuntimeException;

    .line 14
    const-string p1, "There is no way to get here, but the compiler thinks otherwise."

    .line 16
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 19
    throw p0

    .line 20
    :pswitch_13
    check-cast p1, Ljava/lang/Integer;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 25
    move-result p0

    .line 26
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->k(I)I

    .line 29
    move-result p0

    .line 30
    return p0

    .line 31
    :pswitch_1e
    check-cast p1, Ljava/lang/Long;

    .line 33
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 36
    move-result-wide p0

    .line 37
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->M(J)I

    .line 40
    move-result p0

    .line 41
    return p0

    .line 42
    :pswitch_29
    check-cast p1, Ljava/lang/Integer;

    .line 44
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 47
    move-result p0

    .line 48
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->K(I)I

    .line 51
    move-result p0

    .line 52
    return p0

    .line 53
    :pswitch_34
    check-cast p1, Ljava/lang/Long;

    .line 55
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 58
    move-result-wide p0

    .line 59
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->I(J)I

    .line 62
    move-result p0

    .line 63
    return p0

    .line 64
    :pswitch_3f
    check-cast p1, Ljava/lang/Integer;

    .line 66
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 69
    move-result p0

    .line 70
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->G(I)I

    .line 73
    move-result p0

    .line 74
    return p0

    .line 75
    :pswitch_4a
    check-cast p1, Ljava/lang/Integer;

    .line 77
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 80
    move-result p0

    .line 81
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->R(I)I

    .line 84
    move-result p0

    .line 85
    return p0

    .line 86
    :pswitch_55
    instance-of p0, p1, Landroidx/datastore/preferences/protobuf/g;

    .line 88
    if-eqz p0, :cond_60

    .line 90
    check-cast p1, Landroidx/datastore/preferences/protobuf/g;

    .line 92
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->g(Landroidx/datastore/preferences/protobuf/g;)I

    .line 95
    move-result p0

    .line 96
    return p0

    .line 97
    :cond_60
    check-cast p1, [B

    .line 99
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->e([B)I

    .line 102
    move-result p0

    .line 103
    return p0

    .line 104
    :pswitch_67
    instance-of p0, p1, Landroidx/datastore/preferences/protobuf/g;

    .line 106
    if-eqz p0, :cond_72

    .line 108
    check-cast p1, Landroidx/datastore/preferences/protobuf/g;

    .line 110
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->g(Landroidx/datastore/preferences/protobuf/g;)I

    .line 113
    move-result p0

    .line 114
    return p0

    .line 115
    :cond_72
    check-cast p1, Ljava/lang/String;

    .line 117
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->O(Ljava/lang/String;)I

    .line 120
    move-result p0

    .line 121
    return p0

    .line 122
    :pswitch_79
    check-cast p1, Landroidx/datastore/preferences/protobuf/O;

    .line 124
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->A(Landroidx/datastore/preferences/protobuf/O;)I

    .line 127
    move-result p0

    .line 128
    return p0

    .line 129
    :pswitch_80
    check-cast p1, Landroidx/datastore/preferences/protobuf/O;

    .line 131
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/j;->s(Landroidx/datastore/preferences/protobuf/O;)I

    .line 134
    move-result p0

    .line 135
    return p0

    .line 136
    :pswitch_87
    check-cast p1, Ljava/lang/Boolean;

    .line 138
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 141
    move-result p0

    .line 142
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->d(Z)I

    .line 145
    move-result p0

    .line 146
    return p0

    .line 147
    :pswitch_92
    check-cast p1, Ljava/lang/Integer;

    .line 149
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 152
    move-result p0

    .line 153
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->m(I)I

    .line 156
    move-result p0

    .line 157
    return p0

    .line 158
    :pswitch_9d
    check-cast p1, Ljava/lang/Long;

    .line 160
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 163
    move-result-wide p0

    .line 164
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->o(J)I

    .line 167
    move-result p0

    .line 168
    return p0

    .line 169
    :pswitch_a8
    check-cast p1, Ljava/lang/Integer;

    .line 171
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 174
    move-result p0

    .line 175
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->v(I)I

    .line 178
    move-result p0

    .line 179
    return p0

    .line 180
    :pswitch_b3
    check-cast p1, Ljava/lang/Long;

    .line 182
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 185
    move-result-wide p0

    .line 186
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->T(J)I

    .line 189
    move-result p0

    .line 190
    return p0

    .line 191
    :pswitch_be
    check-cast p1, Ljava/lang/Long;

    .line 193
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 196
    move-result-wide p0

    .line 197
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->x(J)I

    .line 200
    move-result p0

    .line 201
    return p0

    .line 202
    :pswitch_c9
    check-cast p1, Ljava/lang/Float;

    .line 204
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 207
    move-result p0

    .line 208
    invoke-static {p0}, Landroidx/datastore/preferences/protobuf/j;->q(F)I

    .line 211
    move-result p0

    .line 212
    return p0

    .line 213
    :pswitch_d4
    check-cast p1, Ljava/lang/Double;

    .line 215
    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    .line 218
    move-result-wide p0

    .line 219
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->i(D)I

    .line 222
    move-result p0

    .line 223
    return p0

    .line 224
    nop

    .line 225
    :pswitch_data_e0
    .packed-switch 0x1
        :pswitch_d4
        :pswitch_c9
        :pswitch_be
        :pswitch_b3
        :pswitch_a8
        :pswitch_9d
        :pswitch_92
        :pswitch_87
        :pswitch_80
        :pswitch_79
        :pswitch_67
        :pswitch_55
        :pswitch_4a
        :pswitch_3f
        :pswitch_34
        :pswitch_29
        :pswitch_1e
        :pswitch_13
    .end packed-switch
.end method

.method public static d(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)I
    .registers 5

    .line 1
    invoke-interface {p0}, Landroidx/datastore/preferences/protobuf/s$b;->getLiteType()Landroidx/datastore/preferences/protobuf/r0$b;

    .line 4
    move-result-object v0

    .line 5
    invoke-interface {p0}, Landroidx/datastore/preferences/protobuf/s$b;->getNumber()I

    .line 8
    move-result v1

    .line 9
    invoke-interface {p0}, Landroidx/datastore/preferences/protobuf/s$b;->isRepeated()Z

    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_4d

    .line 15
    invoke-interface {p0}, Landroidx/datastore/preferences/protobuf/s$b;->isPacked()Z

    .line 18
    move-result p0

    .line 19
    const/4 v2, 0x0

    .line 20
    if-eqz p0, :cond_36

    .line 22
    check-cast p1, Ljava/util/List;

    .line 24
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 27
    move-result-object p0

    .line 28
    :goto_1b
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_2b

    .line 34
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    move-result-object p1

    .line 38
    invoke-static {v0, p1}, Landroidx/datastore/preferences/protobuf/s;->c(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)I

    .line 41
    move-result p1

    .line 42
    add-int/2addr v2, p1

    .line 43
    goto :goto_1b

    .line 44
    :cond_2b
    invoke-static {v1}, Landroidx/datastore/preferences/protobuf/j;->P(I)I

    .line 47
    move-result p0

    .line 48
    add-int/2addr p0, v2

    .line 49
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/j;->E(I)I

    .line 52
    move-result p1

    .line 53
    add-int/2addr p0, p1

    .line 54
    return p0

    .line 55
    :cond_36
    check-cast p1, Ljava/util/List;

    .line 57
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 60
    move-result-object p0

    .line 61
    :goto_3c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    move-result p1

    .line 65
    if-eqz p1, :cond_4c

    .line 67
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 70
    move-result-object p1

    .line 71
    invoke-static {v0, v1, p1}, Landroidx/datastore/preferences/protobuf/s;->b(Landroidx/datastore/preferences/protobuf/r0$b;ILjava/lang/Object;)I

    .line 74
    move-result p1

    .line 75
    add-int/2addr v2, p1

    .line 76
    goto :goto_3c

    .line 77
    :cond_4c
    return v2

    .line 78
    :cond_4d
    invoke-static {v0, v1, p1}, Landroidx/datastore/preferences/protobuf/s;->b(Landroidx/datastore/preferences/protobuf/r0$b;ILjava/lang/Object;)I

    .line 81
    move-result p0

    .line 82
    return p0
.end method

.method public static i(Landroidx/datastore/preferences/protobuf/r0$b;Z)I
    .registers 2

    .line 1
    if-eqz p1, :cond_4

    .line 3
    const/4 p0, 0x2

    .line 4
    return p0

    .line 5
    :cond_4
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/r0$b;->b()I

    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public static l(Ljava/util/Map$Entry;)Z
    .registers 1

    .line 1
    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 4
    move-result-object p0

    .line 5
    invoke-static {p0}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 8
    const/4 p0, 0x0

    .line 9
    throw p0
.end method

.method public static m(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)Z
    .registers 4

    .line 1
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/y;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    sget-object v0, Landroidx/datastore/preferences/protobuf/s$a;->a:[I

    .line 6
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/r0$b;->a()Landroidx/datastore/preferences/protobuf/r0$c;

    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 13
    move-result p0

    .line 14
    aget p0, v0, p0

    .line 16
    const/4 v0, 0x1

    .line 17
    const/4 v1, 0x0

    .line 18
    packed-switch p0, :pswitch_data_38

    .line 21
    return v1

    .line 22
    :pswitch_15
    instance-of p0, p1, Landroidx/datastore/preferences/protobuf/O;

    .line 24
    return p0

    .line 25
    :pswitch_18
    instance-of p0, p1, Ljava/lang/Integer;

    .line 27
    return p0

    .line 28
    :pswitch_1b
    instance-of p0, p1, Landroidx/datastore/preferences/protobuf/g;

    .line 30
    if-nez p0, :cond_25

    .line 32
    instance-of p0, p1, [B

    .line 34
    if-eqz p0, :cond_24

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    move v0, v1

    .line 38
    :cond_25
    :goto_25
    return v0

    .line 39
    :pswitch_26
    instance-of p0, p1, Ljava/lang/String;

    .line 41
    return p0

    .line 42
    :pswitch_29
    instance-of p0, p1, Ljava/lang/Boolean;

    .line 44
    return p0

    .line 45
    :pswitch_2c
    instance-of p0, p1, Ljava/lang/Double;

    .line 47
    return p0

    .line 48
    :pswitch_2f
    instance-of p0, p1, Ljava/lang/Float;

    .line 50
    return p0

    .line 51
    :pswitch_32
    instance-of p0, p1, Ljava/lang/Long;

    .line 53
    return p0

    .line 54
    :pswitch_35
    instance-of p0, p1, Ljava/lang/Integer;

    .line 56
    return p0

    .line 57
    :pswitch_data_38
    .packed-switch 0x1
        :pswitch_35
        :pswitch_32
        :pswitch_2f
        :pswitch_2c
        :pswitch_29
        :pswitch_26
        :pswitch_1b
        :pswitch_18
        :pswitch_15
    .end packed-switch
.end method

.method public static r()Landroidx/datastore/preferences/protobuf/s;
    .registers 1

    .line 1
    new-instance v0, Landroidx/datastore/preferences/protobuf/s;

    .line 3
    invoke-direct {v0}, Landroidx/datastore/preferences/protobuf/s;-><init>()V

    .line 6
    return-object v0
.end method

.method public static u(Landroidx/datastore/preferences/protobuf/j;Landroidx/datastore/preferences/protobuf/r0$b;ILjava/lang/Object;)V
    .registers 5

    .line 1
    sget-object v0, Landroidx/datastore/preferences/protobuf/r0$b;->l:Landroidx/datastore/preferences/protobuf/r0$b;

    .line 3
    if-ne p1, v0, :cond_a

    .line 5
    check-cast p3, Landroidx/datastore/preferences/protobuf/O;

    .line 7
    invoke-virtual {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/j;->r0(ILandroidx/datastore/preferences/protobuf/O;)V

    .line 10
    goto :goto_15

    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    invoke-static {p1, v0}, Landroidx/datastore/preferences/protobuf/s;->i(Landroidx/datastore/preferences/protobuf/r0$b;Z)I

    .line 15
    move-result v0

    .line 16
    invoke-virtual {p0, p2, v0}, Landroidx/datastore/preferences/protobuf/j;->N0(II)V

    .line 19
    invoke-static {p0, p1, p3}, Landroidx/datastore/preferences/protobuf/s;->v(Landroidx/datastore/preferences/protobuf/j;Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)V

    .line 22
    :goto_15
    return-void
.end method

.method public static v(Landroidx/datastore/preferences/protobuf/j;Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)V
    .registers 4

    .line 1
    sget-object v0, Landroidx/datastore/preferences/protobuf/s$a;->b:[I

    .line 3
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 6
    move-result p1

    .line 7
    aget p1, v0, p1

    .line 9
    packed-switch p1, :pswitch_data_ce

    .line 12
    goto/16 :goto_cc

    .line 14
    :pswitch_d
    check-cast p2, Ljava/lang/Integer;

    .line 16
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 19
    move-result p1

    .line 20
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->k0(I)V

    .line 23
    goto/16 :goto_cc

    .line 25
    :pswitch_18
    check-cast p2, Ljava/lang/Long;

    .line 27
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 30
    move-result-wide p1

    .line 31
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->K0(J)V

    .line 34
    goto/16 :goto_cc

    .line 36
    :pswitch_23
    check-cast p2, Ljava/lang/Integer;

    .line 38
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 41
    move-result p1

    .line 42
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->I0(I)V

    .line 45
    goto/16 :goto_cc

    .line 47
    :pswitch_2e
    check-cast p2, Ljava/lang/Long;

    .line 49
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 52
    move-result-wide p1

    .line 53
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->G0(J)V

    .line 56
    goto/16 :goto_cc

    .line 58
    :pswitch_39
    check-cast p2, Ljava/lang/Integer;

    .line 60
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 63
    move-result p1

    .line 64
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->E0(I)V

    .line 67
    goto/16 :goto_cc

    .line 69
    :pswitch_44
    check-cast p2, Ljava/lang/Integer;

    .line 71
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 74
    move-result p1

    .line 75
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->P0(I)V

    .line 78
    goto/16 :goto_cc

    .line 80
    :pswitch_4f
    instance-of p1, p2, Landroidx/datastore/preferences/protobuf/g;

    .line 82
    if-eqz p1, :cond_5a

    .line 84
    check-cast p2, Landroidx/datastore/preferences/protobuf/g;

    .line 86
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->g0(Landroidx/datastore/preferences/protobuf/g;)V

    .line 89
    goto/16 :goto_cc

    .line 91
    :cond_5a
    check-cast p2, [B

    .line 93
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->d0([B)V

    .line 96
    goto/16 :goto_cc

    .line 98
    :pswitch_61
    instance-of p1, p2, Landroidx/datastore/preferences/protobuf/g;

    .line 100
    if-eqz p1, :cond_6b

    .line 102
    check-cast p2, Landroidx/datastore/preferences/protobuf/g;

    .line 104
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->g0(Landroidx/datastore/preferences/protobuf/g;)V

    .line 107
    goto :goto_cc

    .line 108
    :cond_6b
    check-cast p2, Ljava/lang/String;

    .line 110
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->M0(Ljava/lang/String;)V

    .line 113
    goto :goto_cc

    .line 114
    :pswitch_71
    check-cast p2, Landroidx/datastore/preferences/protobuf/O;

    .line 116
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->A0(Landroidx/datastore/preferences/protobuf/O;)V

    .line 119
    goto :goto_cc

    .line 120
    :pswitch_77
    check-cast p2, Landroidx/datastore/preferences/protobuf/O;

    .line 122
    invoke-virtual {p0, p2}, Landroidx/datastore/preferences/protobuf/j;->t0(Landroidx/datastore/preferences/protobuf/O;)V

    .line 125
    goto :goto_cc

    .line 126
    :pswitch_7d
    check-cast p2, Ljava/lang/Boolean;

    .line 128
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 131
    move-result p1

    .line 132
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->c0(Z)V

    .line 135
    goto :goto_cc

    .line 136
    :pswitch_87
    check-cast p2, Ljava/lang/Integer;

    .line 138
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 141
    move-result p1

    .line 142
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->m0(I)V

    .line 145
    goto :goto_cc

    .line 146
    :pswitch_91
    check-cast p2, Ljava/lang/Long;

    .line 148
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 151
    move-result-wide p1

    .line 152
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->o0(J)V

    .line 155
    goto :goto_cc

    .line 156
    :pswitch_9b
    check-cast p2, Ljava/lang/Integer;

    .line 158
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 161
    move-result p1

    .line 162
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->w0(I)V

    .line 165
    goto :goto_cc

    .line 166
    :pswitch_a5
    check-cast p2, Ljava/lang/Long;

    .line 168
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 171
    move-result-wide p1

    .line 172
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->R0(J)V

    .line 175
    goto :goto_cc

    .line 176
    :pswitch_af
    check-cast p2, Ljava/lang/Long;

    .line 178
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 181
    move-result-wide p1

    .line 182
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->y0(J)V

    .line 185
    goto :goto_cc

    .line 186
    :pswitch_b9
    check-cast p2, Ljava/lang/Float;

    .line 188
    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    .line 191
    move-result p1

    .line 192
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/j;->q0(F)V

    .line 195
    goto :goto_cc

    .line 196
    :pswitch_c3
    check-cast p2, Ljava/lang/Double;

    .line 198
    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    .line 201
    move-result-wide p1

    .line 202
    invoke-virtual {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/j;->i0(D)V

    .line 205
    :goto_cc
    return-void

    .line 206
    nop

    .line 207
    :pswitch_data_ce
    .packed-switch 0x1
        :pswitch_c3
        :pswitch_b9
        :pswitch_af
        :pswitch_a5
        :pswitch_9b
        :pswitch_91
        :pswitch_87
        :pswitch_7d
        :pswitch_77
        :pswitch_71
        :pswitch_61
        :pswitch_4f
        :pswitch_44
        :pswitch_39
        :pswitch_2e
        :pswitch_23
        :pswitch_18
        :pswitch_d
    .end packed-switch
.end method


# virtual methods
.method public a()Landroidx/datastore/preferences/protobuf/s;
    .registers 6

    .line 1
    invoke-static {}, Landroidx/datastore/preferences/protobuf/s;->r()Landroidx/datastore/preferences/protobuf/s;

    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    :goto_5
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 8
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/h0;->l()I

    .line 11
    move-result v2

    .line 12
    const/4 v3, 0x0

    .line 13
    if-ge v1, v2, :cond_25

    .line 15
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 17
    invoke-virtual {v2, v1}, Landroidx/datastore/preferences/protobuf/h0;->k(I)Ljava/util/Map$Entry;

    .line 20
    move-result-object v2

    .line 21
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 24
    move-result-object v4

    .line 25
    invoke-static {v4}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 28
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {v0, v3, v2}, Landroidx/datastore/preferences/protobuf/s;->s(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)V

    .line 35
    add-int/lit8 v1, v1, 0x1

    .line 37
    goto :goto_5

    .line 38
    :cond_25
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 40
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h0;->n()Ljava/lang/Iterable;

    .line 43
    move-result-object v1

    .line 44
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 47
    move-result-object v1

    .line 48
    :goto_2f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_4a

    .line 54
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 57
    move-result-object v2

    .line 58
    check-cast v2, Ljava/util/Map$Entry;

    .line 60
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 63
    move-result-object v4

    .line 64
    invoke-static {v4}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 67
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v0, v3, v2}, Landroidx/datastore/preferences/protobuf/s;->s(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)V

    .line 74
    goto :goto_2f

    .line 75
    :cond_4a
    iget-boolean v1, p0, Landroidx/datastore/preferences/protobuf/s;->c:Z

    .line 77
    iput-boolean v1, v0, Landroidx/datastore/preferences/protobuf/s;->c:Z

    .line 79
    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/s;->a()Landroidx/datastore/preferences/protobuf/s;

    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public e()Ljava/util/Iterator;
    .registers 3

    .line 1
    iget-boolean v0, p0, Landroidx/datastore/preferences/protobuf/s;->c:Z

    .line 3
    if-eqz v0, :cond_14

    .line 5
    new-instance v0, Landroidx/datastore/preferences/protobuf/B;

    .line 7
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 9
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h0;->i()Ljava/util/Set;

    .line 12
    move-result-object v1

    .line 13
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1}, Landroidx/datastore/preferences/protobuf/B;-><init>(Ljava/util/Iterator;)V

    .line 20
    return-object v0

    .line 21
    :cond_14
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 23
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->i()Ljava/util/Set;

    .line 26
    move-result-object v0

    .line 27
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    if-ne p0, p1, :cond_4

    .line 3
    const/4 p1, 0x1

    .line 4
    return p1

    .line 5
    :cond_4
    instance-of v0, p1, Landroidx/datastore/preferences/protobuf/s;

    .line 7
    if-nez v0, :cond_a

    .line 9
    const/4 p1, 0x0

    .line 10
    return p1

    .line 11
    :cond_a
    check-cast p1, Landroidx/datastore/preferences/protobuf/s;

    .line 13
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 15
    iget-object p1, p1, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 17
    invoke-virtual {v0, p1}, Landroidx/datastore/preferences/protobuf/h0;->equals(Ljava/lang/Object;)Z

    .line 20
    move-result p1

    .line 21
    return p1
.end method

.method public f()I
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_2
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 5
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/h0;->l()I

    .line 8
    move-result v2

    .line 9
    if-ge v0, v2, :cond_18

    .line 11
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 13
    invoke-virtual {v2, v0}, Landroidx/datastore/preferences/protobuf/h0;->k(I)Ljava/util/Map$Entry;

    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {p0, v2}, Landroidx/datastore/preferences/protobuf/s;->g(Ljava/util/Map$Entry;)I

    .line 20
    move-result v2

    .line 21
    add-int/2addr v1, v2

    .line 22
    add-int/lit8 v0, v0, 0x1

    .line 24
    goto :goto_2

    .line 25
    :cond_18
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 27
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->n()Ljava/lang/Iterable;

    .line 30
    move-result-object v0

    .line 31
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 34
    move-result-object v0

    .line 35
    :goto_22
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_34

    .line 41
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    move-result-object v2

    .line 45
    check-cast v2, Ljava/util/Map$Entry;

    .line 47
    invoke-virtual {p0, v2}, Landroidx/datastore/preferences/protobuf/s;->g(Ljava/util/Map$Entry;)I

    .line 50
    move-result v2

    .line 51
    add-int/2addr v1, v2

    .line 52
    goto :goto_22

    .line 53
    :cond_34
    return v1
.end method

.method public final g(Ljava/util/Map$Entry;)I
    .registers 3

    .line 1
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 8
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 11
    const/4 p1, 0x0

    .line 12
    throw p1
.end method

.method public h()I
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_2
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 5
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/h0;->l()I

    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x0

    .line 10
    if-ge v0, v2, :cond_24

    .line 12
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 14
    invoke-virtual {v2, v0}, Landroidx/datastore/preferences/protobuf/h0;->k(I)Ljava/util/Map$Entry;

    .line 17
    move-result-object v2

    .line 18
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 21
    move-result-object v4

    .line 22
    invoke-static {v4}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 25
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 28
    move-result-object v2

    .line 29
    invoke-static {v3, v2}, Landroidx/datastore/preferences/protobuf/s;->d(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)I

    .line 32
    move-result v2

    .line 33
    add-int/2addr v1, v2

    .line 34
    add-int/lit8 v0, v0, 0x1

    .line 36
    goto :goto_2

    .line 37
    :cond_24
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 39
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->n()Ljava/lang/Iterable;

    .line 42
    move-result-object v0

    .line 43
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 46
    move-result-object v0

    .line 47
    :goto_2e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_4b

    .line 53
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    move-result-object v2

    .line 57
    check-cast v2, Ljava/util/Map$Entry;

    .line 59
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 62
    move-result-object v4

    .line 63
    invoke-static {v4}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 66
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 69
    move-result-object v2

    .line 70
    invoke-static {v3, v2}, Landroidx/datastore/preferences/protobuf/s;->d(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)I

    .line 73
    move-result v2

    .line 74
    add-int/2addr v1, v2

    .line 75
    goto :goto_2e

    .line 76
    :cond_4b
    return v1
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 3
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->hashCode()I

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public j()Z
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public k()Z
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_2
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 5
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/h0;->l()I

    .line 8
    move-result v2

    .line 9
    if-ge v1, v2, :cond_1a

    .line 11
    iget-object v2, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 13
    invoke-virtual {v2, v1}, Landroidx/datastore/preferences/protobuf/h0;->k(I)Ljava/util/Map$Entry;

    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/s;->l(Ljava/util/Map$Entry;)Z

    .line 20
    move-result v2

    .line 21
    if-nez v2, :cond_17

    .line 23
    return v0

    .line 24
    :cond_17
    add-int/lit8 v1, v1, 0x1

    .line 26
    goto :goto_2

    .line 27
    :cond_1a
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 29
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h0;->n()Ljava/lang/Iterable;

    .line 32
    move-result-object v1

    .line 33
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    move-result-object v1

    .line 37
    :cond_24
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_37

    .line 43
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    move-result-object v2

    .line 47
    check-cast v2, Ljava/util/Map$Entry;

    .line 49
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/s;->l(Ljava/util/Map$Entry;)Z

    .line 52
    move-result v2

    .line 53
    if-nez v2, :cond_24

    .line 55
    return v0

    .line 56
    :cond_37
    const/4 v0, 0x1

    .line 57
    return v0
.end method

.method public n()Ljava/util/Iterator;
    .registers 3

    .line 1
    iget-boolean v0, p0, Landroidx/datastore/preferences/protobuf/s;->c:Z

    .line 3
    if-eqz v0, :cond_14

    .line 5
    new-instance v0, Landroidx/datastore/preferences/protobuf/B;

    .line 7
    iget-object v1, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 9
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h0;->entrySet()Ljava/util/Set;

    .line 12
    move-result-object v1

    .line 13
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1}, Landroidx/datastore/preferences/protobuf/B;-><init>(Ljava/util/Iterator;)V

    .line 20
    return-object v0

    .line 21
    :cond_14
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 23
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->entrySet()Ljava/util/Set;

    .line 26
    move-result-object v0

    .line 27
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method

.method public o()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Landroidx/datastore/preferences/protobuf/s;->b:Z

    .line 3
    if-eqz v0, :cond_5

    .line 5
    return-void

    .line 6
    :cond_5
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 8
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/h0;->q()V

    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Landroidx/datastore/preferences/protobuf/s;->b:Z

    .line 14
    return-void
.end method

.method public p(Landroidx/datastore/preferences/protobuf/s;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    iget-object v1, p1, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 4
    invoke-virtual {v1}, Landroidx/datastore/preferences/protobuf/h0;->l()I

    .line 7
    move-result v1

    .line 8
    if-ge v0, v1, :cond_15

    .line 10
    iget-object v1, p1, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 12
    invoke-virtual {v1, v0}, Landroidx/datastore/preferences/protobuf/h0;->k(I)Ljava/util/Map$Entry;

    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {p0, v1}, Landroidx/datastore/preferences/protobuf/s;->q(Ljava/util/Map$Entry;)V

    .line 19
    add-int/lit8 v0, v0, 0x1

    .line 21
    goto :goto_1

    .line 22
    :cond_15
    iget-object p1, p1, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 24
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/h0;->n()Ljava/lang/Iterable;

    .line 27
    move-result-object p1

    .line 28
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 31
    move-result-object p1

    .line 32
    :goto_1f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2f

    .line 38
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    move-result-object v0

    .line 42
    check-cast v0, Ljava/util/Map$Entry;

    .line 44
    invoke-virtual {p0, v0}, Landroidx/datastore/preferences/protobuf/s;->q(Ljava/util/Map$Entry;)V

    .line 47
    goto :goto_1f

    .line 48
    :cond_2f
    return-void
.end method

.method public final q(Ljava/util/Map$Entry;)V
    .registers 3

    .line 1
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 8
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 11
    const/4 p1, 0x0

    .line 12
    throw p1
.end method

.method public s(Landroidx/datastore/preferences/protobuf/s$b;Ljava/lang/Object;)V
    .registers 6

    .line 1
    invoke-interface {p1}, Landroidx/datastore/preferences/protobuf/s$b;->isRepeated()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_34

    .line 7
    instance-of v0, p2, Ljava/util/List;

    .line 9
    if-eqz v0, :cond_2c

    .line 11
    new-instance v0, Ljava/util/ArrayList;

    .line 13
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 16
    check-cast p2, Ljava/util/List;

    .line 18
    invoke-interface {v0, p2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 21
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 24
    move-result-object p2

    .line 25
    :goto_18
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_2a

    .line 31
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    move-result-object v1

    .line 35
    invoke-interface {p1}, Landroidx/datastore/preferences/protobuf/s$b;->getLiteType()Landroidx/datastore/preferences/protobuf/r0$b;

    .line 38
    move-result-object v2

    .line 39
    invoke-virtual {p0, v2, v1}, Landroidx/datastore/preferences/protobuf/s;->t(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)V

    .line 42
    goto :goto_18

    .line 43
    :cond_2a
    move-object p2, v0

    .line 44
    goto :goto_3b

    .line 45
    :cond_2c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 47
    const-string p2, "Wrong object type used with protocol message reflection."

    .line 49
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 52
    throw p1

    .line 53
    :cond_34
    invoke-interface {p1}, Landroidx/datastore/preferences/protobuf/s$b;->getLiteType()Landroidx/datastore/preferences/protobuf/r0$b;

    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {p0, v0, p2}, Landroidx/datastore/preferences/protobuf/s;->t(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)V

    .line 60
    :goto_3b
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/s;->a:Landroidx/datastore/preferences/protobuf/h0;

    .line 62
    invoke-virtual {v0, p1, p2}, Landroidx/datastore/preferences/protobuf/h0;->s(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    return-void
.end method

.method public final t(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)V
    .registers 3

    .line 1
    invoke-static {p1, p2}, Landroidx/datastore/preferences/protobuf/s;->m(Landroidx/datastore/preferences/protobuf/r0$b;Ljava/lang/Object;)Z

    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_7

    .line 7
    return-void

    .line 8
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 10
    const-string p2, "Wrong object type used with protocol message reflection."

    .line 12
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 15
    throw p1
.end method
