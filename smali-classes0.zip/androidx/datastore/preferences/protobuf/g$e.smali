.class public final Landroidx/datastore/preferences/protobuf/g$e;
.super Landroidx/datastore/preferences/protobuf/g$i;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/datastore/preferences/protobuf/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field public final f:I

.field public final g:I


# direct methods
.method public constructor <init>([BII)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Landroidx/datastore/preferences/protobuf/g$i;-><init>([B)V

    .line 4
    add-int v0, p2, p3

    .line 6
    array-length p1, p1

    .line 7
    invoke-static {p2, v0, p1}, Landroidx/datastore/preferences/protobuf/g;->d(III)I

    .line 10
    iput p2, p0, Landroidx/datastore/preferences/protobuf/g$e;->f:I

    .line 12
    iput p3, p0, Landroidx/datastore/preferences/protobuf/g$e;->g:I

    .line 14
    return-void
.end method


# virtual methods
.method public b(I)B
    .registers 4

    .line 1
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/g$e;->size()I

    .line 4
    move-result v0

    .line 5
    invoke-static {p1, v0}, Landroidx/datastore/preferences/protobuf/g;->c(II)V

    .line 8
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/g$i;->e:[B

    .line 10
    iget v1, p0, Landroidx/datastore/preferences/protobuf/g$e;->f:I

    .line 12
    add-int/2addr v1, p1

    .line 13
    aget-byte p1, v0, v1

    .line 15
    return p1
.end method

.method public h(I)B
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/g$i;->e:[B

    .line 3
    iget v1, p0, Landroidx/datastore/preferences/protobuf/g$e;->f:I

    .line 5
    add-int/2addr v1, p1

    .line 6
    aget-byte p1, v0, v1

    .line 8
    return p1
.end method

.method public size()I
    .registers 2

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/g$e;->g:I

    .line 3
    return v0
.end method

.method public x()I
    .registers 2

    .line 1
    iget v0, p0, Landroidx/datastore/preferences/protobuf/g$e;->f:I

    .line 3
    return v0
.end method
