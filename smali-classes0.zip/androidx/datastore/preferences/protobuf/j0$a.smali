.class public final Landroidx/datastore/preferences/protobuf/j0$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/datastore/preferences/protobuf/j0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/datastore/preferences/protobuf/j0;->a(Landroidx/datastore/preferences/protobuf/g;)Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroidx/datastore/preferences/protobuf/g;


# direct methods
.method public constructor <init>(Landroidx/datastore/preferences/protobuf/g;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/datastore/preferences/protobuf/j0$a;->a:Landroidx/datastore/preferences/protobuf/g;

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public byteAt(I)B
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/j0$a;->a:Landroidx/datastore/preferences/protobuf/g;

    .line 3
    invoke-virtual {v0, p1}, Landroidx/datastore/preferences/protobuf/g;->b(I)B

    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public size()I
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/datastore/preferences/protobuf/j0$a;->a:Landroidx/datastore/preferences/protobuf/g;

    .line 3
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/g;->size()I

    .line 6
    move-result v0

    .line 7
    return v0
.end method
