.class public final Landroidx/datastore/preferences/protobuf/q0$e;
.super Landroidx/datastore/preferences/protobuf/q0$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/datastore/preferences/protobuf/q0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroidx/datastore/preferences/protobuf/q0$b;-><init>()V

    .line 4
    return-void
.end method

.method public static e()Z
    .registers 1

    .line 1
    invoke-static {}, Landroidx/datastore/preferences/protobuf/p0;->C()Z

    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_e

    .line 7
    invoke-static {}, Landroidx/datastore/preferences/protobuf/p0;->D()Z

    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_e

    .line 13
    const/4 v0, 0x1

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    return v0
.end method

.method public static f([BJI)I
    .registers 14

    .line 1
    invoke-static {p0, p1, p2, p3}, Landroidx/datastore/preferences/protobuf/q0$e;->g([BJI)I

    .line 4
    move-result v0

    .line 5
    sub-int/2addr p3, v0

    .line 6
    int-to-long v0, v0

    .line 7
    add-long/2addr p1, v0

    .line 8
    :cond_7
    :goto_7
    const/4 v0, 0x0

    .line 9
    move v1, v0

    .line 10
    :goto_9
    const-wide/16 v2, 0x1

    .line 12
    if-lez p3, :cond_1a

    .line 14
    add-long v4, p1, v2

    .line 16
    invoke-static {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 19
    move-result v1

    .line 20
    if-ltz v1, :cond_19

    .line 22
    add-int/lit8 p3, p3, -0x1

    .line 24
    move-wide p1, v4

    .line 25
    goto :goto_9

    .line 26
    :cond_19
    move-wide p1, v4

    .line 27
    :cond_1a
    if-nez p3, :cond_1d

    .line 29
    return v0

    .line 30
    :cond_1d
    add-int/lit8 v0, p3, -0x1

    .line 32
    const/16 v4, -0x20

    .line 34
    const/4 v5, -0x1

    .line 35
    const/16 v6, -0x41

    .line 37
    if-ge v1, v4, :cond_3a

    .line 39
    if-nez v0, :cond_29

    .line 41
    return v1

    .line 42
    :cond_29
    add-int/lit8 p3, p3, -0x2

    .line 44
    const/16 v0, -0x3e

    .line 46
    if-lt v1, v0, :cond_39

    .line 48
    add-long/2addr v2, p1

    .line 49
    invoke-static {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 52
    move-result p1

    .line 53
    if-le p1, v6, :cond_37

    .line 55
    goto :goto_39

    .line 56
    :cond_37
    move-wide p1, v2

    .line 57
    goto :goto_7

    .line 58
    :cond_39
    :goto_39
    return v5

    .line 59
    :cond_3a
    const/16 v7, -0x10

    .line 61
    const-wide/16 v8, 0x2

    .line 63
    if-ge v1, v7, :cond_65

    .line 65
    const/4 v7, 0x2

    .line 66
    if-ge v0, v7, :cond_48

    .line 68
    invoke-static {p0, v1, p1, p2, v0}, Landroidx/datastore/preferences/protobuf/q0$e;->h([BIJI)I

    .line 71
    move-result p0

    .line 72
    return p0

    .line 73
    :cond_48
    add-int/lit8 p3, p3, -0x3

    .line 75
    add-long/2addr v2, p1

    .line 76
    invoke-static {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 79
    move-result v0

    .line 80
    if-gt v0, v6, :cond_64

    .line 82
    const/16 v7, -0x60

    .line 84
    if-ne v1, v4, :cond_57

    .line 86
    if-lt v0, v7, :cond_64

    .line 88
    :cond_57
    const/16 v4, -0x13

    .line 90
    if-ne v1, v4, :cond_5d

    .line 92
    if-ge v0, v7, :cond_64

    .line 94
    :cond_5d
    add-long/2addr p1, v8

    .line 95
    invoke-static {p0, v2, v3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 98
    move-result v0

    .line 99
    if-le v0, v6, :cond_7

    .line 101
    :cond_64
    return v5

    .line 102
    :cond_65
    const/4 v4, 0x3

    .line 103
    if-ge v0, v4, :cond_6d

    .line 105
    invoke-static {p0, v1, p1, p2, v0}, Landroidx/datastore/preferences/protobuf/q0$e;->h([BIJI)I

    .line 108
    move-result p0

    .line 109
    return p0

    .line 110
    :cond_6d
    add-int/lit8 p3, p3, -0x4

    .line 112
    add-long/2addr v2, p1

    .line 113
    invoke-static {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 116
    move-result v0

    .line 117
    if-gt v0, v6, :cond_8f

    .line 119
    shl-int/lit8 v1, v1, 0x1c

    .line 121
    add-int/lit8 v0, v0, 0x70

    .line 123
    add-int/2addr v1, v0

    .line 124
    shr-int/lit8 v0, v1, 0x1e

    .line 126
    if-nez v0, :cond_8f

    .line 128
    add-long/2addr v8, p1

    .line 129
    invoke-static {p0, v2, v3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 132
    move-result v0

    .line 133
    if-gt v0, v6, :cond_8f

    .line 135
    const-wide/16 v0, 0x3

    .line 137
    add-long/2addr p1, v0

    .line 138
    invoke-static {p0, v8, v9}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 141
    move-result v0

    .line 142
    if-le v0, v6, :cond_7

    .line 144
    :cond_8f
    return v5
.end method

.method public static g([BJI)I
    .registers 8

    .line 1
    const/16 v0, 0x10

    .line 3
    const/4 v1, 0x0

    .line 4
    if-ge p3, v0, :cond_6

    .line 6
    return v1

    .line 7
    :cond_6
    :goto_6
    if-ge v1, p3, :cond_16

    .line 9
    const-wide/16 v2, 0x1

    .line 11
    add-long/2addr v2, p1

    .line 12
    invoke-static {p0, p1, p2}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 15
    move-result p1

    .line 16
    if-gez p1, :cond_12

    .line 18
    return v1

    .line 19
    :cond_12
    add-int/lit8 v1, v1, 0x1

    .line 21
    move-wide p1, v2

    .line 22
    goto :goto_6

    .line 23
    :cond_16
    return p3
.end method

.method public static h([BIJI)I
    .registers 7

    .line 1
    if-eqz p4, :cond_27

    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p4, v0, :cond_1e

    .line 6
    const/4 v0, 0x2

    .line 7
    if-ne p4, v0, :cond_18

    .line 9
    invoke-static {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 12
    move-result p4

    .line 13
    const-wide/16 v0, 0x1

    .line 15
    add-long/2addr p2, v0

    .line 16
    invoke-static {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 19
    move-result p0

    .line 20
    invoke-static {p1, p4, p0}, Landroidx/datastore/preferences/protobuf/q0;->b(III)I

    .line 23
    move-result p0

    .line 24
    return p0

    .line 25
    :cond_18
    new-instance p0, Ljava/lang/AssertionError;

    .line 27
    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    .line 30
    throw p0

    .line 31
    :cond_1e
    invoke-static {p0, p2, p3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 34
    move-result p0

    .line 35
    invoke-static {p1, p0}, Landroidx/datastore/preferences/protobuf/q0;->a(II)I

    .line 38
    move-result p0

    .line 39
    return p0

    .line 40
    :cond_27
    invoke-static {p1}, Landroidx/datastore/preferences/protobuf/q0;->d(I)I

    .line 43
    move-result p0

    .line 44
    return p0
.end method


# virtual methods
.method public a([BII)Ljava/lang/String;
    .registers 13

    .line 1
    or-int v0, p2, p3

    .line 3
    array-length v1, p1

    .line 4
    sub-int/2addr v1, p2

    .line 5
    sub-int/2addr v1, p3

    .line 6
    or-int/2addr v0, v1

    .line 7
    if-ltz v0, :cond_c3

    .line 9
    add-int v0, p2, p3

    .line 11
    new-array p3, p3, [C

    .line 13
    const/4 v7, 0x0

    .line 14
    move v1, v7

    .line 15
    :goto_e
    if-ge p2, v0, :cond_25

    .line 17
    int-to-long v2, p2

    .line 18
    invoke-static {p1, v2, v3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 21
    move-result v2

    .line 22
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/q0$a;->b(B)Z

    .line 25
    move-result v3

    .line 26
    if-nez v3, :cond_1c

    .line 28
    goto :goto_25

    .line 29
    :cond_1c
    add-int/lit8 p2, p2, 0x1

    .line 31
    add-int/lit8 v3, v1, 0x1

    .line 33
    invoke-static {v2, p3, v1}, Landroidx/datastore/preferences/protobuf/q0$a;->c(B[CI)V

    .line 36
    move v1, v3

    .line 37
    goto :goto_e

    .line 38
    :cond_25
    :goto_25
    move v8, v1

    .line 39
    :goto_26
    if-ge p2, v0, :cond_bd

    .line 41
    add-int/lit8 v1, p2, 0x1

    .line 43
    int-to-long v2, p2

    .line 44
    invoke-static {p1, v2, v3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 47
    move-result v2

    .line 48
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/q0$a;->b(B)Z

    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_54

    .line 54
    add-int/lit8 p2, v8, 0x1

    .line 56
    invoke-static {v2, p3, v8}, Landroidx/datastore/preferences/protobuf/q0$a;->c(B[CI)V

    .line 59
    :goto_3a
    if-ge v1, v0, :cond_51

    .line 61
    int-to-long v2, v1

    .line 62
    invoke-static {p1, v2, v3}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 65
    move-result v2

    .line 66
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/q0$a;->b(B)Z

    .line 69
    move-result v3

    .line 70
    if-nez v3, :cond_48

    .line 72
    goto :goto_51

    .line 73
    :cond_48
    add-int/lit8 v1, v1, 0x1

    .line 75
    add-int/lit8 v3, p2, 0x1

    .line 77
    invoke-static {v2, p3, p2}, Landroidx/datastore/preferences/protobuf/q0$a;->c(B[CI)V

    .line 80
    move p2, v3

    .line 81
    goto :goto_3a

    .line 82
    :cond_51
    :goto_51
    move v8, p2

    .line 83
    move p2, v1

    .line 84
    goto :goto_26

    .line 85
    :cond_54
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/q0$a;->d(B)Z

    .line 88
    move-result v3

    .line 89
    if-eqz v3, :cond_6f

    .line 91
    if-ge v1, v0, :cond_6a

    .line 93
    add-int/lit8 p2, p2, 0x2

    .line 95
    int-to-long v3, v1

    .line 96
    invoke-static {p1, v3, v4}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 99
    move-result v1

    .line 100
    add-int/lit8 v3, v8, 0x1

    .line 102
    invoke-static {v2, v1, p3, v8}, Landroidx/datastore/preferences/protobuf/q0$a;->e(BB[CI)V

    .line 105
    move v8, v3

    .line 106
    goto :goto_26

    .line 107
    :cond_6a
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->c()Landroidx/datastore/preferences/protobuf/z;

    .line 110
    move-result-object p1

    .line 111
    throw p1

    .line 112
    :cond_6f
    invoke-static {v2}, Landroidx/datastore/preferences/protobuf/q0$a;->f(B)Z

    .line 115
    move-result v3

    .line 116
    if-eqz v3, :cond_93

    .line 118
    add-int/lit8 v3, v0, -0x1

    .line 120
    if-ge v1, v3, :cond_8e

    .line 122
    add-int/lit8 v3, p2, 0x2

    .line 124
    int-to-long v4, v1

    .line 125
    invoke-static {p1, v4, v5}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 128
    move-result v1

    .line 129
    add-int/lit8 p2, p2, 0x3

    .line 131
    int-to-long v3, v3

    .line 132
    invoke-static {p1, v3, v4}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 135
    move-result v3

    .line 136
    add-int/lit8 v4, v8, 0x1

    .line 138
    invoke-static {v2, v1, v3, p3, v8}, Landroidx/datastore/preferences/protobuf/q0$a;->g(BBB[CI)V

    .line 141
    move v8, v4

    .line 142
    goto :goto_26

    .line 143
    :cond_8e
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->c()Landroidx/datastore/preferences/protobuf/z;

    .line 146
    move-result-object p1

    .line 147
    throw p1

    .line 148
    :cond_93
    add-int/lit8 v3, v0, -0x2

    .line 150
    if-ge v1, v3, :cond_b8

    .line 152
    add-int/lit8 v3, p2, 0x2

    .line 154
    int-to-long v4, v1

    .line 155
    invoke-static {p1, v4, v5}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 158
    move-result v4

    .line 159
    add-int/lit8 v1, p2, 0x3

    .line 161
    int-to-long v5, v3

    .line 162
    invoke-static {p1, v5, v6}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 165
    move-result v3

    .line 166
    add-int/lit8 p2, p2, 0x4

    .line 168
    int-to-long v5, v1

    .line 169
    invoke-static {p1, v5, v6}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 172
    move-result v5

    .line 173
    move v1, v2

    .line 174
    move v2, v4

    .line 175
    move v4, v5

    .line 176
    move-object v5, p3

    .line 177
    move v6, v8

    .line 178
    invoke-static/range {v1 .. v6}, Landroidx/datastore/preferences/protobuf/q0$a;->a(BBBB[CI)V

    .line 181
    add-int/lit8 v8, v8, 0x2

    .line 183
    goto/16 :goto_26

    .line 185
    :cond_b8
    invoke-static {}, Landroidx/datastore/preferences/protobuf/z;->c()Landroidx/datastore/preferences/protobuf/z;

    .line 188
    move-result-object p1

    .line 189
    throw p1

    .line 190
    :cond_bd
    new-instance p1, Ljava/lang/String;

    .line 192
    invoke-direct {p1, p3, v7, v8}, Ljava/lang/String;-><init>([CII)V

    .line 195
    return-object p1

    .line 196
    :cond_c3
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 198
    array-length p1, p1

    .line 199
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 202
    move-result-object p1

    .line 203
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    move-result-object p2

    .line 207
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 210
    move-result-object p3

    .line 211
    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    .line 214
    move-result-object p1

    .line 215
    const-string p2, "buffer length=%d, index=%d, size=%d"

    .line 217
    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 220
    move-result-object p1

    .line 221
    invoke-direct {v0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 224
    throw v0
.end method

.method public b(Ljava/lang/CharSequence;[BII)I
    .registers 29

    .line 1
    move-object/from16 v0, p1

    .line 3
    move-object/from16 v1, p2

    .line 5
    move/from16 v2, p3

    .line 7
    move/from16 v3, p4

    .line 9
    int-to-long v4, v2

    .line 10
    int-to-long v6, v3

    .line 11
    add-long/2addr v6, v4

    .line 12
    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    .line 15
    move-result v8

    .line 16
    const-string v9, " at index "

    .line 18
    const-string v10, "Failed writing "

    .line 20
    if-gt v8, v3, :cond_144

    .line 22
    array-length v11, v1

    .line 23
    sub-int/2addr v11, v3

    .line 24
    if-lt v11, v2, :cond_144

    .line 26
    const/4 v2, 0x0

    .line 27
    :goto_1a
    const-wide/16 v11, 0x1

    .line 29
    const/16 v3, 0x80

    .line 31
    if-ge v2, v8, :cond_2f

    .line 33
    invoke-interface {v0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 36
    move-result v13

    .line 37
    if-ge v13, v3, :cond_2f

    .line 39
    add-long/2addr v11, v4

    .line 40
    int-to-byte v3, v13

    .line 41
    invoke-static {v1, v4, v5, v3}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 44
    add-int/lit8 v2, v2, 0x1

    .line 46
    move-wide v4, v11

    .line 47
    goto :goto_1a

    .line 48
    :cond_2f
    if-ne v2, v8, :cond_33

    .line 50
    long-to-int v0, v4

    .line 51
    return v0

    .line 52
    :cond_33
    :goto_33
    if-ge v2, v8, :cond_142

    .line 54
    invoke-interface {v0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 57
    move-result v13

    .line 58
    if-ge v13, v3, :cond_4f

    .line 60
    cmp-long v14, v4, v6

    .line 62
    if-gez v14, :cond_4f

    .line 64
    add-long v14, v4, v11

    .line 66
    int-to-byte v13, v13

    .line 67
    invoke-static {v1, v4, v5, v13}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 70
    move-wide/from16 v22, v6

    .line 72
    move-object/from16 v17, v10

    .line 74
    move-wide/from16 v20, v11

    .line 76
    move-wide v4, v14

    .line 77
    move-object v14, v9

    .line 78
    goto/16 :goto_f8

    .line 80
    :cond_4f
    const/16 v14, 0x800

    .line 82
    const-wide/16 v15, 0x2

    .line 84
    if-ge v13, v14, :cond_76

    .line 86
    sub-long v17, v6, v15

    .line 88
    cmp-long v14, v4, v17

    .line 90
    if-gtz v14, :cond_76

    .line 92
    move-object v14, v9

    .line 93
    move-object/from16 v17, v10

    .line 95
    add-long v9, v4, v11

    .line 97
    ushr-int/lit8 v11, v13, 0x6

    .line 99
    or-int/lit16 v11, v11, 0x3c0

    .line 101
    int-to-byte v11, v11

    .line 102
    invoke-static {v1, v4, v5, v11}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 105
    add-long/2addr v4, v15

    .line 106
    and-int/lit8 v11, v13, 0x3f

    .line 108
    or-int/2addr v11, v3

    .line 109
    int-to-byte v11, v11

    .line 110
    invoke-static {v1, v9, v10, v11}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 113
    :goto_70
    move-wide/from16 v22, v6

    .line 115
    const-wide/16 v20, 0x1

    .line 117
    goto/16 :goto_f8

    .line 119
    :cond_76
    move-object v14, v9

    .line 120
    move-object/from16 v17, v10

    .line 122
    const v9, 0xdfff

    .line 125
    const v10, 0xd800

    .line 128
    const-wide/16 v11, 0x3

    .line 130
    if-lt v13, v10, :cond_85

    .line 132
    if-ge v9, v13, :cond_ad

    .line 134
    :cond_85
    sub-long v18, v6, v11

    .line 136
    cmp-long v18, v4, v18

    .line 138
    if-gtz v18, :cond_ad

    .line 140
    const-wide/16 v18, 0x1

    .line 142
    add-long v9, v4, v18

    .line 144
    ushr-int/lit8 v11, v13, 0xc

    .line 146
    or-int/lit16 v11, v11, 0x1e0

    .line 148
    int-to-byte v11, v11

    .line 149
    invoke-static {v1, v4, v5, v11}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 152
    add-long v11, v4, v15

    .line 154
    ushr-int/lit8 v15, v13, 0x6

    .line 156
    and-int/lit8 v15, v15, 0x3f

    .line 158
    or-int/2addr v15, v3

    .line 159
    int-to-byte v15, v15

    .line 160
    invoke-static {v1, v9, v10, v15}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 163
    const-wide/16 v9, 0x3

    .line 165
    add-long/2addr v4, v9

    .line 166
    and-int/lit8 v9, v13, 0x3f

    .line 168
    or-int/2addr v9, v3

    .line 169
    int-to-byte v9, v9

    .line 170
    invoke-static {v1, v11, v12, v9}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 173
    goto :goto_70

    .line 174
    :cond_ad
    const-wide/16 v11, 0x4

    .line 176
    sub-long v20, v6, v11

    .line 178
    cmp-long v20, v4, v20

    .line 180
    if-gtz v20, :cond_10c

    .line 182
    add-int/lit8 v9, v2, 0x1

    .line 184
    if-eq v9, v8, :cond_104

    .line 186
    invoke-interface {v0, v9}, Ljava/lang/CharSequence;->charAt(I)C

    .line 189
    move-result v2

    .line 190
    invoke-static {v13, v2}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    .line 193
    move-result v10

    .line 194
    if-eqz v10, :cond_103

    .line 196
    invoke-static {v13, v2}, Ljava/lang/Character;->toCodePoint(CC)I

    .line 199
    move-result v2

    .line 200
    const-wide/16 v20, 0x1

    .line 202
    add-long v11, v4, v20

    .line 204
    ushr-int/lit8 v10, v2, 0x12

    .line 206
    or-int/lit16 v10, v10, 0xf0

    .line 208
    int-to-byte v10, v10

    .line 209
    invoke-static {v1, v4, v5, v10}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 212
    move-wide/from16 v22, v6

    .line 214
    add-long v6, v4, v15

    .line 216
    ushr-int/lit8 v10, v2, 0xc

    .line 218
    and-int/lit8 v10, v10, 0x3f

    .line 220
    or-int/2addr v10, v3

    .line 221
    int-to-byte v10, v10

    .line 222
    invoke-static {v1, v11, v12, v10}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 225
    const-wide/16 v10, 0x3

    .line 227
    add-long v11, v4, v10

    .line 229
    ushr-int/lit8 v10, v2, 0x6

    .line 231
    and-int/lit8 v10, v10, 0x3f

    .line 233
    or-int/2addr v10, v3

    .line 234
    int-to-byte v10, v10

    .line 235
    invoke-static {v1, v6, v7, v10}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 238
    const-wide/16 v6, 0x4

    .line 240
    add-long/2addr v4, v6

    .line 241
    and-int/lit8 v2, v2, 0x3f

    .line 243
    or-int/2addr v2, v3

    .line 244
    int-to-byte v2, v2

    .line 245
    invoke-static {v1, v11, v12, v2}, Landroidx/datastore/preferences/protobuf/p0;->H([BJB)V

    .line 248
    move v2, v9

    .line 249
    :goto_f8
    add-int/lit8 v2, v2, 0x1

    .line 251
    move-object v9, v14

    .line 252
    move-object/from16 v10, v17

    .line 254
    move-wide/from16 v11, v20

    .line 256
    move-wide/from16 v6, v22

    .line 258
    goto/16 :goto_33

    .line 260
    :cond_103
    move v2, v9

    .line 261
    :cond_104
    new-instance v0, Landroidx/datastore/preferences/protobuf/q0$d;

    .line 263
    add-int/lit8 v2, v2, -0x1

    .line 265
    invoke-direct {v0, v2, v8}, Landroidx/datastore/preferences/protobuf/q0$d;-><init>(II)V

    .line 268
    throw v0

    .line 269
    :cond_10c
    if-gt v10, v13, :cond_124

    .line 271
    if-gt v13, v9, :cond_124

    .line 273
    add-int/lit8 v1, v2, 0x1

    .line 275
    if-eq v1, v8, :cond_11e

    .line 277
    invoke-interface {v0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 280
    move-result v0

    .line 281
    invoke-static {v13, v0}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    .line 284
    move-result v0

    .line 285
    if-nez v0, :cond_124

    .line 287
    :cond_11e
    new-instance v0, Landroidx/datastore/preferences/protobuf/q0$d;

    .line 289
    invoke-direct {v0, v2, v8}, Landroidx/datastore/preferences/protobuf/q0$d;-><init>(II)V

    .line 292
    throw v0

    .line 293
    :cond_124
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 295
    new-instance v1, Ljava/lang/StringBuilder;

    .line 297
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 300
    move-object/from16 v6, v17

    .line 302
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 305
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 308
    move-object v7, v14

    .line 309
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 312
    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 315
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 318
    move-result-object v1

    .line 319
    invoke-direct {v0, v1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 322
    throw v0

    .line 323
    :cond_142
    long-to-int v0, v4

    .line 324
    return v0

    .line 325
    :cond_144
    move-object v7, v9

    .line 326
    move-object v6, v10

    .line 327
    new-instance v1, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 329
    new-instance v4, Ljava/lang/StringBuilder;

    .line 331
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 334
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 337
    add-int/lit8 v8, v8, -0x1

    .line 339
    invoke-interface {v0, v8}, Ljava/lang/CharSequence;->charAt(I)C

    .line 342
    move-result v0

    .line 343
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 346
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 349
    add-int v0, v2, v3

    .line 351
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 354
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 357
    move-result-object v0

    .line 358
    invoke-direct {v1, v0}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 361
    throw v1
.end method

.method public d(I[BII)I
    .registers 15

    .line 1
    or-int v0, p3, p4

    .line 3
    array-length v1, p2

    .line 4
    sub-int/2addr v1, p4

    .line 5
    or-int/2addr v0, v1

    .line 6
    if-ltz v0, :cond_a8

    .line 8
    int-to-long v0, p3

    .line 9
    int-to-long p3, p4

    .line 10
    if-eqz p1, :cond_a1

    .line 12
    cmp-long v2, v0, p3

    .line 14
    if-ltz v2, :cond_10

    .line 16
    return p1

    .line 17
    :cond_10
    int-to-byte v2, p1

    .line 18
    const/16 v3, -0x20

    .line 20
    const/4 v4, -0x1

    .line 21
    const/16 v5, -0x41

    .line 23
    const-wide/16 v6, 0x1

    .line 25
    if-ge v2, v3, :cond_2a

    .line 27
    const/16 p1, -0x3e

    .line 29
    if-lt v2, p1, :cond_29

    .line 31
    add-long/2addr v6, v0

    .line 32
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 35
    move-result p1

    .line 36
    if-le p1, v5, :cond_26

    .line 38
    goto :goto_29

    .line 39
    :cond_26
    move-wide v0, v6

    .line 40
    goto/16 :goto_a1

    .line 42
    :cond_29
    :goto_29
    return v4

    .line 43
    :cond_2a
    const/16 v8, -0x10

    .line 45
    if-ge v2, v8, :cond_5e

    .line 47
    shr-int/lit8 p1, p1, 0x8

    .line 49
    not-int p1, p1

    .line 50
    int-to-byte p1, p1

    .line 51
    if-nez p1, :cond_44

    .line 53
    add-long v8, v0, v6

    .line 55
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 58
    move-result p1

    .line 59
    cmp-long v0, v8, p3

    .line 61
    if-ltz v0, :cond_43

    .line 63
    invoke-static {v2, p1}, Landroidx/datastore/preferences/protobuf/q0;->a(II)I

    .line 66
    move-result p1

    .line 67
    return p1

    .line 68
    :cond_43
    move-wide v0, v8

    .line 69
    :cond_44
    if-gt p1, v5, :cond_5d

    .line 71
    const/16 v8, -0x60

    .line 73
    if-ne v2, v3, :cond_4c

    .line 75
    if-lt p1, v8, :cond_5d

    .line 77
    :cond_4c
    const/16 v3, -0x13

    .line 79
    if-ne v2, v3, :cond_52

    .line 81
    if-ge p1, v8, :cond_5d

    .line 83
    :cond_52
    add-long v2, v0, v6

    .line 85
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 88
    move-result p1

    .line 89
    if-le p1, v5, :cond_5b

    .line 91
    goto :goto_5d

    .line 92
    :cond_5b
    move-wide v0, v2

    .line 93
    goto :goto_a1

    .line 94
    :cond_5d
    :goto_5d
    return v4

    .line 95
    :cond_5e
    shr-int/lit8 v3, p1, 0x8

    .line 97
    not-int v3, v3

    .line 98
    int-to-byte v3, v3

    .line 99
    if-nez v3, :cond_76

    .line 101
    add-long v8, v0, v6

    .line 103
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 106
    move-result v3

    .line 107
    cmp-long p1, v8, p3

    .line 109
    if-ltz p1, :cond_73

    .line 111
    invoke-static {v2, v3}, Landroidx/datastore/preferences/protobuf/q0;->a(II)I

    .line 114
    move-result p1

    .line 115
    return p1

    .line 116
    :cond_73
    const/4 p1, 0x0

    .line 117
    move-wide v0, v8

    .line 118
    goto :goto_79

    .line 119
    :cond_76
    shr-int/lit8 p1, p1, 0x10

    .line 121
    int-to-byte p1, p1

    .line 122
    :goto_79
    if-nez p1, :cond_8b

    .line 124
    add-long v8, v0, v6

    .line 126
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 129
    move-result p1

    .line 130
    cmp-long v0, v8, p3

    .line 132
    if-ltz v0, :cond_8a

    .line 134
    invoke-static {v2, v3, p1}, Landroidx/datastore/preferences/protobuf/q0;->b(III)I

    .line 137
    move-result p1

    .line 138
    return p1

    .line 139
    :cond_8a
    move-wide v0, v8

    .line 140
    :cond_8b
    if-gt v3, v5, :cond_a0

    .line 142
    shl-int/lit8 v2, v2, 0x1c

    .line 144
    add-int/lit8 v3, v3, 0x70

    .line 146
    add-int/2addr v2, v3

    .line 147
    shr-int/lit8 v2, v2, 0x1e

    .line 149
    if-nez v2, :cond_a0

    .line 151
    if-gt p1, v5, :cond_a0

    .line 153
    add-long v2, v0, v6

    .line 155
    invoke-static {p2, v0, v1}, Landroidx/datastore/preferences/protobuf/p0;->s([BJ)B

    .line 158
    move-result p1

    .line 159
    if-le p1, v5, :cond_5b

    .line 161
    :cond_a0
    return v4

    .line 162
    :cond_a1
    :goto_a1
    sub-long/2addr p3, v0

    .line 163
    long-to-int p1, p3

    .line 164
    invoke-static {p2, v0, v1, p1}, Landroidx/datastore/preferences/protobuf/q0$e;->f([BJI)I

    .line 167
    move-result p1

    .line 168
    return p1

    .line 169
    :cond_a8
    new-instance p1, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 171
    array-length p2, p2

    .line 172
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 175
    move-result-object p2

    .line 176
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 179
    move-result-object p3

    .line 180
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 183
    move-result-object p4

    .line 184
    filled-new-array {p2, p3, p4}, [Ljava/lang/Object;

    .line 187
    move-result-object p2

    .line 188
    const-string p3, "Array length=%d, index=%d, limit=%d"

    .line 190
    invoke-static {p3, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 193
    move-result-object p2

    .line 194
    invoke-direct {p1, p2}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 197
    throw p1
.end method
