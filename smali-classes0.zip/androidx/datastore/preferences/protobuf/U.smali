.class public interface abstract Landroidx/datastore/preferences/protobuf/U;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract newInstance(Ljava/lang/Object;)Ljava/lang/Object;
.end method
