.class public final Landroidx/datastore/preferences/protobuf/q;
.super Landroidx/datastore/preferences/protobuf/p;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroidx/datastore/preferences/protobuf/p;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public a(Ljava/util/Map$Entry;)I
    .registers 2

    .line 1
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 4
    move-result-object p1

    .line 5
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 8
    const/4 p1, 0x0

    .line 9
    throw p1
.end method

.method public b(Landroidx/datastore/preferences/protobuf/o;Landroidx/datastore/preferences/protobuf/O;I)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-virtual {p1, p2, p3}, Landroidx/datastore/preferences/protobuf/o;->a(Landroidx/datastore/preferences/protobuf/O;I)Landroidx/datastore/preferences/protobuf/w$c;

    .line 4
    const/4 p1, 0x0

    .line 5
    return-object p1
.end method

.method public c(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/s;
    .registers 2

    .line 1
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public d(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/s;
    .registers 2

    .line 1
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public e(Landroidx/datastore/preferences/protobuf/O;)Z
    .registers 2

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public f(Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroidx/datastore/preferences/protobuf/q;->c(Ljava/lang/Object;)Landroidx/datastore/preferences/protobuf/s;

    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/s;->o()V

    .line 8
    return-void
.end method

.method public g(Landroidx/datastore/preferences/protobuf/d0;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/o;Landroidx/datastore/preferences/protobuf/s;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/l0;)Ljava/lang/Object;
    .registers 7

    .line 1
    invoke-static {p2}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public h(Landroidx/datastore/preferences/protobuf/d0;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/o;Landroidx/datastore/preferences/protobuf/s;)V
    .registers 5

    .line 1
    invoke-static {p2}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public i(Landroidx/datastore/preferences/protobuf/g;Ljava/lang/Object;Landroidx/datastore/preferences/protobuf/o;Landroidx/datastore/preferences/protobuf/s;)V
    .registers 5

    .line 1
    invoke-static {p2}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public j(Landroidx/datastore/preferences/protobuf/s0;Ljava/util/Map$Entry;)V
    .registers 3

    .line 1
    invoke-interface {p2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 4
    move-result-object p1

    .line 5
    invoke-static {p1}, Landroid/support/v4/media/session/a;->a(Ljava/lang/Object;)V

    .line 8
    const/4 p1, 0x0

    .line 9
    throw p1
.end method
