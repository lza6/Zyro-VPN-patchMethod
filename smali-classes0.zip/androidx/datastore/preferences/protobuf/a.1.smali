.class public abstract Landroidx/datastore/preferences/protobuf/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/datastore/preferences/protobuf/O;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/datastore/preferences/protobuf/a$a;
    }
.end annotation


# instance fields
.field protected memoizedHashCode:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Landroidx/datastore/preferences/protobuf/a;->memoizedHashCode:I

    .line 7
    return-void
.end method

.method public static b(Ljava/lang/Iterable;Ljava/util/List;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Landroidx/datastore/preferences/protobuf/a$a;->b(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 4
    return-void
.end method


# virtual methods
.method public abstract c()I
.end method

.method public d(Landroidx/datastore/preferences/protobuf/e0;)I
    .registers 4

    .line 1
    invoke-virtual {p0}, Landroidx/datastore/preferences/protobuf/a;->c()I

    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-ne v0, v1, :cond_e

    .line 8
    invoke-interface {p1, p0}, Landroidx/datastore/preferences/protobuf/e0;->getSerializedSize(Ljava/lang/Object;)I

    .line 11
    move-result v0

    .line 12
    invoke-virtual {p0, v0}, Landroidx/datastore/preferences/protobuf/a;->f(I)V

    .line 15
    :cond_e
    return v0
.end method

.method public e()Landroidx/datastore/preferences/protobuf/k0;
    .registers 2

    .line 1
    new-instance v0, Landroidx/datastore/preferences/protobuf/k0;

    .line 3
    invoke-direct {v0, p0}, Landroidx/datastore/preferences/protobuf/k0;-><init>(Landroidx/datastore/preferences/protobuf/O;)V

    .line 6
    return-object v0
.end method

.method public abstract f(I)V
.end method

.method public g(Ljava/io/OutputStream;)V
    .registers 3

    .line 1
    invoke-interface {p0}, Landroidx/datastore/preferences/protobuf/O;->getSerializedSize()I

    .line 4
    move-result v0

    .line 5
    invoke-static {v0}, Landroidx/datastore/preferences/protobuf/j;->C(I)I

    .line 8
    move-result v0

    .line 9
    invoke-static {p1, v0}, Landroidx/datastore/preferences/protobuf/j;->Z(Ljava/io/OutputStream;I)Landroidx/datastore/preferences/protobuf/j;

    .line 12
    move-result-object p1

    .line 13
    invoke-interface {p0, p1}, Landroidx/datastore/preferences/protobuf/O;->a(Landroidx/datastore/preferences/protobuf/j;)V

    .line 16
    invoke-virtual {p1}, Landroidx/datastore/preferences/protobuf/j;->W()V

    .line 19
    return-void
.end method
