.class public final Landroidx/concurrent/futures/e;
.super Landroidx/concurrent/futures/a;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroidx/concurrent/futures/a;-><init>()V

    .line 4
    return-void
.end method

.method public static i()Landroidx/concurrent/futures/e;
    .registers 1

    .line 1
    new-instance v0, Landroidx/concurrent/futures/e;

    .line 3
    invoke-direct {v0}, Landroidx/concurrent/futures/e;-><init>()V

    .line 6
    return-object v0
.end method


# virtual methods
.method public set(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroidx/concurrent/futures/a;->set(Ljava/lang/Object;)Z

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public setException(Ljava/lang/Throwable;)Z
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroidx/concurrent/futures/a;->setException(Ljava/lang/Throwable;)Z

    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public setFuture(LJ2/f;)Z
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroidx/concurrent/futures/a;->setFuture(LJ2/f;)Z

    .line 4
    move-result p1

    .line 5
    return p1
.end method
