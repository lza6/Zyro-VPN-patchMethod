.class public final Landroidx/activity/q;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/activity/q$f;,
        Landroidx/activity/q$g;,
        Landroidx/activity/q$h;,
        Landroidx/activity/q$i;
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:LQ/a;

.field public final c:Lq4/g;

.field public d:Landroidx/activity/p;

.field public e:Landroid/window/OnBackInvokedCallback;

.field public f:Landroid/window/OnBackInvokedDispatcher;

.field public g:Z

.field public h:Z


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .registers 3

    const/4 v0, 0x0

    .line 9
    invoke-direct {p0, p1, v0}, Landroidx/activity/q;-><init>(Ljava/lang/Runnable;LQ/a;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;LQ/a;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Landroidx/activity/q;->a:Ljava/lang/Runnable;

    .line 3
    iput-object p2, p0, Landroidx/activity/q;->b:LQ/a;

    .line 4
    new-instance p1, Lq4/g;

    invoke-direct {p1}, Lq4/g;-><init>()V

    iput-object p1, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 5
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x21

    if-lt p1, p2, :cond_40

    const/16 p2, 0x22

    if-lt p1, p2, :cond_33

    .line 6
    sget-object p1, Landroidx/activity/q$g;->a:Landroidx/activity/q$g;

    new-instance p2, Landroidx/activity/q$a;

    invoke-direct {p2, p0}, Landroidx/activity/q$a;-><init>(Landroidx/activity/q;)V

    new-instance v0, Landroidx/activity/q$b;

    invoke-direct {v0, p0}, Landroidx/activity/q$b;-><init>(Landroidx/activity/q;)V

    new-instance v1, Landroidx/activity/q$c;

    invoke-direct {v1, p0}, Landroidx/activity/q$c;-><init>(Landroidx/activity/q;)V

    new-instance v2, Landroidx/activity/q$d;

    invoke-direct {v2, p0}, Landroidx/activity/q$d;-><init>(Landroidx/activity/q;)V

    invoke-virtual {p1, p2, v0, v1, v2}, Landroidx/activity/q$g;->a(LB4/l;LB4/l;LB4/a;LB4/a;)Landroid/window/OnBackInvokedCallback;

    move-result-object p1

    goto :goto_3e

    .line 7
    :cond_33
    sget-object p1, Landroidx/activity/q$f;->a:Landroidx/activity/q$f;

    new-instance p2, Landroidx/activity/q$e;

    invoke-direct {p2, p0}, Landroidx/activity/q$e;-><init>(Landroidx/activity/q;)V

    invoke-virtual {p1, p2}, Landroidx/activity/q$f;->b(LB4/a;)Landroid/window/OnBackInvokedCallback;

    move-result-object p1

    .line 8
    :goto_3e
    iput-object p1, p0, Landroidx/activity/q;->e:Landroid/window/OnBackInvokedCallback;

    :cond_40
    return-void
.end method

.method public static final synthetic a(Landroidx/activity/q;)Landroidx/activity/p;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 3
    return-object p0
.end method

.method public static final synthetic b(Landroidx/activity/q;)Lq4/g;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 3
    return-object p0
.end method

.method public static final synthetic c(Landroidx/activity/q;)V
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroidx/activity/q;->j()V

    .line 4
    return-void
.end method

.method public static final synthetic d(Landroidx/activity/q;Landroidx/activity/b;)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroidx/activity/q;->l(Landroidx/activity/b;)V

    .line 4
    return-void
.end method

.method public static final synthetic e(Landroidx/activity/q;Landroidx/activity/b;)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroidx/activity/q;->m(Landroidx/activity/b;)V

    .line 4
    return-void
.end method

.method public static final synthetic f(Landroidx/activity/q;Landroidx/activity/p;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 3
    return-void
.end method

.method public static final synthetic g(Landroidx/activity/q;)V
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroidx/activity/q;->p()V

    .line 4
    return-void
.end method


# virtual methods
.method public final h(Landroidx/lifecycle/q;Landroidx/activity/p;)V
    .registers 5

    .line 1
    const-string v0, "owner"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    const-string v0, "onBackPressedCallback"

    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    invoke-interface {p1}, Landroidx/lifecycle/q;->getLifecycle()Landroidx/lifecycle/i;

    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p1}, Landroidx/lifecycle/i;->b()Landroidx/lifecycle/i$b;

    .line 18
    move-result-object v0

    .line 19
    sget-object v1, Landroidx/lifecycle/i$b;->a:Landroidx/lifecycle/i$b;

    .line 21
    if-ne v0, v1, :cond_17

    .line 23
    return-void

    .line 24
    :cond_17
    new-instance v0, Landroidx/activity/q$h;

    .line 26
    invoke-direct {v0, p0, p1, p2}, Landroidx/activity/q$h;-><init>(Landroidx/activity/q;Landroidx/lifecycle/i;Landroidx/activity/p;)V

    .line 29
    invoke-virtual {p2, v0}, Landroidx/activity/p;->addCancellable(Landroidx/activity/c;)V

    .line 32
    invoke-virtual {p0}, Landroidx/activity/q;->p()V

    .line 35
    new-instance p1, Landroidx/activity/q$j;

    .line 37
    invoke-direct {p1, p0}, Landroidx/activity/q$j;-><init>(Ljava/lang/Object;)V

    .line 40
    invoke-virtual {p2, p1}, Landroidx/activity/p;->setEnabledChangedCallback$activity_release(LB4/a;)V

    .line 43
    return-void
.end method

.method public final i(Landroidx/activity/p;)Landroidx/activity/c;
    .registers 4

    .line 1
    const-string v0, "onBackPressedCallback"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 8
    invoke-virtual {v0, p1}, Lq4/g;->add(Ljava/lang/Object;)Z

    .line 11
    new-instance v0, Landroidx/activity/q$i;

    .line 13
    invoke-direct {v0, p0, p1}, Landroidx/activity/q$i;-><init>(Landroidx/activity/q;Landroidx/activity/p;)V

    .line 16
    invoke-virtual {p1, v0}, Landroidx/activity/p;->addCancellable(Landroidx/activity/c;)V

    .line 19
    invoke-virtual {p0}, Landroidx/activity/q;->p()V

    .line 22
    new-instance v1, Landroidx/activity/q$k;

    .line 24
    invoke-direct {v1, p0}, Landroidx/activity/q$k;-><init>(Ljava/lang/Object;)V

    .line 27
    invoke-virtual {p1, v1}, Landroidx/activity/p;->setEnabledChangedCallback$activity_release(LB4/a;)V

    .line 30
    return-object v0
.end method

.method public final j()V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_27

    .line 6
    iget-object v0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 8
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    move-result v2

    .line 12
    invoke-interface {v0, v2}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 15
    move-result-object v0

    .line 16
    :cond_f
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_23

    .line 22
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 25
    move-result-object v2

    .line 26
    move-object v3, v2

    .line 27
    check-cast v3, Landroidx/activity/p;

    .line 29
    invoke-virtual {v3}, Landroidx/activity/p;->isEnabled()Z

    .line 32
    move-result v3

    .line 33
    if-eqz v3, :cond_f

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move-object v2, v1

    .line 37
    :goto_24
    move-object v0, v2

    .line 38
    check-cast v0, Landroidx/activity/p;

    .line 40
    :cond_27
    iput-object v1, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 42
    if-eqz v0, :cond_2e

    .line 44
    invoke-virtual {v0}, Landroidx/activity/p;->handleOnBackCancelled()V

    .line 47
    :cond_2e
    return-void
.end method

.method public final k()V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_27

    .line 6
    iget-object v0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 8
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    move-result v2

    .line 12
    invoke-interface {v0, v2}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 15
    move-result-object v0

    .line 16
    :cond_f
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_23

    .line 22
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 25
    move-result-object v2

    .line 26
    move-object v3, v2

    .line 27
    check-cast v3, Landroidx/activity/p;

    .line 29
    invoke-virtual {v3}, Landroidx/activity/p;->isEnabled()Z

    .line 32
    move-result v3

    .line 33
    if-eqz v3, :cond_f

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move-object v2, v1

    .line 37
    :goto_24
    move-object v0, v2

    .line 38
    check-cast v0, Landroidx/activity/p;

    .line 40
    :cond_27
    iput-object v1, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 42
    if-eqz v0, :cond_2f

    .line 44
    invoke-virtual {v0}, Landroidx/activity/p;->handleOnBackPressed()V

    .line 47
    return-void

    .line 48
    :cond_2f
    iget-object v0, p0, Landroidx/activity/q;->a:Ljava/lang/Runnable;

    .line 50
    if-eqz v0, :cond_36

    .line 52
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 55
    :cond_36
    return-void
.end method

.method public final l(Landroidx/activity/b;)V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 3
    if-nez v0, :cond_26

    .line 5
    iget-object v0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 7
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 10
    move-result v1

    .line 11
    invoke-interface {v0, v1}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 14
    move-result-object v0

    .line 15
    :cond_e
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_22

    .line 21
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 24
    move-result-object v1

    .line 25
    move-object v2, v1

    .line 26
    check-cast v2, Landroidx/activity/p;

    .line 28
    invoke-virtual {v2}, Landroidx/activity/p;->isEnabled()Z

    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_e

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 v1, 0x0

    .line 36
    :goto_23
    move-object v0, v1

    .line 37
    check-cast v0, Landroidx/activity/p;

    .line 39
    :cond_26
    if-eqz v0, :cond_2b

    .line 41
    invoke-virtual {v0, p1}, Landroidx/activity/p;->handleOnBackProgressed(Landroidx/activity/b;)V

    .line 44
    :cond_2b
    return-void
.end method

.method public final m(Landroidx/activity/b;)V
    .registers 5

    .line 1
    iget-object v0, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 6
    move-result v1

    .line 7
    invoke-interface {v0, v1}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 10
    move-result-object v0

    .line 11
    :cond_a
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_1e

    .line 17
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 20
    move-result-object v1

    .line 21
    move-object v2, v1

    .line 22
    check-cast v2, Landroidx/activity/p;

    .line 24
    invoke-virtual {v2}, Landroidx/activity/p;->isEnabled()Z

    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_a

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    const/4 v1, 0x0

    .line 32
    :goto_1f
    check-cast v1, Landroidx/activity/p;

    .line 34
    iput-object v1, p0, Landroidx/activity/q;->d:Landroidx/activity/p;

    .line 36
    if-eqz v1, :cond_28

    .line 38
    invoke-virtual {v1, p1}, Landroidx/activity/p;->handleOnBackStarted(Landroidx/activity/b;)V

    .line 41
    :cond_28
    return-void
.end method

.method public final n(Landroid/window/OnBackInvokedDispatcher;)V
    .registers 3

    .line 1
    const-string v0, "invoker"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iput-object p1, p0, Landroidx/activity/q;->f:Landroid/window/OnBackInvokedDispatcher;

    .line 8
    iget-boolean p1, p0, Landroidx/activity/q;->h:Z

    .line 10
    invoke-virtual {p0, p1}, Landroidx/activity/q;->o(Z)V

    .line 13
    return-void
.end method

.method public final o(Z)V
    .registers 6

    .line 1
    iget-object v0, p0, Landroidx/activity/q;->f:Landroid/window/OnBackInvokedDispatcher;

    .line 3
    iget-object v1, p0, Landroidx/activity/q;->e:Landroid/window/OnBackInvokedCallback;

    .line 5
    if-eqz v0, :cond_25

    .line 7
    if-eqz v1, :cond_25

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz p1, :cond_18

    .line 12
    iget-boolean v3, p0, Landroidx/activity/q;->g:Z

    .line 14
    if-nez v3, :cond_18

    .line 16
    sget-object p1, Landroidx/activity/q$f;->a:Landroidx/activity/q$f;

    .line 18
    invoke-virtual {p1, v0, v2, v1}, Landroidx/activity/q$f;->d(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 21
    const/4 p1, 0x1

    .line 22
    iput-boolean p1, p0, Landroidx/activity/q;->g:Z

    .line 24
    goto :goto_25

    .line 25
    :cond_18
    if-nez p1, :cond_25

    .line 27
    iget-boolean p1, p0, Landroidx/activity/q;->g:Z

    .line 29
    if-eqz p1, :cond_25

    .line 31
    sget-object p1, Landroidx/activity/q$f;->a:Landroidx/activity/q$f;

    .line 33
    invoke-virtual {p1, v0, v1}, Landroidx/activity/q$f;->e(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 36
    iput-boolean v2, p0, Landroidx/activity/q;->g:Z

    .line 38
    :cond_25
    :goto_25
    return-void
.end method

.method public final p()V
    .registers 5

    .line 1
    iget-boolean v0, p0, Landroidx/activity/q;->h:Z

    .line 3
    iget-object v1, p0, Landroidx/activity/q;->c:Lq4/g;

    .line 5
    instance-of v2, v1, Ljava/util/Collection;

    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v2, :cond_10

    .line 10
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_10

    .line 16
    goto :goto_27

    .line 17
    :cond_10
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 20
    move-result-object v1

    .line 21
    :cond_14
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_27

    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Landroidx/activity/p;

    .line 33
    invoke-virtual {v2}, Landroidx/activity/p;->isEnabled()Z

    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_14

    .line 39
    const/4 v3, 0x1

    .line 40
    :cond_27
    :goto_27
    iput-boolean v3, p0, Landroidx/activity/q;->h:Z

    .line 42
    if-eq v3, v0, :cond_3f

    .line 44
    iget-object v0, p0, Landroidx/activity/q;->b:LQ/a;

    .line 46
    if-eqz v0, :cond_36

    .line 48
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 51
    move-result-object v1

    .line 52
    invoke-interface {v0, v1}, LQ/a;->accept(Ljava/lang/Object;)V

    .line 55
    :cond_36
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 57
    const/16 v1, 0x21

    .line 59
    if-lt v0, v1, :cond_3f

    .line 61
    invoke-virtual {p0, v3}, Landroidx/activity/q;->o(Z)V

    .line 64
    :cond_3f
    return-void
.end method
