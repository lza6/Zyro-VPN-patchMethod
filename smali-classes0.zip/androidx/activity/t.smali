.class public abstract Landroidx/activity/t;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:I = 0x7f08018c

.field public static b:I = 0x7f08021f
