.class public final Landroidx/activity/q$g$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/window/OnBackAnimationCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/q$g;->a(LB4/l;LB4/l;LB4/a;LB4/a;)Landroid/window/OnBackInvokedCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic a:LB4/l;

.field public final synthetic b:LB4/l;

.field public final synthetic c:LB4/a;

.field public final synthetic d:LB4/a;


# direct methods
.method public constructor <init>(LB4/l;LB4/l;LB4/a;LB4/a;)V
    .registers 5

    .line 1
    iput-object p1, p0, Landroidx/activity/q$g$a;->a:LB4/l;

    .line 3
    iput-object p2, p0, Landroidx/activity/q$g$a;->b:LB4/l;

    .line 5
    iput-object p3, p0, Landroidx/activity/q$g$a;->c:LB4/a;

    .line 7
    iput-object p4, p0, Landroidx/activity/q$g$a;->d:LB4/a;

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    return-void
.end method


# virtual methods
.method public onBackCancelled()V
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/activity/q$g$a;->d:LB4/a;

    .line 3
    invoke-interface {v0}, LB4/a;->invoke()Ljava/lang/Object;

    .line 6
    return-void
.end method

.method public onBackInvoked()V
    .registers 2

    .line 1
    iget-object v0, p0, Landroidx/activity/q$g$a;->c:LB4/a;

    .line 3
    invoke-interface {v0}, LB4/a;->invoke()Ljava/lang/Object;

    .line 6
    return-void
.end method

.method public onBackProgressed(Landroid/window/BackEvent;)V
    .registers 4

    .line 1
    const-string v0, "backEvent"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/activity/q$g$a;->b:LB4/l;

    .line 8
    new-instance v1, Landroidx/activity/b;

    .line 10
    invoke-direct {v1, p1}, Landroidx/activity/b;-><init>(Landroid/window/BackEvent;)V

    .line 13
    invoke-interface {v0, v1}, LB4/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    return-void
.end method

.method public onBackStarted(Landroid/window/BackEvent;)V
    .registers 4

    .line 1
    const-string v0, "backEvent"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/activity/q$g$a;->a:LB4/l;

    .line 8
    new-instance v1, Landroidx/activity/b;

    .line 10
    invoke-direct {v1, p1}, Landroidx/activity/b;-><init>(Landroid/window/BackEvent;)V

    .line 13
    invoke-interface {v0, v1}, LB4/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    return-void
.end method
