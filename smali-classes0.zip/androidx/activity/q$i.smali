.class public final Landroidx/activity/q$i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/activity/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/activity/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "i"
.end annotation


# instance fields
.field public final a:Landroidx/activity/p;

.field public final synthetic b:Landroidx/activity/q;


# direct methods
.method public constructor <init>(Landroidx/activity/q;Landroidx/activity/p;)V
    .registers 4

    .line 1
    const-string v0, "onBackPressedCallback"

    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iput-object p1, p0, Landroidx/activity/q$i;->b:Landroidx/activity/q;

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p2, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 13
    return-void
.end method


# virtual methods
.method public cancel()V
    .registers 3

    .line 1
    iget-object v0, p0, Landroidx/activity/q$i;->b:Landroidx/activity/q;

    .line 3
    invoke-static {v0}, Landroidx/activity/q;->b(Landroidx/activity/q;)Lq4/g;

    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 9
    invoke-virtual {v0, v1}, Lq4/g;->remove(Ljava/lang/Object;)Z

    .line 12
    iget-object v0, p0, Landroidx/activity/q$i;->b:Landroidx/activity/q;

    .line 14
    invoke-static {v0}, Landroidx/activity/q;->a(Landroidx/activity/q;)Landroidx/activity/p;

    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 20
    invoke-static {v0, v1}, Lkotlin/jvm/internal/s;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    move-result v0

    .line 24
    const/4 v1, 0x0

    .line 25
    if-eqz v0, :cond_24

    .line 27
    iget-object v0, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 29
    invoke-virtual {v0}, Landroidx/activity/p;->handleOnBackCancelled()V

    .line 32
    iget-object v0, p0, Landroidx/activity/q$i;->b:Landroidx/activity/q;

    .line 34
    invoke-static {v0, v1}, Landroidx/activity/q;->f(Landroidx/activity/q;Landroidx/activity/p;)V

    .line 37
    :cond_24
    iget-object v0, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 39
    invoke-virtual {v0, p0}, Landroidx/activity/p;->removeCancellable(Landroidx/activity/c;)V

    .line 42
    iget-object v0, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 44
    invoke-virtual {v0}, Landroidx/activity/p;->getEnabledChangedCallback$activity_release()LB4/a;

    .line 47
    move-result-object v0

    .line 48
    if-eqz v0, :cond_34

    .line 50
    invoke-interface {v0}, LB4/a;->invoke()Ljava/lang/Object;

    .line 53
    :cond_34
    iget-object v0, p0, Landroidx/activity/q$i;->a:Landroidx/activity/p;

    .line 55
    invoke-virtual {v0, v1}, Landroidx/activity/p;->setEnabledChangedCallback$activity_release(LB4/a;)V

    .line 58
    return-void
.end method
