.class public interface abstract Landroidx/activity/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/q;


# virtual methods
.method public abstract getOnBackPressedDispatcher()Landroidx/activity/q;
.end method
