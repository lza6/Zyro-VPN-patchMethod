.class public final Landroidx/activity/q$a;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/q;-><init>(Ljava/lang/Runnable;LQ/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Landroidx/activity/q;


# direct methods
.method public constructor <init>(Landroidx/activity/q;)V
    .registers 2

    iput-object p1, p0, Landroidx/activity/q$a;->d:Landroidx/activity/q;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/activity/b;)V
    .registers 3

    .line 1
    const-string v0, "backEvent"

    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/s;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    iget-object v0, p0, Landroidx/activity/q$a;->d:Landroidx/activity/q;

    .line 8
    invoke-static {v0, p1}, Landroidx/activity/q;->e(Landroidx/activity/q;Landroidx/activity/b;)V

    .line 11
    return-void
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, Landroidx/activity/b;

    .line 3
    invoke-virtual {p0, p1}, Landroidx/activity/q$a;->a(Landroidx/activity/b;)V

    .line 6
    sget-object p1, Lp4/E;->a:Lp4/E;

    .line 8
    return-object p1
.end method
