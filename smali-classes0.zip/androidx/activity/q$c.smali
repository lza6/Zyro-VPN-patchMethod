.class public final Landroidx/activity/q$c;
.super Lkotlin/jvm/internal/t;
.source "SourceFile"

# interfaces
.implements LB4/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/q;-><init>(Ljava/lang/Runnable;LQ/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field public final synthetic d:Landroidx/activity/q;


# direct methods
.method public constructor <init>(Landroidx/activity/q;)V
    .registers 2

    iput-object p1, p0, Landroidx/activity/q$c;->d:Landroidx/activity/q;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/t;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Landroidx/activity/q$c;->invoke()V

    sget-object v0, Lp4/E;->a:Lp4/E;

    return-object v0
.end method

.method public final invoke()V
    .registers 2

    .line 2
    iget-object v0, p0, Landroidx/activity/q$c;->d:Landroidx/activity/q;

    invoke-virtual {v0}, Landroidx/activity/q;->k()V

    return-void
.end method
