.class public abstract LA0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I


# direct methods
.method public constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, LA0/a;->a:I

    .line 6
    iput p2, p0, LA0/a;->b:I

    .line 8
    return-void
.end method


# virtual methods
.method public abstract a(LD0/b;)V
.end method
