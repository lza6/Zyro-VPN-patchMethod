.class public La0/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La0/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;Landroid/graphics/Rect;)V
    .registers 3

    .line 1
    check-cast p1, LS/x;

    .line 3
    invoke-virtual {p0, p1, p2}, La0/a$a;->b(LS/x;Landroid/graphics/Rect;)V

    .line 6
    return-void
.end method

.method public b(LS/x;Landroid/graphics/Rect;)V
    .registers 3

    .line 1
    invoke-virtual {p1, p2}, LS/x;->l(Landroid/graphics/Rect;)V

    .line 4
    return-void
.end method
