.class public abstract Landroid/support/customtabs/trusted/ITrustedWebActivityService$Stub;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Landroid/support/customtabs/trusted/ITrustedWebActivityService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/customtabs/trusted/ITrustedWebActivityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/customtabs/trusted/ITrustedWebActivityService$Stub$a;
    }
.end annotation


# direct methods
.method public static asInterface(Landroid/os/IBinder;)Landroid/support/customtabs/trusted/ITrustedWebActivityService;
    .registers 3

    .line 1
    if-nez p0, :cond_4

    .line 3
    const/4 p0, 0x0

    .line 4
    return-object p0

    .line 5
    :cond_4
    sget-object v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->q1:Ljava/lang/String;

    .line 7
    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_13

    .line 13
    instance-of v1, v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService;

    .line 15
    if-eqz v1, :cond_13

    .line 17
    check-cast v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService;

    .line 19
    return-object v0

    .line 20
    :cond_13
    new-instance v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService$Stub$a;

    .line 22
    invoke-direct {v0, p0}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$Stub$a;-><init>(Landroid/os/IBinder;)V

    .line 25
    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 1

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 8

    .line 1
    sget-object v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->q1:Ljava/lang/String;

    .line 3
    const/4 v1, 0x1

    .line 4
    if-lt p1, v1, :cond_d

    .line 6
    const v2, 0xffffff

    .line 9
    if-gt p1, v2, :cond_d

    .line 11
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 14
    :cond_d
    const v2, 0x5f4e5446

    .line 17
    if-ne p1, v2, :cond_16

    .line 19
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 22
    return v1

    .line 23
    :cond_16
    packed-switch p1, :pswitch_data_90

    .line 26
    :pswitch_19
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 29
    move-result p1

    .line 30
    return p1

    .line 31
    :pswitch_1e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 34
    move-result-object p1

    .line 35
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 37
    invoke-static {p2, p4}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 40
    move-result-object p4

    .line 41
    check-cast p4, Landroid/os/Bundle;

    .line 43
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 46
    move-result-object p2

    .line 47
    invoke-interface {p0, p1, p4, p2}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->M(Ljava/lang/String;Landroid/os/Bundle;Landroid/os/IBinder;)Landroid/os/Bundle;

    .line 50
    move-result-object p1

    .line 51
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 54
    invoke-static {p3, p1, v1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->b(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 57
    goto :goto_8e

    .line 58
    :pswitch_39
    invoke-interface {p0}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->f0()Landroid/os/Bundle;

    .line 61
    move-result-object p1

    .line 62
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 65
    invoke-static {p3, p1, v1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->b(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 68
    goto :goto_8e

    .line 69
    :pswitch_44
    sget-object p1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 71
    invoke-static {p2, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 74
    move-result-object p1

    .line 75
    check-cast p1, Landroid/os/Bundle;

    .line 77
    invoke-interface {p0, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->k0(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 80
    move-result-object p1

    .line 81
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 84
    invoke-static {p3, p1, v1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->b(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 87
    goto :goto_8e

    .line 88
    :pswitch_57
    invoke-interface {p0}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->o()Landroid/os/Bundle;

    .line 91
    move-result-object p1

    .line 92
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 95
    invoke-static {p3, p1, v1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->b(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 98
    goto :goto_8e

    .line 99
    :pswitch_62
    invoke-interface {p0}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->d0()I

    .line 102
    move-result p1

    .line 103
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 106
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 109
    goto :goto_8e

    .line 110
    :pswitch_6d
    sget-object p1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 112
    invoke-static {p2, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 115
    move-result-object p1

    .line 116
    check-cast p1, Landroid/os/Bundle;

    .line 118
    invoke-interface {p0, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->x0(Landroid/os/Bundle;)V

    .line 121
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 124
    goto :goto_8e

    .line 125
    :pswitch_7c
    sget-object p1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 127
    invoke-static {p2, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 130
    move-result-object p1

    .line 131
    check-cast p1, Landroid/os/Bundle;

    .line 133
    invoke-interface {p0, p1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->A0(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 136
    move-result-object p1

    .line 137
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 140
    invoke-static {p3, p1, v1}, Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;->b(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 143
    :goto_8e
    return v1

    .line 144
    nop

    .line 145
    :pswitch_data_90
    .packed-switch 0x2
        :pswitch_7c
        :pswitch_6d
        :pswitch_62
        :pswitch_57
        :pswitch_44
        :pswitch_39
        :pswitch_19
        :pswitch_1e
    .end packed-switch
.end method
