.class public interface abstract Landroid/support/customtabs/trusted/ITrustedWebActivityService;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/customtabs/trusted/ITrustedWebActivityService$a;,
        Landroid/support/customtabs/trusted/ITrustedWebActivityService$Stub;
    }
.end annotation


# static fields
.field public static final q1:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const/16 v0, 0x24

    .line 3
    const/16 v1, 0x2e

    .line 5
    const-string v2, "android$support$customtabs$trusted$ITrustedWebActivityService"

    .line 7
    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Landroid/support/customtabs/trusted/ITrustedWebActivityService;->q1:Ljava/lang/String;

    .line 13
    return-void
.end method


# virtual methods
.method public abstract A0(Landroid/os/Bundle;)Landroid/os/Bundle;
.end method

.method public abstract M(Ljava/lang/String;Landroid/os/Bundle;Landroid/os/IBinder;)Landroid/os/Bundle;
.end method

.method public abstract d0()I
.end method

.method public abstract f0()Landroid/os/Bundle;
.end method

.method public abstract k0(Landroid/os/Bundle;)Landroid/os/Bundle;
.end method

.method public abstract o()Landroid/os/Bundle;
.end method

.method public abstract x0(Landroid/os/Bundle;)V
.end method
