.class public interface abstract Landroid/support/customtabs/ICustomTabsCallback;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/customtabs/ICustomTabsCallback$a;,
        Landroid/support/customtabs/ICustomTabsCallback$Stub;
    }
.end annotation


# static fields
.field public static final l1:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const/16 v0, 0x24

    .line 3
    const/16 v1, 0x2e

    .line 5
    const-string v2, "android$support$customtabs$ICustomTabsCallback"

    .line 7
    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Landroid/support/customtabs/ICustomTabsCallback;->l1:Ljava/lang/String;

    .line 13
    return-void
.end method


# virtual methods
.method public abstract B0(Landroid/os/Bundle;)V
.end method

.method public abstract G(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
.end method

.method public abstract G0(ILandroid/os/Bundle;)V
.end method

.method public abstract R0(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract V(Landroid/os/Bundle;)V
.end method

.method public abstract W(Landroid/os/Bundle;)V
.end method

.method public abstract W0(Landroid/os/Bundle;)V
.end method

.method public abstract Y0(ILandroid/net/Uri;ZLandroid/os/Bundle;)V
.end method

.method public abstract c0(IILandroid/os/Bundle;)V
.end method

.method public abstract r(IIIIILandroid/os/Bundle;)V
.end method

.method public abstract u0(Ljava/lang/String;Landroid/os/Bundle;)V
.end method
