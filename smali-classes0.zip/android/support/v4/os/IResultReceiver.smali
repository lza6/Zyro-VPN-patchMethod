.class public interface abstract Landroid/support/v4/os/IResultReceiver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/os/IResultReceiver$a;,
        Landroid/support/v4/os/IResultReceiver$Stub;
    }
.end annotation


# static fields
.field public static final t1:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const/16 v0, 0x24

    .line 3
    const/16 v1, 0x2e

    .line 5
    const-string v2, "android$support$v4$os$IResultReceiver"

    .line 7
    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Landroid/support/v4/os/IResultReceiver;->t1:Ljava/lang/String;

    .line 13
    return-void
.end method


# virtual methods
.method public abstract b(ILandroid/os/Bundle;)V
.end method
