.class public abstract Landroid/support/v4/media/a$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/media/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public static a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 1

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0}, Landroid/media/MediaDescription$Builder;->build()Landroid/media/MediaDescription;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public static b()Ljava/lang/Object;
    .registers 1

    .line 1
    new-instance v0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-direct {v0}, Landroid/media/MediaDescription$Builder;-><init>()V

    .line 6
    return-object v0
.end method

.method public static c(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setDescription(Ljava/lang/CharSequence;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static d(Ljava/lang/Object;Landroid/os/Bundle;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setExtras(Landroid/os/Bundle;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static e(Ljava/lang/Object;Landroid/graphics/Bitmap;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setIconBitmap(Landroid/graphics/Bitmap;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static f(Ljava/lang/Object;Landroid/net/Uri;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setIconUri(Landroid/net/Uri;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static g(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setMediaId(Ljava/lang/String;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static h(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setSubtitle(Ljava/lang/CharSequence;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method

.method public static i(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    .registers 2

    .line 1
    check-cast p0, Landroid/media/MediaDescription$Builder;

    .line 3
    invoke-virtual {p0, p1}, Landroid/media/MediaDescription$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/media/MediaDescription$Builder;

    .line 6
    return-void
.end method
