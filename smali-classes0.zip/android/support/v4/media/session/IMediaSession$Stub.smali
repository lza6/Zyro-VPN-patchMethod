.class public abstract Landroid/support/v4/media/session/IMediaSession$Stub;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/media/session/IMediaSession;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/media/session/IMediaSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/media/session/IMediaSession$Stub$a;
    }
.end annotation


# direct methods
.method public static asInterface(Landroid/os/IBinder;)Landroid/support/v4/media/session/IMediaSession;
    .registers 3

    .line 1
    if-nez p0, :cond_4

    .line 3
    const/4 p0, 0x0

    .line 4
    return-object p0

    .line 5
    :cond_4
    const-string v0, "android.support.v4.media.session.IMediaSession"

    .line 7
    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_13

    .line 13
    instance-of v1, v0, Landroid/support/v4/media/session/IMediaSession;

    .line 15
    if-eqz v1, :cond_13

    .line 17
    check-cast v0, Landroid/support/v4/media/session/IMediaSession;

    .line 19
    return-object v0

    .line 20
    :cond_13
    new-instance v0, Landroid/support/v4/media/session/IMediaSession$Stub$a;

    .line 22
    invoke-direct {v0, p0}, Landroid/support/v4/media/session/IMediaSession$Stub$a;-><init>(Landroid/os/IBinder;)V

    .line 25
    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 1

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 9

    .line 1
    const/16 v0, 0x33

    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "android.support.v4.media.session.IMediaSession"

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eq p1, v0, :cond_3cd

    .line 9
    const v0, 0x5f4e5446

    .line 12
    if-eq p1, v0, :cond_3c9

    .line 14
    const/4 v0, 0x0

    .line 15
    packed-switch p1, :pswitch_data_3f6

    .line 18
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 21
    move-result p1

    .line 22
    return p1

    .line 23
    :pswitch_16
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 26
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 29
    move-result p1

    .line 30
    invoke-interface {p0, p1}, Landroid/support/v4/media/session/IMediaSession;->V0(I)V

    .line 33
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 36
    return v3

    .line 37
    :pswitch_24
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 40
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->v0()I

    .line 43
    move-result p1

    .line 44
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 47
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 50
    return v3

    .line 51
    :pswitch_32
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 54
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 57
    move-result p1

    .line 58
    if-eqz p1, :cond_3c

    .line 60
    move v0, v3

    .line 61
    :cond_3c
    invoke-interface {p0, v0}, Landroid/support/v4/media/session/IMediaSession;->m0(Z)V

    .line 64
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 67
    return v3

    .line 68
    :pswitch_43
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 71
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->z0()Z

    .line 74
    move-result p1

    .line 75
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 78
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 81
    return v3

    .line 82
    :pswitch_51
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 85
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 88
    move-result p1

    .line 89
    invoke-interface {p0, p1}, Landroid/support/v4/media/session/IMediaSession;->w0(I)V

    .line 92
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 95
    return v3

    .line 96
    :pswitch_5f
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 99
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 102
    move-result p1

    .line 103
    if-eqz p1, :cond_71

    .line 105
    sget-object p1, Landroid/support/v4/media/MediaDescriptionCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 107
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 110
    move-result-object p1

    .line 111
    move-object v1, p1

    .line 112
    check-cast v1, Landroid/support/v4/media/MediaDescriptionCompat;

    .line 114
    :cond_71
    invoke-interface {p0, v1}, Landroid/support/v4/media/session/IMediaSession;->l(Landroid/support/v4/media/MediaDescriptionCompat;)V

    .line 117
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 120
    return v3

    .line 121
    :pswitch_78
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 124
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 127
    move-result p1

    .line 128
    if-eqz p1, :cond_8a

    .line 130
    sget-object p1, Landroid/support/v4/media/MediaDescriptionCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 132
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 135
    move-result-object p1

    .line 136
    move-object v1, p1

    .line 137
    check-cast v1, Landroid/support/v4/media/MediaDescriptionCompat;

    .line 139
    :cond_8a
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 142
    move-result p1

    .line 143
    invoke-interface {p0, v1, p1}, Landroid/support/v4/media/session/IMediaSession;->h0(Landroid/support/v4/media/MediaDescriptionCompat;I)V

    .line 146
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 149
    return v3

    .line 150
    :pswitch_95
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 153
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 156
    move-result p1

    .line 157
    if-eqz p1, :cond_a7

    .line 159
    sget-object p1, Landroid/support/v4/media/MediaDescriptionCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 161
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 164
    move-result-object p1

    .line 165
    move-object v1, p1

    .line 166
    check-cast v1, Landroid/support/v4/media/MediaDescriptionCompat;

    .line 168
    :cond_a7
    invoke-interface {p0, v1}, Landroid/support/v4/media/session/IMediaSession;->n(Landroid/support/v4/media/MediaDescriptionCompat;)V

    .line 171
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 174
    return v3

    .line 175
    :pswitch_ae
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 178
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 181
    move-result p1

    .line 182
    if-eqz p1, :cond_b8

    .line 184
    move v0, v3

    .line 185
    :cond_b8
    invoke-interface {p0, v0}, Landroid/support/v4/media/session/IMediaSession;->P0(Z)V

    .line 188
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 191
    return v3

    .line 192
    :pswitch_bf
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 195
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 198
    move-result p1

    .line 199
    invoke-interface {p0, p1}, Landroid/support/v4/media/session/IMediaSession;->I0(I)V

    .line 202
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 205
    return v3

    .line 206
    :pswitch_cd
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 209
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->e()Z

    .line 212
    move-result p1

    .line 213
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 216
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 219
    return v3

    .line 220
    :pswitch_db
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 223
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->N0()I

    .line 226
    move-result p1

    .line 227
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 230
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 233
    return v3

    .line 234
    :pswitch_e9
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 237
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 240
    move-result p1

    .line 241
    if-eqz p1, :cond_fb

    .line 243
    sget-object p1, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 245
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 248
    move-result-object p1

    .line 249
    check-cast p1, Landroid/net/Uri;

    .line 251
    goto :goto_fc

    .line 252
    :cond_fb
    move-object p1, v1

    .line 253
    :goto_fc
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 256
    move-result p4

    .line 257
    if-eqz p4, :cond_10b

    .line 259
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 261
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 264
    move-result-object p2

    .line 265
    move-object v1, p2

    .line 266
    check-cast v1, Landroid/os/Bundle;

    .line 268
    :cond_10b
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->h(Landroid/net/Uri;Landroid/os/Bundle;)V

    .line 271
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 274
    return v3

    .line 275
    :pswitch_112
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 278
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 281
    move-result-object p1

    .line 282
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 285
    move-result p4

    .line 286
    if-eqz p4, :cond_128

    .line 288
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 290
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 293
    move-result-object p2

    .line 294
    move-object v1, p2

    .line 295
    check-cast v1, Landroid/os/Bundle;

    .line 297
    :cond_128
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->u(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 300
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 303
    return v3

    .line 304
    :pswitch_12f
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 307
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 310
    move-result-object p1

    .line 311
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 314
    move-result p4

    .line 315
    if-eqz p4, :cond_145

    .line 317
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 319
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 322
    move-result-object p2

    .line 323
    move-object v1, p2

    .line 324
    check-cast v1, Landroid/os/Bundle;

    .line 326
    :cond_145
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->H(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 329
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 332
    return v3

    .line 333
    :pswitch_14c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 336
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->x()V

    .line 339
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 342
    return v3

    .line 343
    :pswitch_156
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 346
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->s()I

    .line 349
    move-result p1

    .line 350
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 353
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 356
    return v3

    .line 357
    :pswitch_164
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 360
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->getExtras()Landroid/os/Bundle;

    .line 363
    move-result-object p1

    .line 364
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 367
    if-eqz p1, :cond_177

    .line 369
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 372
    invoke-virtual {p1, p3, v3}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    .line 375
    goto :goto_17a

    .line 376
    :cond_177
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 379
    :goto_17a
    return v3

    .line 380
    :pswitch_17b
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 383
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->F()Ljava/lang/CharSequence;

    .line 386
    move-result-object p1

    .line 387
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 390
    if-eqz p1, :cond_18e

    .line 392
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 395
    invoke-static {p1, p3, v3}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V

    .line 398
    goto :goto_191

    .line 399
    :cond_18e
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 402
    :goto_191
    return v3

    .line 403
    :pswitch_192
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 406
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->H0()Ljava/util/List;

    .line 409
    move-result-object p1

    .line 410
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 413
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    .line 416
    return v3

    .line 417
    :pswitch_1a0
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 420
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->q0()Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 423
    move-result-object p1

    .line 424
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 427
    if-eqz p1, :cond_1b3

    .line 429
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 432
    invoke-virtual {p1, p3, v3}, Landroid/support/v4/media/session/PlaybackStateCompat;->writeToParcel(Landroid/os/Parcel;I)V

    .line 435
    goto :goto_1b6

    .line 436
    :cond_1b3
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 439
    :goto_1b6
    return v3

    .line 440
    :pswitch_1b7
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 443
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->getMetadata()Landroid/support/v4/media/MediaMetadataCompat;

    .line 446
    move-result-object p1

    .line 447
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 450
    if-eqz p1, :cond_1ca

    .line 452
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 455
    invoke-virtual {p1, p3, v3}, Landroid/support/v4/media/MediaMetadataCompat;->writeToParcel(Landroid/os/Parcel;I)V

    .line 458
    goto :goto_1cd

    .line 459
    :cond_1ca
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 462
    :goto_1cd
    return v3

    .line 463
    :pswitch_1ce
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 466
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 469
    move-result-object p1

    .line 470
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 473
    move-result p4

    .line 474
    if-eqz p4, :cond_1e4

    .line 476
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 478
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 481
    move-result-object p2

    .line 482
    move-object v1, p2

    .line 483
    check-cast v1, Landroid/os/Bundle;

    .line 485
    :cond_1e4
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->c(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 488
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 491
    return v3

    .line 492
    :pswitch_1eb
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 495
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 498
    move-result p1

    .line 499
    if-eqz p1, :cond_1fd

    .line 501
    sget-object p1, Landroid/support/v4/media/RatingCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 503
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 506
    move-result-object p1

    .line 507
    move-object v1, p1

    .line 508
    check-cast v1, Landroid/support/v4/media/RatingCompat;

    .line 510
    :cond_1fd
    invoke-interface {p0, v1}, Landroid/support/v4/media/session/IMediaSession;->f(Landroid/support/v4/media/RatingCompat;)V

    .line 513
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 516
    return v3

    .line 517
    :pswitch_204
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 520
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 523
    move-result-wide p1

    .line 524
    invoke-interface {p0, p1, p2}, Landroid/support/v4/media/session/IMediaSession;->R(J)V

    .line 527
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 530
    return v3

    .line 531
    :pswitch_212
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 534
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->J0()V

    .line 537
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 540
    return v3

    .line 541
    :pswitch_21c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 544
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->O()V

    .line 547
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 550
    return v3

    .line 551
    :pswitch_226
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 554
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->previous()V

    .line 557
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 560
    return v3

    .line 561
    :pswitch_230
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 564
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->next()V

    .line 567
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 570
    return v3

    .line 571
    :pswitch_23a
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 574
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->stop()V

    .line 577
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 580
    return v3

    .line 581
    :pswitch_244
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 584
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->pause()V

    .line 587
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 590
    return v3

    .line 591
    :pswitch_24e
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 594
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 597
    move-result-wide p1

    .line 598
    invoke-interface {p0, p1, p2}, Landroid/support/v4/media/session/IMediaSession;->O0(J)V

    .line 601
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 604
    return v3

    .line 605
    :pswitch_25c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 608
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 611
    move-result p1

    .line 612
    if-eqz p1, :cond_26e

    .line 614
    sget-object p1, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 616
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 619
    move-result-object p1

    .line 620
    check-cast p1, Landroid/net/Uri;

    .line 622
    goto :goto_26f

    .line 623
    :cond_26e
    move-object p1, v1

    .line 624
    :goto_26f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 627
    move-result p4

    .line 628
    if-eqz p4, :cond_27e

    .line 630
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 632
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 635
    move-result-object p2

    .line 636
    move-object v1, p2

    .line 637
    check-cast v1, Landroid/os/Bundle;

    .line 639
    :cond_27e
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->Q(Landroid/net/Uri;Landroid/os/Bundle;)V

    .line 642
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 645
    return v3

    .line 646
    :pswitch_285
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 649
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 652
    move-result-object p1

    .line 653
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 656
    move-result p4

    .line 657
    if-eqz p4, :cond_29b

    .line 659
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 661
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 664
    move-result-object p2

    .line 665
    move-object v1, p2

    .line 666
    check-cast v1, Landroid/os/Bundle;

    .line 668
    :cond_29b
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->L(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 671
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 674
    return v3

    .line 675
    :pswitch_2a2
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 678
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 681
    move-result-object p1

    .line 682
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 685
    move-result p4

    .line 686
    if-eqz p4, :cond_2b8

    .line 688
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 690
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 693
    move-result-object p2

    .line 694
    move-object v1, p2

    .line 695
    check-cast v1, Landroid/os/Bundle;

    .line 697
    :cond_2b8
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->K(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 700
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 703
    return v3

    .line 704
    :pswitch_2bf
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 707
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->E0()V

    .line 710
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 713
    return v3

    .line 714
    :pswitch_2c9
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 717
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 720
    move-result p1

    .line 721
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 724
    move-result p4

    .line 725
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 728
    move-result-object p2

    .line 729
    invoke-interface {p0, p1, p4, p2}, Landroid/support/v4/media/session/IMediaSession;->g(IILjava/lang/String;)V

    .line 732
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 735
    return v3

    .line 736
    :pswitch_2df
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 739
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 742
    move-result p1

    .line 743
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 746
    move-result p4

    .line 747
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 750
    move-result-object p2

    .line 751
    invoke-interface {p0, p1, p4, p2}, Landroid/support/v4/media/session/IMediaSession;->b0(IILjava/lang/String;)V

    .line 754
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 757
    return v3

    .line 758
    :pswitch_2f5
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 761
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->Q0()Landroid/support/v4/media/session/ParcelableVolumeInfo;

    .line 764
    move-result-object p1

    .line 765
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 768
    if-eqz p1, :cond_308

    .line 770
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 773
    invoke-virtual {p1, p3, v3}, Landroid/support/v4/media/session/ParcelableVolumeInfo;->writeToParcel(Landroid/os/Parcel;I)V

    .line 776
    goto :goto_30b

    .line 777
    :cond_308
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 780
    :goto_30b
    return v3

    .line 781
    :pswitch_30c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 784
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->a()J

    .line 787
    move-result-wide p1

    .line 788
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 791
    invoke-virtual {p3, p1, p2}, Landroid/os/Parcel;->writeLong(J)V

    .line 794
    return v3

    .line 795
    :pswitch_31a
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 798
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->p()Landroid/app/PendingIntent;

    .line 801
    move-result-object p1

    .line 802
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 805
    if-eqz p1, :cond_32d

    .line 807
    invoke-virtual {p3, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 810
    invoke-virtual {p1, p3, v3}, Landroid/app/PendingIntent;->writeToParcel(Landroid/os/Parcel;I)V

    .line 813
    goto :goto_330

    .line 814
    :cond_32d
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 817
    :goto_330
    return v3

    .line 818
    :pswitch_331
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 821
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->getTag()Ljava/lang/String;

    .line 824
    move-result-object p1

    .line 825
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 828
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 831
    return v3

    .line 832
    :pswitch_33f
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 835
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->getPackageName()Ljava/lang/String;

    .line 838
    move-result-object p1

    .line 839
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 842
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 845
    return v3

    .line 846
    :pswitch_34d
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 849
    invoke-interface {p0}, Landroid/support/v4/media/session/IMediaSession;->m()Z

    .line 852
    move-result p1

    .line 853
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 856
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 859
    return v3

    .line 860
    :pswitch_35b
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 863
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 866
    move-result-object p1

    .line 867
    invoke-static {p1}, Landroid/support/v4/media/session/IMediaControllerCallback$Stub;->asInterface(Landroid/os/IBinder;)Landroid/support/v4/media/session/IMediaControllerCallback;

    .line 870
    move-result-object p1

    .line 871
    invoke-interface {p0, p1}, Landroid/support/v4/media/session/IMediaSession;->J(Landroid/support/v4/media/session/IMediaControllerCallback;)V

    .line 874
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 877
    return v3

    .line 878
    :pswitch_36d
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 881
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 884
    move-result-object p1

    .line 885
    invoke-static {p1}, Landroid/support/v4/media/session/IMediaControllerCallback$Stub;->asInterface(Landroid/os/IBinder;)Landroid/support/v4/media/session/IMediaControllerCallback;

    .line 888
    move-result-object p1

    .line 889
    invoke-interface {p0, p1}, Landroid/support/v4/media/session/IMediaSession;->d(Landroid/support/v4/media/session/IMediaControllerCallback;)V

    .line 892
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 895
    return v3

    .line 896
    :pswitch_37f
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 899
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 902
    move-result p1

    .line 903
    if-eqz p1, :cond_391

    .line 905
    sget-object p1, Landroid/view/KeyEvent;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 907
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 910
    move-result-object p1

    .line 911
    move-object v1, p1

    .line 912
    check-cast v1, Landroid/view/KeyEvent;

    .line 914
    :cond_391
    invoke-interface {p0, v1}, Landroid/support/v4/media/session/IMediaSession;->Y(Landroid/view/KeyEvent;)Z

    .line 917
    move-result p1

    .line 918
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 921
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 924
    return v3

    .line 925
    :pswitch_39c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 928
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 931
    move-result-object p1

    .line 932
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 935
    move-result p4

    .line 936
    if-eqz p4, :cond_3b2

    .line 938
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 940
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 943
    move-result-object p4

    .line 944
    check-cast p4, Landroid/os/Bundle;

    .line 946
    goto :goto_3b3

    .line 947
    :cond_3b2
    move-object p4, v1

    .line 948
    :goto_3b3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 951
    move-result v0

    .line 952
    if-eqz v0, :cond_3c2

    .line 954
    sget-object v0, Landroid/support/v4/media/session/MediaSessionCompat$ResultReceiverWrapper;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 956
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 959
    move-result-object p2

    .line 960
    move-object v1, p2

    .line 961
    check-cast v1, Landroid/support/v4/media/session/MediaSessionCompat$ResultReceiverWrapper;

    .line 963
    :cond_3c2
    invoke-interface {p0, p1, p4, v1}, Landroid/support/v4/media/session/IMediaSession;->F0(Ljava/lang/String;Landroid/os/Bundle;Landroid/support/v4/media/session/MediaSessionCompat$ResultReceiverWrapper;)V

    .line 966
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 969
    return v3

    .line 970
    :cond_3c9
    invoke-virtual {p3, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 973
    return v3

    .line 974
    :cond_3cd
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 977
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 980
    move-result p1

    .line 981
    if-eqz p1, :cond_3df

    .line 983
    sget-object p1, Landroid/support/v4/media/RatingCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 985
    invoke-interface {p1, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 988
    move-result-object p1

    .line 989
    check-cast p1, Landroid/support/v4/media/RatingCompat;

    .line 991
    goto :goto_3e0

    .line 992
    :cond_3df
    move-object p1, v1

    .line 993
    :goto_3e0
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 996
    move-result p4

    .line 997
    if-eqz p4, :cond_3ef

    .line 999
    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 1001
    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 1004
    move-result-object p2

    .line 1005
    move-object v1, p2

    .line 1006
    check-cast v1, Landroid/os/Bundle;

    .line 1008
    :cond_3ef
    invoke-interface {p0, p1, v1}, Landroid/support/v4/media/session/IMediaSession;->e0(Landroid/support/v4/media/RatingCompat;Landroid/os/Bundle;)V

    .line 1011
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 1014
    return v3

    .line 1015
    :pswitch_data_3f6
    .packed-switch 0x1
        :pswitch_39c
        :pswitch_37f
        :pswitch_36d
        :pswitch_35b
        :pswitch_34d
        :pswitch_33f
        :pswitch_331
        :pswitch_31a
        :pswitch_30c
        :pswitch_2f5
        :pswitch_2df
        :pswitch_2c9
        :pswitch_2bf
        :pswitch_2a2
        :pswitch_285
        :pswitch_25c
        :pswitch_24e
        :pswitch_244
        :pswitch_23a
        :pswitch_230
        :pswitch_226
        :pswitch_21c
        :pswitch_212
        :pswitch_204
        :pswitch_1eb
        :pswitch_1ce
        :pswitch_1b7
        :pswitch_1a0
        :pswitch_192
        :pswitch_17b
        :pswitch_164
        :pswitch_156
        :pswitch_14c
        :pswitch_12f
        :pswitch_112
        :pswitch_e9
        :pswitch_db
        :pswitch_cd
        :pswitch_bf
        :pswitch_ae
        :pswitch_95
        :pswitch_78
        :pswitch_5f
        :pswitch_51
        :pswitch_43
        :pswitch_32
        :pswitch_24
        :pswitch_16
    .end packed-switch
.end method
