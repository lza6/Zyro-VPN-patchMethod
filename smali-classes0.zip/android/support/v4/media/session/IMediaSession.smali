.class public interface abstract Landroid/support/v4/media/session/IMediaSession;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/media/session/IMediaSession$Stub;
    }
.end annotation


# virtual methods
.method public abstract E0()V
.end method

.method public abstract F()Ljava/lang/CharSequence;
.end method

.method public abstract F0(Ljava/lang/String;Landroid/os/Bundle;Landroid/support/v4/media/session/MediaSessionCompat$ResultReceiverWrapper;)V
.end method

.method public abstract H(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract H0()Ljava/util/List;
.end method

.method public abstract I0(I)V
.end method

.method public abstract J(Landroid/support/v4/media/session/IMediaControllerCallback;)V
.end method

.method public abstract J0()V
.end method

.method public abstract K(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract L(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract N0()I
.end method

.method public abstract O()V
.end method

.method public abstract O0(J)V
.end method

.method public abstract P0(Z)V
.end method

.method public abstract Q(Landroid/net/Uri;Landroid/os/Bundle;)V
.end method

.method public abstract Q0()Landroid/support/v4/media/session/ParcelableVolumeInfo;
.end method

.method public abstract R(J)V
.end method

.method public abstract V0(I)V
.end method

.method public abstract Y(Landroid/view/KeyEvent;)Z
.end method

.method public abstract a()J
.end method

.method public abstract b0(IILjava/lang/String;)V
.end method

.method public abstract c(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract d(Landroid/support/v4/media/session/IMediaControllerCallback;)V
.end method

.method public abstract e()Z
.end method

.method public abstract e0(Landroid/support/v4/media/RatingCompat;Landroid/os/Bundle;)V
.end method

.method public abstract f(Landroid/support/v4/media/RatingCompat;)V
.end method

.method public abstract g(IILjava/lang/String;)V
.end method

.method public abstract getExtras()Landroid/os/Bundle;
.end method

.method public abstract getMetadata()Landroid/support/v4/media/MediaMetadataCompat;
.end method

.method public abstract getPackageName()Ljava/lang/String;
.end method

.method public abstract getTag()Ljava/lang/String;
.end method

.method public abstract h(Landroid/net/Uri;Landroid/os/Bundle;)V
.end method

.method public abstract h0(Landroid/support/v4/media/MediaDescriptionCompat;I)V
.end method

.method public abstract l(Landroid/support/v4/media/MediaDescriptionCompat;)V
.end method

.method public abstract m()Z
.end method

.method public abstract m0(Z)V
.end method

.method public abstract n(Landroid/support/v4/media/MediaDescriptionCompat;)V
.end method

.method public abstract next()V
.end method

.method public abstract p()Landroid/app/PendingIntent;
.end method

.method public abstract pause()V
.end method

.method public abstract previous()V
.end method

.method public abstract q0()Landroid/support/v4/media/session/PlaybackStateCompat;
.end method

.method public abstract s()I
.end method

.method public abstract stop()V
.end method

.method public abstract u(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract v0()I
.end method

.method public abstract w0(I)V
.end method

.method public abstract x()V
.end method

.method public abstract z0()Z
.end method
