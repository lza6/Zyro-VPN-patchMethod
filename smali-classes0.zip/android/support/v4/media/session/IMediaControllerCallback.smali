.class public interface abstract Landroid/support/v4/media/session/IMediaControllerCallback;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/media/session/IMediaControllerCallback$Stub;
    }
.end annotation


# virtual methods
.method public abstract C(Ljava/util/List;)V
.end method

.method public abstract C0(I)V
.end method

.method public abstract S(Z)V
.end method

.method public abstract Z(Z)V
.end method

.method public abstract a0(Ljava/lang/CharSequence;)V
.end method

.method public abstract b1(Landroid/support/v4/media/session/PlaybackStateCompat;)V
.end method

.method public abstract d1(Landroid/support/v4/media/session/ParcelableVolumeInfo;)V
.end method

.method public abstract g0()V
.end method

.method public abstract i0(Landroid/support/v4/media/MediaMetadataCompat;)V
.end method

.method public abstract onEvent(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract p0(I)V
.end method

.method public abstract y()V
.end method

.method public abstract z(Landroid/os/Bundle;)V
.end method
