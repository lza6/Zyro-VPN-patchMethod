.class public interface abstract Landroid/support/v4/app/INotificationSideChannel;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/app/INotificationSideChannel$a;,
        Landroid/support/v4/app/INotificationSideChannel$Stub;
    }
.end annotation


# static fields
.field public static final r1:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const/16 v0, 0x24

    .line 3
    const/16 v1, 0x2e

    .line 5
    const-string v2, "android$support$v4$app$INotificationSideChannel"

    .line 7
    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Landroid/support/v4/app/INotificationSideChannel;->r1:Ljava/lang/String;

    .line 13
    return-void
.end method


# virtual methods
.method public abstract B(Ljava/lang/String;)V
.end method

.method public abstract X0(Ljava/lang/String;ILjava/lang/String;Landroid/app/Notification;)V
.end method

.method public abstract j0(Ljava/lang/String;ILjava/lang/String;)V
.end method
